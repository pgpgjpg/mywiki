#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main(void)
{
	char buffer[80];
 	int fd;

	if((fd=open("/etc/hosts", O_RDONLY))==-1) {
		perror("open");
		exit(1);
	}
	dup2(fd, 0);
	close(fd);	 
	printf("Please input a string --> ");
	fgets(buffer,80, stdin);
	printf("You input the sting : %s\n", buffer);
	return 0;
}
