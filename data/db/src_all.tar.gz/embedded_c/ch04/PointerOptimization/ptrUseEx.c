#include <stdio.h>
typedef struct _info {
	char name[20];
	int age;
	float height;
}INFO;

int add(int d1, int d2) {
	return d1+d2;
}

void argArrTest(int *d) {
	int i;
	for(i=0; i<5; i++)
		printf("d[%d]:%d ", i, d[i]);
	printf("\n");
}

void argStrTest(char *d) {
	printf("d:%s\n", d);
}

void argStructTest(INFO * d) {
	int i;
	for(i=0; i<3; i++)
		printf("d_%d:%s, %d, %.1f\n", i, d[i].name, d[i].age, d[i].height);
}

void argFuncTest(int (*fp)(int, int)) {
	printf("%d + %d = %d\n", 10, 20, fp(10, 20));
}

int main(void) {
	int data[] = {1,2,3,4,5};
	char *str = "hello";
	INFO stInfo[3] = {{"kim", 17, 170.3F},
			  {"park", 20, 175.2F},
			  {"lee", 19, 180.1F}};
	
	argArrTest(data);
	argStrTest(str);
	argStructTest(stInfo);
	argFuncTest(add);
	return 0;
}
