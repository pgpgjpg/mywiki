#include <stdio.h>
#include <string.h>

typedef struct _info {
	char name[20];
	int age;
	float height;
}INFO;

typedef struct _classInfo {
	INFO *st;
	int classNo;
}CLASS_INFO;

#if TCASE==1
void setInfo(CLASS_INFO *d); 
void setInfo(CLASS_INFO *d) {
	strcpy(d->st->name, "kim");
	d->st->age = 21;
	d->st->height = 171.1F;
}
#elif TCASE==2
void setInfo(CLASS_INFO *d); 
void setInfo(CLASS_INFO *d) {
	INFO *t = d->st;
	strcpy(t->name, "park");
	t->age = 22;
	t->height = 181.1F;
}
#endif

int main(void) {
	INFO p_data;
	CLASS_INFO data = {&p_data, 1};
	setInfo(&data);
	printf("%s, %d, %.1f\n", data.st->name, data.st->age, data.st->height);
}
