#include <stdio.h>
#include <string.h>
typedef struct _info {
	char name[20];
	int age;
	float height;
}INFO;

#if TCASE==1
void printInfo(INFO d) {
	printf("%s, %d, %.1f\n", d.name, d.age, d.height);
}
#elif TCASE==2
void printInfo(INFO *d) {
	printf("%s, %d, %.1f\n", d->name, d->age, d->height);
}
#endif

int main(void) {
	INFO data;
	strcpy(data.name, "kim");
	data.age = 22;
	data.height = 180.4F;

#if TCASE==1
	printInfo(data);
#elif TCASE==2
	printInfo(&data);
#endif
}
