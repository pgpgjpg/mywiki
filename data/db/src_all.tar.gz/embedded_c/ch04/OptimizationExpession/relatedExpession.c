#include <stdio.h>

int main(void)
{
	int d1 = 1, d2 = 10, d3=3, d4 =5;
	
#if TCASE==1
	d1 = d2 / d3 + d4 / d3;
	
	if(d1 == 1) || (d1 == 2) || (d1 == 4) || (d == 8))
		printf("Hello!!\n);
		
	
	
#elif TCASE==2
	if ((d2 > 20) && (d1 < 10)) d3 = 2;
#endif	
	
	printf("d3:%d\n", d3);
	
	return 0;
}
