#include <stdio.h>

int main(void)
{
	int d1 = 5, d2 = 10, d3=1;
	
#if TCASE==1
	if ((d1 < 10) && (d2 > 20)) d3 = 2;
#elif TCASE==2
	if ((d2 > 20) && (d1 < 10)) d3 = 2;
#endif	
	
	printf("d3:%d\n", d3);
	
	return 0;
}
