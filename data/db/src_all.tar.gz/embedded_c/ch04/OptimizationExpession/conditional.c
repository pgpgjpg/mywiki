#include <stdio.h>

void f1(void) { printf("f1()..\n"); }
void f2(void) { printf("f2()..\n"); }
void f3(void) { printf("f3()..\n"); }
void f4(void) { printf("f4()..\n"); }
void f5(void) { printf("f5()..\n"); }

#if TCASE==1
void linkFunc(int type)
{
	switch(type) {
		case 1 :
			f1();
			break;
		case 2 : 
			f2();
			break;
		case 3 :
			f3();
			break;
		case 4 :
			f4();
			break;
		case 5 :
			f5();
			break;
	}
}
#elif TCASE==2
void linkFunc(int type)
{
	void (*fp[5])(void) = {f1, f2, f3, f4, f5};
	fp[type-1]();
}
#endif
int main(void)
{
	linkFunc(3);
	return 0;
}
