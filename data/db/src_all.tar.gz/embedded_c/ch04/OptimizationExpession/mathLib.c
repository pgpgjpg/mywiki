#include <stdio.h>
#include <math.h>

#if TCASE==1
double mathFunc(int type, int d)
{
	double rst;
	if(type == 1) rst = sin(d);
	else rst = cos(d);
	return rst;
}
#elif TCASE==2
double mathFunc(int type, int d)
{
	double rst;
	int t=0;
	
	double sin[] = {0, 0.85090, 1};
	double cos[] = {1, 0.85090, 0};
	if(d != 0) t = d/45;
	rst = (type == 1) ? sin[t] : cos[t];
	return rst;
}
#endif

int main(void)
{
	int menu, degree;
	printf("Select(1.sin, 2:cos) => ");
	scanf("%d", &menu);
	printf("Degree(0|45|90)? ");
	scanf("%d", &degree);
	printf("rst:%.5f\n", mathFunc(menu, degree));
	return 0;
}
