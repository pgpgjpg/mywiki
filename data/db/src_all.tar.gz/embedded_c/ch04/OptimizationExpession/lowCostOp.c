#include <stdio.h>

int main(void)
{
	int d1, d2, d3, d4;
	
	d1 = 51;  d2 = 51;
	d1 %= 8;
	d2 &= 7;
	printf("d1:%d, d2:%d\n", d1, d2);
	
	d3 = 31;  d4 = 31;
	d3 /= 4;
	d4 >>= 2;
	printf("d3:%d, d4:%d\n", d3, d4);
	
	return 0;
}
