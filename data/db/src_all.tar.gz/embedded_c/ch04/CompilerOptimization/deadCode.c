#include <stdio.h>

int main(void)
{
	int a, b = 0;
		
	scanf("%d", &a);
	if(a<0 && a>0) b = 10;
	
	return 0;
}
