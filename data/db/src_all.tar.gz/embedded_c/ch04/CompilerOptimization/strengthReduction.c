#include <stdio.h>

int main(void)
{
	int i, j;
		
	for(i=0; i<10; i++) {
		j = i * 5;
		printf("j:%d\n", j);
	}
		
	return 0;
}
