#include <stdio.h>
void f1(void) {
	printf("1...\n");
}
void f2(void) {
	printf("2...\n");
}
void f3(void) {
	printf("3...\n");
}
#if CASE==1
int main(void) {
	int menu=2;
	switch(menu) {
		case 1:
			f1();
			break;
		case 2:
			f2();
			break;
		case 3:
			f3();
			break;
	}
}
#elif CASE==2
int main(void) {
	int menu=2;
	void (*p[3])(void) = {f1, f2, f3};
	p[menu-1]();
}
#endif
