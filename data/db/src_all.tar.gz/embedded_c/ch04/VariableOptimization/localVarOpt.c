#include <stdio.h>
#if CASE==1
char f1(char d) {
	return d + 1;
}
int main(void) {
	int rst;
	rst = f1(10);
}
#elif CASE==2
short f2(short d) {
	return d + 1;
}
int main(void) {
	int rst;
	rst = f2(10);
}
#elif CASE==3
int f3(int d) {
	return d + 1;
}
int main(void) {
	int rst;
	rst = f3(10);
}
#endif