#include <stdio.h>

void f(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8);

int main()
{
	int n1=1, n2=2, n3=3, n4=4, n5=5, n6=6, n7=7, n8=8;

	f(n1, n2, n3, n4, n5, n6, n7, n8);

	return 0;
}

void f(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8)
{
	printf("%d %d %d %d %d %d %d %d\n", n1, n2, n3, n4, n5, n6, n7, n8);
}
