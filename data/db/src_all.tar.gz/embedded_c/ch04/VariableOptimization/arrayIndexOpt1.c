#include <stdio.h>
#if CASE==1
int main(void) {
	int menu=2, rst;
	switch(menu) {
		case 1:
			rst = 'a';
			break;
		case 2:
			rst = 'b';
			break;
		case 3:
			rst = 'c';
			break;
	}
	printf("rst:%c\n", rst);
}
#elif CASE==2
int main(void) {
	int menu=2, rst;
	static char *rstVal="abc";
	rst = rstVal[menu-1];
	printf("rst:%c\n", rst);
}
#endif
