#include <stdio.h>
int f2(void);
int global_var;
#if CASE==1
void f1(void) {
	int i;
	for(i=0; i<100; i++) {
		if(f2()) global_var++;
	}
}
#elif CASE==2
void f1(void) {
	int i, local_var=global_var;
	for(i=0; i<100; i++) {
		if(f2()) local_var++;
	}
	global_var = local_var;
}
#endif
int main(void) {
	f1();
}

int f2(void) {
	return 1;
}