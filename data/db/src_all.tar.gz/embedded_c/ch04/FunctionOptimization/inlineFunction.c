#include <stdio.h>

#define mul_macro(x)	((x)*(x))
inline int mul_inline(int x)
{
	return x*x;
}
int mul(int x)
{
	return x*x;
}

int main()
{
	printf("%d\n", mul_macro(4));
	printf("%d\n", mul_inline(4));
	printf("%d\n", mul(4));

	return 0;
}
