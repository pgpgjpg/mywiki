#include <stdio.h>

#if TCASE==1
int fact(int n) {
	if((n==1) || (n==0)) return 1;
	else return n * fact(n-1);
}
#elif TCASE==2
int fact(int n) {
	int i=1, rst=1;
	if(n==0) return 1;
loop:
	if(i<=n) rst *= i++;
	else return rst;
	goto loop;
}
#elif TCASE==3
int fact(int n) {
	int i, rst=1;
	if(n==0) return 1;
	for(i=1; i<=n; i++) rst *= i;
	return rst;
}
#endif

int main(void)
{
	fact(5);
	return 0;
}
