#include <stdio.h>

#if TCASE==1
int func1(int d1, int d2, int d3, int d4)
{
	return d1+d2+d3+d4;
}
#elif TCASE==2
int func2(int d1, int d2, int d3, int d4, int d5, int d6, int d7)
{
	return d1+d2+d3+d4+d5+d6+d7;
}
#endif

int main(void)
{
	int rst;
	rst = func1(1, 2, 3, 4);
	rst = func2(1, 2, 3, 4, 5, 6, 7);
	return 0;
}
