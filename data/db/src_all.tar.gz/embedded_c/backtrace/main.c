#include <stdio.h>

int func3();
int func2();
int func1();
void backtraceByGlibc();
void backtraceByGcc();

int main()
{
	func1();
	return 0;
}

int func1()
{
	func2();
	return 0;
}
int func2()
{
	func3();
	return 0;
}
int func3()
{
	//backtraceByGlibc();
	backtraceByGcc();
	return 0;
}

