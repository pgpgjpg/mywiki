#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>

#define BACKTRACE_BUFFER_SIZE 256

void backtraceByGlibc(void)
{
    int i, nptrs;
    void *buffer[BACKTRACE_BUFFER_SIZE];
    char **strings = NULL;

    nptrs = backtrace(buffer, BACKTRACE_BUFFER_SIZE);
    strings = backtrace_symbols(buffer, nptrs);
    if (!strings) {
        perror("backtrace_symbols");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < nptrs; i++) {
        printf("%s\n", strings[i]);
    }

    free(strings);
}

