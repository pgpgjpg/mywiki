#include <stdio.h>
#include <stdlib.h>

int main()
{
	FILE *fp1, *fp2;

	if((fp1=fopen("/etc/passwd", "r"))==NULL) {
		perror("fopen");
		exit(1);
	}
	if((fp2=fopen("/etc/shadow", "r"))==NULL) {
		perror("fopen");
		exit(1);
	}

	fclose(fp1);
	fclose(fp2);

	return 0;
}
