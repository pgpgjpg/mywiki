#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include "member.h"

typedef void (*FP)(darray*);

int main()
{
	int menu;
	darray *lpArray = NULL;
	void *handle;
	char *error;
	FP fp;

	handle = dlopen("/home/mobis/myLib/libmember.so", RTLD_LAZY);
	if(!handle){
		fputs(dlerror(), stderr);
		exit(1);
	}

	if(!createArray(&lpArray)){
		fprintf(stderr, "%s %d\n", __FILE__, __LINE__);
		return 1;
	}

	do{
		printf("1. 입력 \n");
		printf("2. 출력 \n");
		printf("3. 검색 \n");
		printf("4. 수정 \n");
		printf("5. 삭제 \n");
		printf("9. 종료 \n");
		printf("select : ");
		scanf("%d", &menu);
		getchar();
		
		switch(menu){
		case 1 : 
			printf("select 1\n\n");
			fp = dlsym(handle, "joinMember");
			if((error = dlerror()) != NULL){
				fprintf(stderr, "%s", error);
				exit(1);
			}
			fp(lpArray);
			//joinMember(lpArray);
			break;
		case 2 : 
			printf("select 2\n\n");
			fp = dlsym(handle, "showMember");
			if((error = dlerror()) != NULL){
				fprintf(stderr, "%s", error);
				exit(1);
			}
			fp(lpArray);
			//showMember(lpArray);
			break;
		case 3 : 
			printf("select 2\n\n");
			fp = dlsym(handle, "searchMember");
			if((error = dlerror()) != NULL){
				fprintf(stderr, "%s", error);
				exit(1);
			}
			fp(lpArray);
			//searchMember(lpArray);
			break;
		case 4 : 
			printf("select 2\n\n");
			fp = dlsym(handle, "reviseMember");
			if((error = dlerror()) != NULL){
				fprintf(stderr, "%s", error);
				exit(1);
			}
			fp(lpArray);
			//reviseMember(lpArray);
			break;
		case 5 : 
			printf("select 2\n\n");
			fp = dlsym(handle, "deleteMember");
			if((error = dlerror()) != NULL){
				fprintf(stderr, "%s", error);
				exit(1);
			}
			fp(lpArray);
			//deleteMember(lpArray);
			break;
		case 9 : 
			printf("select 9\n\n");
			exit(0);
			break;
		default :
			printf("wrong select\n\n");
			break;
		}
	}while(1);
	dlclose(handle);
	destroyArray(lpArray);

	return 0;
}

