#pragma once
#include "dynamicArray.h"

typedef struct{
	char name[20];
	char telno[16];
	float mileage;
}MEMBER, *LPMEMBER;

void joinMember(darray *lpArray);
void showMember(darray *lpArray);
void searchMember(darray *lpArray);	// input : name
void reviseMember(darray *lpArray);	// telno, mileage
void deleteMember(darray *lpArray);	// input : name
