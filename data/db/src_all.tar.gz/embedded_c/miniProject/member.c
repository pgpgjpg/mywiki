#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "member.h"

void joinMember(darray *lpArray)
{
	LPMEMBER input = (MEMBER*)malloc(sizeof(MEMBER));
	if(input == NULL){
		printf("error : joinMember_malloc\n");
		return;
	}

	printf("Enter name -> ");
	fgets(input->name, 20, stdin);
	input->name[strlen(input->name) - 1] = '\0';

	printf("Enter tel no -> ");
	fgets(input->telno, 16, stdin);
	input->telno[strlen(input->telno) - 1] = '\0';

	printf("Enter mileage -> ");
	scanf("%f", &input->mileage);
	getchar();

	AddArray(lpArray, (void*)input);
}

void showMember(darray *lpArray)
{
	int count;
	LPMEMBER value;

	CheckSize(lpArray, &count);

	for(int i = 0; i < count; ++i){
		GetArray(lpArray, i, (void**)&value);
		printf("name : %s\ntel no : %s\nmileage : %.1f\n\n", value->name, value->telno, value->mileage);
	}
}

void searchMember(darray *lpArray)    // input : name
{
	int count, i;
	char s_name[20];
	LPMEMBER value;

	printf("Enter name that you want to search -> ");
	fgets(s_name, 20, stdin);
	s_name[strlen(s_name) - 1] = '\0';

	CheckSize(lpArray, &count);

	for(i = 0; i < count; ++i){
		GetArray(lpArray, i, (void**)&value);
		if(!strcmp(value->name, s_name)){
			printf("Found!\n");
			printf("name : %s\ntel no : %s\nmileage : %f\n\n", value->name, value->telno, value->mileage);
			return;
		}
	}
	
	if(i == count){
		printf("error : there isn't [%s] in DB\n\n", s_name);
		return;
	}
}

void reviseMember(darray *lpArray)    // telno, mileage
{
	int count, i;
	char s_name[20];
	LPMEMBER value;

	printf("Enter name that you want to revise -> ");
	fgets(s_name, 20, stdin);
	s_name[strlen(s_name) - 1] = '\0';

	CheckSize(lpArray, &count);

	for(i = 0; i < count; ++i){
		GetArray(lpArray, i, (void**)&value);
		if(!strcmp(value->name, s_name)){
			MEMBER *new = (MEMBER*)malloc(sizeof(MEMBER));
			printf("Enter new tel no -> ");
			fgets(new->telno, 16, stdin);
			new->telno[strlen(new->telno) - 1] = '\0';

			printf("Enter new mileage -> ");
			scanf("%f", &new->mileage);
			getchar();

			strcpy(new->name, s_name);

			SetArray(lpArray, i, (void*)new);

			return;
		}
	}
	
	if(i == count){
		printf("error : there isn't [%s] in DB\n\n", s_name);
		return;
	}

}

void deleteMember(darray *lpArray)    // input : name
{
	int count, i;
	char s_name[20];
	LPMEMBER value;

	printf("Enter name that you want to delete -> ");
	fgets(s_name, 20, stdin);
	s_name[strlen(s_name) - 1] = '\0';

	CheckSize(lpArray, &count);

	for(i = 0; i < count; ++i){
		GetArray(lpArray, i, (void**)&value);
		if(!strcmp(value->name, s_name)){
			RemoveArray(lpArray, i);
			return;
		}
	}
	
	if(i == count){
		printf("error : there isn't [%s] in DB\n\n", s_name);
		return;
	}
}
