#ifndef __ISPRIME_H__
#define __ISPRIME_H__

int isPrime(int);

#endif
