#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int (*FCMP)(void *, void *);
#define	BASE(i)	((char *)base + (i)*size)
#define	NAME_SIZE	20

void bsort(void *base, int nelem, int size, FCMP fcmp);
int b_search(int *key, int *base, int nelem);
int fcmp1(void *a, void *b);

int main()
{
	int score[] = {78, 23, 86, 33, 98, 42};
	int i, rst, s_score;

	printf("Before Sort....\n");
	for(i=0; i<sizeof(score)/sizeof(int); i++)
		printf("%d ", score[i]);
	printf("\n\n");

	bsort(score, sizeof(score)/sizeof(int), sizeof(int), fcmp1);

	printf("After Sort....\n");
	for(i=0; i<(sizeof(score)/sizeof(int)); i++)
		printf("%d ", score[i]);
	printf("\n");
	printf("============================================\n");
	while(1)
	{
		printf("\nSearch Score ==> ");
		scanf("%d", &s_score);
		if(s_score == -1) break;
		rst = b_search(&s_score, &score[0], sizeof(score)/sizeof(int));
		if(rst != -1) printf("%d data ==> index %d\n",  s_score, rst);
		else printf("no %d data!!\n", s_score);
	}

	return 0;
}

void bsort(void *base, int nelem, int size, FCMP fcmp)
{
	int step, cmp, change;
    int rst;

	for(step=1; step<=nelem-1; step++) {
      change = 0;
      for(cmp = 1; cmp<=nelem-step; cmp++) {
		if(fcmp(BASE(cmp-1), BASE(cmp)) > 0) {
			swap(BASE(cmp-1), BASE(cmp), size);
            change = 1;
		}
	  }
	  if(change == 0) break;
    }
}

int fcmp1(void *a, void *b)
{
	return ((*(int *)a) == (*(int *)b)) ? 0 :
			((*(int *)a) > (*(int *)b)) ? 1 : -1;
}

int b_search(int *key, int *base, int nelem)
{
	int l, h, m, rst;
	l = 0;
	h = nelem-1;
	while(l<= h)
	{
		m = (l+h)/2;
		if((rst = (*key - base[m])) == 0) return m;
		if(rst < 0) h = m - 1;
		else l = m + 1;
	}

	return -1;
}
