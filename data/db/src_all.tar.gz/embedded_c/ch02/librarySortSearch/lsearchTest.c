#include <stdio.h>
#include <stdlib.h>
#include <search.h>

#define	TABLESIZE	5

int compare(const void *ap, const void *bp)
{
	return (*(int *)ap - *(int *)bp);
}

void print_table(const int *table, int nelm)
{
	int i;
	
	for(i=0; i<nelm; i++) {
		printf("%d\n", table[i]);
	}
}

int main(void)
{
	int table[TABLESIZE+1] = {5, 3, 10, 4, 8};
	unsigned int n=TABLESIZE;
	int item, *ptr;
	
	item = 9;
	printf("n:%d, TABLESIZE:%d\n", n, TABLESIZE);
	print_table(table, n);
	
	ptr = (int *)lsearch(&item, table, &n, sizeof(int), compare);
	if(ptr > (table+TABLESIZE-1)) {
	//if(ptr >= (table+n-1)) {
		printf("ptr:%p\n", ptr);
		printf("%d is not in table(0~%d), but added.\n", item, TABLESIZE-1);
	} else {
		printf("%d is in table(0~%d).\n", *ptr, TABLESIZE-1);
	}
	printf("n:%d, TABLESIZE:%d\n", n, TABLESIZE);
	print_table(table, n);
	
	item = 9;
	ptr = (int *)lfind(&item, table, &n, sizeof(int), compare);
	if(ptr == NULL) {
		printf("%d is not in table(0~%d).\n", item, n-1);
	} else {
		printf("%d is in table(0~%d).\n", *ptr, n-1);
	}
	
	return 0;
}