#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define	NAME_SIZE	20

int fcmp1(const void *a, const void *b);
int fcmp2(const void *a, const void *b);

int main()
{
	int score[] = {78, 23, 86, 33, 98, 42};
    char name[][NAME_SIZE] = {"yang", "lee", "kim", "park", "kang"};
	int i, s_score;
	char s_name[NAME_SIZE];
	void *rst;
	
	printf("Before Sort....\n");
	for(i=0; i<sizeof(score)/sizeof(int); i++)
		printf("%d ", score[i]);
	printf("\n\n");

	qsort(score, sizeof(score)/sizeof(int), sizeof(int), fcmp1);

	printf("After Sort....\n");
	for(i=0; i<(sizeof(score)/sizeof(int)); i++)
		printf("%d ", score[i]);
	printf("\n\n");

	while(1)
	{
		printf("\nSearch Score ==> ");
		scanf("%d", &s_score);
		if(s_score == -1) break;
		rst = bsearch(&s_score, &score[0], sizeof(score)/sizeof(int), sizeof(int), fcmp1);
		if(rst != NULL) printf("%d data found! ==> %d\n",  s_score, *((int *)rst));
		else printf("no %d data!!\n", s_score);
	}

    printf("============================================\n");
	printf("Before Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s ", name[i]);
	printf("\n\n");

	qsort(name, sizeof(name)/NAME_SIZE, NAME_SIZE, fcmp2);

	printf("After Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s ", name[i]);
	printf("\n\n");

	gets(s_name);
	while(1)
	{
		printf("\nSearch Name ==> ");
		gets(s_name);
		if(s_name[0] == '\0') break;
		rst = bsearch(s_name, &name[0][0], sizeof(name)/NAME_SIZE, NAME_SIZE, fcmp2);
		if(rst != NULL) printf("%s data found!! ==> %s\n",  s_name, (char *)rst);
		else printf("no %s data!!\n", s_name);
	}

	return 0;
}

int fcmp1(const void *a, const void *b)
{
	return ((*(int *)a) == (*(int *)b)) ? 0 :
			((*(int *)a) > (*(int *)b)) ? 1 : -1;
}

int fcmp2(const void *a, const void *b)
{
	return strcmp((char *)a, (char *)b);
}
