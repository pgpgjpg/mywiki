#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NAME_SIZE	20
int fcmp1(const void *a, const void *b);
int fcmp2(const void *a, const void *b);

int main()
{
	int score[] = {100, 78, 5, 23, 86, 33, 98, 42, 5, 40, 22};
    char name[][NAME_SIZE] = {"yang", "lee", "kim", "park", "kang"};
	int i;

	printf("Before Sort....\n");
	for(i=0; i<sizeof(score)/sizeof(int); i++)
		printf("%d ", score[i]);
	printf("\n\n");

	qsort(score, sizeof(score)/sizeof(int), sizeof(int), fcmp1);

	printf("After Sort....\n");
	for(i=0; i<(sizeof(score)/sizeof(int)); i++)
		printf("%d ", score[i]);
	printf("\n\n");

    printf("============================================\n");
	printf("Before Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s ", name[i]);
	printf("\n\n");

	qsort(name, sizeof(name)/NAME_SIZE, NAME_SIZE, fcmp2);

	printf("After Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s ", name[i]);
	printf("\n\n");

	return 0;
}

int fcmp1(const void *a, const void *b)
{
	return ((*(int *)a) == (*(int *)b)) ? 0 :
			((*(int *)a) > (*(int *)b)) ? 1 : -1;
}

int fcmp2(const void *a, const void *b)
{
	return strcmp((char *)a, (char *)b);
}
