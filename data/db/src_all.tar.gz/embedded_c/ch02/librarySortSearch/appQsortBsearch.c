#include <stdio.h>
..................

typedef struct _INFO {
	char name[20];
	int age;
	float height;
} INFO;

void printData(INFO *data, int nelem)
{
	int i;
	
	for(i=0; i<nelem; i++) {
		printf("%s, %d, %.1f\n", 
			data[i].name, data[i].age, data[i].height);
	}
}


void dataSearch(INFO *data, int nelem)
{
	char sname[80];
	..............
	
	while(1) {
		printf("\nInput Search Name(quit:'end') => ");
		fgets(sname, sizeof(sname), stdin);
		sname[strlen(sname)-1] = '\0';
		if(!strcmp(sname, "end")) break;
		....... bsearch(.............................);
		printf("\nSearch Result....\n");
		..........................
	
	}
}

int main(void)
{
	INFO data[] = {
		{"park", 17, 170.1F},
		{"lee", 20, 168.2F},
		{"kim", 18, 172.3F},
		{"yang", 22, 180.1F},
		{"kang", 19, 177.3F}};
	
	printf("Before Sort....\n");
	printData(data, sizeof(data)/sizeof(INFO));
	qsort(....................................................);
	printf("---------------------------\n");
	printf("After Sort....\n");
	printData(data, sizeof(data)/sizeof(INFO));
	
	dataSearch(..........................);
	
	return 0;
}