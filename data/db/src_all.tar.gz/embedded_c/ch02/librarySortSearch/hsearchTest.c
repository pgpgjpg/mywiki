#include <stdio.h>
#include <stdlib.h>
#include <search.h>
#include <string.h>

struct info {
	int id, age;
};

#define	TABLESIZE	50

int main(void)
{
	char nametable[TABLESIZE*20];
	char *nameptr = nametable;
	struct info infotable[TABLESIZE];
	struct info *infoptr = infotable;
	ENTRY item, *found;
	char name[30];
	int i=0;
	
	hcreate(TABLESIZE);
	for(i=0; i<TABLESIZE; i++) {
		printf("input data(name id age) : ");
		if(scanf("%s%d%d", nameptr, &infoptr->id, &infoptr->age) == EOF) break;
		item.key = nameptr;
		item.data = (void *)infoptr;
		
		if(hsearch(item, ENTER) == NULL) {
			perror("hsarch_insert failed");
			exit(1);
		}
		
		nameptr += strlen(nameptr) + 1;
		infoptr++;
	}
	
	printf("\ninput data end!!\n\n");
	
	item.key = name;
	while(1) {
		printf("\ninput search name : ");
		if(scanf("%s", name) == EOF) break;
		if((found = hsearch(item, FIND)) != NULL) {
			printf("found %s => id:%d, age:%d\n", found->key,
				((struct info *)found->data)->id, ((struct info *)found->data)->age);
		} else {
			printf("no such employee %s\n", name);
		}
	}
	hdestroy();
	return 0;
}