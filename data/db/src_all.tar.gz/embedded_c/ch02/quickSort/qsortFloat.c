#include <stdio.h>

void qsort(float *base, int nelem);

int main()
{
	int i;

	float avg[] = {35.3F, 99.1F, 70.2F, 55.5F, 12.7F, 40.4F, 63.1F};
	printf("Before Sort....\n");
	for(i=0; i<sizeof(avg)/sizeof(float); i++)
		printf("%.1f ", avg[i]);
	printf("\n\n");

	qsort(avg, sizeof(avg)/sizeof(float));

	printf("After Sort....\n");
	for(i=0; i<sizeof(avg)/sizeof(float); i++)
		printf("%.1f ", avg[i]);
	printf("\n\n");

	return 0;
}

void qsort(float *base, int nelem)
{
	float r, t;
	int l, h;

	if(nelem <= 1) return;

	r = *(base);
	l = 0;
	h = nelem;
	while(1)
	{
		while(*(base + ++l) < r);
		while(*(base + --h) > r);
		if(l >= h) break;
		t = *(base + l);
		*(base + l) = *(base + h);
		*(base + h) = t;
	}

	t = *(base + h);
	*(base + h) = *base;
	*(base) = t;
	qsort(base, h);
	qsort(base+h+1, nelem-h-1);
}
