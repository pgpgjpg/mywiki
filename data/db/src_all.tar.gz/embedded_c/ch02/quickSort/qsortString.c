#include <stdio.h>

#define	NAME_SIZE	20

void qsort(char *base, int nelem, int size);

int main()
{
	int i;

	char name[][NAME_SIZE] = {"yang", "lee", "kim", "park", "kang"};
	printf("Before Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s\n", name[i]);
	printf("\n\n");

	qsort(&name[0][0], sizeof(name)/NAME_SIZE, NAME_SIZE);

	printf("After Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s\n", name[i]);
	printf("\n\n");

	return 0;
}

void qsort(char *base, int nelem, int size)
{
	int l, h;

	if(nelem <= 1) return;

	l = 0;
	h = nelem;
	while(1)
	{
		while(strcmp(base+(++l)*size, base) < 0);
		while(strcmp(base+(--h)*size, base) > 0);
		if(l >= h) break;
		swap(base+l*size, base+h*size, size);
	}

	swap(base, base+h*size, size);
	
	qsort(base, h, size);
	qsort(base+(h+1)*size, nelem-h-1, size);
}
