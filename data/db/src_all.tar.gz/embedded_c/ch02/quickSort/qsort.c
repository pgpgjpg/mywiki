#include <stdio.h>

#define NAME_SIZE	20
#define	BASE(i)	((char *)base + (i)*(size))
typedef int (*FCMP)(void *, void*);

void qsort(void *base, int nelem, int size, FCMP fcmp);

int swap(void *dest, void *src, int size);

int main()
{
	int score[] = {100, 78, 5, 23, 86, 33, 98, 42, 5, 40, 22};
    char name[][NAME_SIZE] = {"yang", "lee", "kim", "park", "kang"};
	int i;

	printf("Before Sort....\n");
	for(i=0; i<sizeof(score)/sizeof(int); i++)
		printf("%d ", score[i]);
	printf("\n\n");

	qsort(score, sizeof(score)/sizeof(int), sizeof(int), .............);

	printf("After Sort....\n");
	for(i=0; i<(sizeof(score)/sizeof(int)); i++)
		printf("%d ", score[i]);
	printf("\n\n");

    printf("============================================\n");
	printf("Before Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s ", name[i]);
	printf("\n\n");

	qsort(name, sizeof(name)/NAME_SIZE, NAME_SIZE, ..............);

	printf("After Sort....\n");
	for(i=0; i<sizeof(name)/NAME_SIZE; i++)
		printf("%s ", name[i]);
	printf("\n\n");

	return 0;
}

void qsort(void *base, int nelem, int size, ...............)
{
	int l, h;

	if(nelem <= 1) return;

	l = 0;
	h = nelem;
	while(1)
	{
		while(fcmp(BASE(++l), base) < 0);
		while(fcmp(BASE(--h), base) > 0);
		if(l >= h) break;
		....................
	}

	.......................

	qsort(............................);
	qsort(.............................);
}


