#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void bsort(float *base, float nelem);

int main()
{
	float avg[] = {35.3F, 99.1F, 70.2F, 55.5F, 12.7F, 40.4F, 63.1F};
	int i;

	printf("Before Sort....\n");
	for(i=0; i<sizeof(avg)/sizeof(float); i++)
		printf("%.1f ", avg[i]);
	printf("\n\n");

	bsort(avg, sizeof(avg)/sizeof(float));

	printf("After Sort....\n");
	for(i=0; i<sizeof(avg)/sizeof(float); i++)
		printf("%.1f ", avg[i]);
	printf("\n\n");

	return 0;
}

void bsort(float *base, float nelem)
{
	int step, cmp, t, change;

	for(step=1; step<=nelem-1; step++) {
      change = 0;
      for(cmp = 1; cmp<=nelem-step; cmp++) {
		if(base[cmp-1] > base[cmp]) {
			swap(&base[cmp-1], &base[cmp], sizeof(float));
            change = 1;
		}
	  }
	  if(change == 0) break;
    }
}
