#include <stdio.h>

int main(void)
{
	short s[5] = {10, 20, 30, 40, 50};
	int i[5] = {100, 200, 300, 400, 500};
	double d[5] = {1000.1, 2000.2, 3000.3, 4000.4, 5000.5};
	void *p;

	p = (void *)s;    p = (short *)p + 3;
	printf("s:%d, *p:%d\n", s[3], *((short *)p));
	p = (void *)s;    p = (char *)p + 3*sizeof(short);
	printf("s:%d, *p:%d\n", s[3], *((short *)p));
	
	p = (void *)i;    p = (int *)p + 3;
	printf("i:%d, *p:%d\n", i[3], *((int *)p));
	p = (void *)i;    p = (char *)p + 3*sizeof(int);
	printf("i:%d, *p:%d\n", i[3], *((int *)p));
	
	p = (void *)d;    p = (double *)p + 3;
	printf("d:%.1f, *p:%.1f\n", d[3], *((double *)p));
	p = (void *)d;    p = (char *)p + 3*sizeof(double);
	printf("d:%.1f, *p:%.1f\n", d[3], *((double *)p));

	return 0;
}
