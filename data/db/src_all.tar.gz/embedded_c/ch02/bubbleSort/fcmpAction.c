#include <stdio.h>
int fcmp1(int *a, int *b);
int fcmp2(void *a, void *b);
int main()
{
	int n1=15, n2=10;
	printf("fcmp1_rst:%d\n", fcmp1(&n1, &n2));
	printf("fcmp2_rst:%d\n", fcmp2(&n1, &n2));
	return 0;
}
int fcmp1(int *a, int *b)
{
	if(*a == *b) return 0;
	else if(*a > *b) return 1;
	else return -1;
	/*
	return (*a == *b) ? 0 :
		   (*a > *b) ? 1 : -1;
	*/
}
int fcmp2(void *a, void *b)
{
	return ((*(int *)a) == (*(int *)b)) ? 0 :
			((*(int *)a) > (*(int *)b)) ? 1 : -1;
}
