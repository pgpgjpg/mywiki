#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void)
{
   pid_t pid;

   pid=fork();
   switch(pid) {
   case -1:
           perror("fork()");
           exit(-1);
           break;
   case 0:         /* child process */ 
	//
           break;
   default:        /* Parent Process */
           //
           break;
   }
   return 0;
}
