#include <stdio.h>

void printData(void);
void updateData(void);

int gIntData = 10;
int gArrData[3] = {1, 2, 3};
char gStrData[] = "apple";

int main(void)
{
	printf("\nsizeof(gArrData):%d, sizeof(gStrData):%d\n\n",
		sizeof(gArrData), sizeof(gStrData));
	printData();
	updateData();
	printData();
	
	return 0;
}
