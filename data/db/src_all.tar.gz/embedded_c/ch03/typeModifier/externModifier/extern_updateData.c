#include <stdio.h>
#include <string.h>
#ifdef TEST2
extern int gIntData;
extern int gArrData[5];
extern char gStrData[80];
#else
extern int gIntData;
extern int gArrData[3];
extern char gStrData[10];
#endif
void updateData(void) {
	int i;
	gIntData++;
#ifdef TEST2
	for(i=0; i<5; i++) gArrData[i]++;
#else
	for(i=0; i<3; i++) gArrData[i]++;
#endif
	strcpy(gStrData, "Good Morning?");
	printf("\nsizeof(gArrData):%d, sizeof(gStrData):%d\n\n",
		sizeof(gArrData), sizeof(gStrData));
}
