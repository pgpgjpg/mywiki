#include <stdio.h>

void func1(void);
static void func3(void);

extern int n;

//static void func2(void)
void func2(void)
{
	n++;
	printf("func2 : n=%d\n", n);
	func1();
	func3();
}

static void func3(void)
{
	printf("func3\n");
}
