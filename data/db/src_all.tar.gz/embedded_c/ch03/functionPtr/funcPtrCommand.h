#ifndef _COMMAND_H_
#define _COMMAND_H_

#define MAX_COMMANDS			20


typedef struct _CMD_TBL {
	char 	*cmd;		// command name
	void	(*run)(int);	// function point.
	char	*usage;		// command usage
} CMD_TBL;


#define	CMD_TBL_T1	{"test1", func_t1, "  test1       test1 function"}
#define	CMD_TBL_T2	{"test2", func_t2, "  test2       test2 function"}
#define	CMD_TBL_T3	{"test3", func_t3, "  test3       test3 function"}
#define	CMD_TBL_END	{0, 0, 0}

extern CMD_TBL cmdTbl[];

// Prototypes.
void	DisplayPrompt(char *prompt);
void	GetCommand(char *cmd);
void 	func_t1(int);
void 	func_t2(int);
void 	func_t3(int);


#endif		// end _COMMAND_H_
