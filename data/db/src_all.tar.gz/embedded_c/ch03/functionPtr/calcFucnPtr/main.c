#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "calcFuncPtrCommand.h"

CALC_T cmdTbl[] = {
	CMD_TBL_T1, 
	CMD_TBL_T2, 
	CMD_TBL_T3, 
	CMD_TBL_T4, 
	CMD_TBL_END
};
	
		
void DisplayPrompt(char *prompt){
	if(prompt == NULL) {
		printf("monitor> ");
	} else {
		printf("%s", prompt);
	}
}

void GetCommand(char *cmd)
{
	fgets(cmd, 80, stdin);
	cmd[strlen(cmd) - 1] = '\0';
}

void DoPrintfHelp(void){
	CALC_T *cptr;

	printf("The following commands are supported :\n");

	for (cptr=cmdTbl; cptr->cmd; cptr++){
		printf("%s", cptr->cmd);
		printf("\n");
	}

	printf("  help        Help for commands.\n");
	printf("  ?           Help for commands.\n");
	printf("  exit        Quit the monitor program.\n");

	printf("\n");
}

int main(void)
{
	char cmd[80];
	CALC_T *cptr;
	int input_x, input_y;

	while(1) {
		DisplayPrompt("myshell> ");
		GetCommand(cmd);
		if(!cmd[0]) continue;

		for (cptr=cmdTbl; cptr->cmd && strcmp(cmd, cptr->cmd); cptr++);		
		if(cptr->cmd){
			int rst;
			printf("input 2 numbers (x,y) : ");
			scanf("%d%d", &input_x, &input_y);
			getchar();
			rst = cptr->cfunc(input_x, input_y);
			printf("result = %d\n", rst);
		}
		
		if (!strcmp(cmd, "help") || !strcmp(cmd, "?")){
			DoPrintfHelp();
		} else if (!strcmp(cmd, "exit")) {
			exit(0);
		} else if (!(cptr->cmd)){
			printf("\tUnknown command\n");
		}
	}
	return 0;
}
