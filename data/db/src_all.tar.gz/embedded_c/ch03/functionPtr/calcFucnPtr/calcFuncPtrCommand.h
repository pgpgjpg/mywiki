#ifndef _COMMAND_H_
#define _COMMAND_H_

#define MAX_COMMANDS			20


typedef struct calc_t {
	char 	*cmd;				// command name
	int		(*cfunc)(int, int);	// function point.
} CALC_T;


#define	CMD_TBL_T1	{"add", add}
#define	CMD_TBL_T2	{"sub", sub}
#define	CMD_TBL_T3	{"mul", mul}
#define	CMD_TBL_T4	{"divide", divide}
#define	CMD_TBL_END	{0, 0}

extern CALC_T cmdTbl[];

// Prototypes.
void DisplayPrompt(char *prompt);
void GetCommand(char *cmd);

int add(int, int);
int sub(int, int);
int mul(int, int);
int divide(int, int);

#endif		// end _COMMAND_H_
