#include "calcFuncPtrCommand.h"
#include <stdio.h>

int add(int x, int y)
{
	return x+y;
}

int sub(int x, int y)
{
	return x-y;
}
int mul(int x, int y)
{
	return x*y;
}
int divide(int x, int y)
{
	if(y)	return x/y;
	else{
		printf("error: zero divided\n");
		return 0;
	}
}
