#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define	NAME_SIZE	20

int main(void)
{
	short sdata[] = {1, 2, 3, 4};
	float fdata[] = {100.1F, 200.2F, 300.3F, 400.4F};
	char name[][NAME_SIZE] = {"kim", "park", "choi", "lee"};
	void *p1, *p2, *p3;
	
	p1 = sdata;
	p2 = p1 + 1;
	p3 = (short *)p1 + 1;
	//printf("*p1:%d, *p2:%d, *p3:%d\n", *p1, *p2, *p3);	// error
	printf("*p1:%d, *p2:%d, *p3:%d\n", *(short *)p1, *(short *)p2, *(short *)p3);
	
	p1 = fdata;
	p2 = (float *)p1 + 1;
	printf("*p1:%1.f, *p2:%.1f\n", *(float *)p1, *(float *)p2);
	
	p1 = &name[0][0];
	p2 = (char *)p1 + 1*NAME_SIZE;
	printf("*p1:%s, *p2:%s\n", (char *)p1, (char *)p2);
	
	return 0;
}
