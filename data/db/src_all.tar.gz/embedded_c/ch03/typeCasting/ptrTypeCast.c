#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define	NAME_SIZE	20

void dataCopy(.........., ...., int size, int pos);

int main(void)
{
	short s, sdata[] = {1, 2, 3, 4};
	int i, idata[] = {10, 20, 30, 40};
	float f, fdata[] = {100.1F, 200.2F, 300.3F, 400.4F};
	char str[NAME_SIZE], name[][NAME_SIZE] = {"kim", "park", "choi", "lee"};
	
	dataCopy(&s, sdata, sizeof(short), 2);
	dataCopy(&i, idata, sizeof(int), 2);
	dataCopy(&f, fdata, sizeof(float), 2);
	dataCopy(str, &name[0][0], NAME_SIZE, 2);
	
	printf("s   : %d\n", s);
	printf("i   : %d\n", i);
	printf("f   : %.1f\n", f);
	printf("str : %s\n", str);
	
	return 0;
}

void dataCopy(....., ......, int size, int pos)
{
	...........
	return;
}
