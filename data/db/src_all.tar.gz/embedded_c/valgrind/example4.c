#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *mainPtr = (int *) malloc(sizeof(int));

	*mainPtr=100;

	if(*mainPtr==100)
		printf("%d", *mainPtr);

	free(mainPtr);

	*mainPtr = 200;

	return 0;	
}
