#include <stdio.h>
#include <stdlib.h>

int*memAlloc(int);
void setFree(int*);

int main()
{
	int *mainPtr;

	mainPtr = memAlloc(sizeof(int));

	*mainPtr=100;

	if(*mainPtr==100)
		printf("%d\n", *mainPtr);

	setFree(mainPtr);
	free(mainPtr);

	return 0;	
}

int* memAlloc(int size)
{
	return (int*) malloc(sizeof(int));
}

void setFree(int* mainPtr) 
{
	free(mainPtr);
}
