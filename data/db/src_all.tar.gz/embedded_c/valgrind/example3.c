#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *mainPtr = (int*) malloc(sizeof(int));
	*mainPtr = 100;
	if(*mainPtr==100)
		printf("%d\n", *mainPtr);

	free(mainPtr);

	return 0;	
}
