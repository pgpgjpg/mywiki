#include <stdio.h>
#include <stdlib.h>

int main()
{
	char* ptr =(char*) malloc(sizeof(char)*80);

	printf("Input>> ");
	scanf("%s", ptr);
	printf("%s\n", ptr);
	return 0;	
	
}
