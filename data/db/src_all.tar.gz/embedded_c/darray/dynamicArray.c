// 동적 배열 구성하기
#include <stdio.h>
#include <stdlib.h>
#include "dynamicArray.h"
#include <stdbool.h>

int createArray(darray** lpArray)
{
	darray* temp;

	temp = (darray *) malloc(sizeof(darray));
	if(temp==NULL)
		return false;
	temp->max_size=10;
	temp->size=0;
	temp->array = (void**) malloc(sizeof(void*)*temp->max_size);
	if(temp->array==NULL)
		return false;
	*lpArray = temp;
	return true;
}

int destroyArray(darray* lpArray)
{
	free(lpArray->array);
	free(lpArray);
	return true;
}

int AddArray(darray* lpArray, void* value)
{
	if(lpArray->size==lpArray->max_size) { 		// Full?
		lpArray->array=(void**)realloc(lpArray->array, sizeof(void*)*lpArray->max_size*2);
		if(lpArray->array==NULL) {
			perror("Memory Realloc");
			return false;
		}
		lpArray->max_size *= 2;
	}
		
	lpArray->array[lpArray->size++]= value;
	return true;
}


int GetArray(darray* lpArray,int i,void** value)
{
	if(i>=lpArray->size)
		return false;
	*value = lpArray->array[i];
	return true;
}

int SetArray(darray* lpArray, int i, void* value)
{
	if(i<0 || i>=lpArray->size)
		return false;
	free(lpArray->array[i]);	
	lpArray->array[i] = value;
	return true;
}

int RemoveArray(darray* lpArray, int i)
{
	if(i<0 || i>=lpArray->size)
		return false;

	free(lpArray->array[i]);
	for(int n = i+1; n < lpArray->max_size-1; ++n)
		lpArray->array[n-1] = lpArray->array[n];
	lpArray->array[lpArray->size-1] = NULL;
	lpArray->size--;
	return true;
}

int CheckSize(darray* lpArray, int* size)
{
	*size = lpArray->size;
	return true;
}
