#pragma once

typedef struct score {
		char name[20];
		int c;
		int linux_s;
		float avg;
} SCORE, *LPSCORE;
