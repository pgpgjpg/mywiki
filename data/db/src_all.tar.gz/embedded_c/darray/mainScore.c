// 동적 배열 구성하기
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dynamicArray.h"
#include "score.h"


int main()
{
	darray *lpArray=NULL;


	 if(!createArray(&lpArray)) {		// 배열 선언 
		fprintf(stderr, "%s %d\n", __FILE__, __LINE__);
		return 1;
	}

	int i;
	LPSCORE lpscore;

	while(1) {
		lpscore = (LPSCORE) malloc( sizeof(SCORE));
		if(lpscore==NULL) {
				fprintf(stderr, "malloc error\n");
				return 1;
		}
		printf("name : ");
		fgets(lpscore->name, 20, stdin);
		lpscore->name[strlen(lpscore->name)-1]='\0';
		if(strcmp(lpscore->name, "end")==0) {
				free(lpscore);
				break;
		}
		printf("c linux_s : ");
		scanf("%d %d", &lpscore->c, &lpscore->linux_s); getchar();
		lpscore->avg = (lpscore->c + lpscore->linux_s)/2.0;

		AddArray(lpArray, (void*) lpscore);		// 원소 추가 
	}

	LPSCORE value;
	int count;

	CheckSize(lpArray, &count);

	for(i=0; i< count; i++) {
		GetArray(lpArray, i, (void**) &value);
		printf("%s %d %d %.2f\n", value->name, value->c, value->linux_s, value->avg);
	}

	value = (LPSCORE)malloc(sizeof(SCORE));
	memset(value, 0, sizeof(SCORE));
	strcpy(value->name, "hong");
	value->c = 80;
	value->linux_s = 90;

	SetArray(lpArray, 1, (void*) value);
	CheckSize(lpArray, &count);
	
	for(i=0; i< count; i++) {
		GetArray(lpArray, i, (void**) &value);
		printf("%s %d %d %.2f\n", value->name, value->c, value->linux_s, value->avg);
	}

	for(i = 0; i < count; ++i)
		RemoveArray(lpArray, 0);

	



	destroyArray(lpArray);
 
	return 0;
}

