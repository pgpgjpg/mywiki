#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

	FILE *fp;
	char data, buf[1024];

	if((fp=fopen(argv[1], "r"))==NULL)
	{
		perror("fopen");
		exit(1);
	}

	data = fgetc(fp);
	printf("read data : %c\n", data);
	data = fgetc(fp);
	printf("read data : %c\n", data);
	//fputc(data, stdout);

	fgets(buf, sizeof(buf), fp);
	printf("read data : %s\n", buf);
	//fputs(buf, stdout);

	fgets(buf, 5, fp);
	printf("read data : %s\n", buf);
	//fputs(buf, stdout);

	fgets(buf, sizeof(buf), fp);
	printf("read data : %s\n", buf);
	//fputs(buf, stdout);

	fclose(fp);
	return 0;
}
