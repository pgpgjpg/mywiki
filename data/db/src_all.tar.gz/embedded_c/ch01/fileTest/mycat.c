#include <stdio.h>
#include <stdlib.h>

int main(int argc, char * argv[])
{
	FILE *fp;
	char ch, buff[256];
	
	if(argc!=2) {
		printf("Usage : %s file_name\n", argv[0]);
		exit(1);
	}

	if((fp = fopen(argv[1], "r")) == NULL) {
		perror("file open");
		exit(1);
	}

#if CASE==1
	while((ch=fgetc(fp)) != EOF) putchar(ch);
#elif CASE==2
	while(1) {
		ch=fgetc(fp);
		if(feof(fp)) break;
		putchar(ch);
	}
#elif CASE==3
	while(fgets(buff, sizeof(buff), fp) != NULL) printf("%s", buff);
#else
	while(1) {
		fgets(buff, sizeof(buff), fp);
		if(feof(fp)) break;
		printf("%s", buff);
	}
#endif

	fclose(fp);


	return 0;
}
