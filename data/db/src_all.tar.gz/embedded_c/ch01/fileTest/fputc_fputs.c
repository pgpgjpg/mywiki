#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *fp;
	char buf[1024];

	if((fp=fopen(argv[1], "w"))==NULL)
	{
		perror("fopen");
		exit(1);
	}

	fputc('A', fp);
	fputc('B', fp);
	fputc('C', fp);
	fputc('\n', fp);
	fputs("Hello!\n", fp);
	fputs("Apple\n", fp);
	fputs("Banana\n", fp);

	fclose(fp);
	return 0;
}
