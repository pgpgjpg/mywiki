#include "a.h"
#include "b.h"

void func1();
void func2();

int main()
{
   int n=NO1;
   printf("test1(%d)\n", n);
   func1();
   func2();

   return 0;
}
