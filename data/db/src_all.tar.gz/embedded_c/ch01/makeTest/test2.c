#include "a.h"
#include "c.h"

extern void func1()
{
   int n=NO2;
   printf("test2(%d)\n", n);
}
