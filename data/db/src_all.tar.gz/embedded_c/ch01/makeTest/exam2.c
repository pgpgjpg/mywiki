#include "a.h"
#include "b.h"

void func1();

main()
{
   int n=NO1;
   printf("exam2(%d)\n", n);
   func1();
}
