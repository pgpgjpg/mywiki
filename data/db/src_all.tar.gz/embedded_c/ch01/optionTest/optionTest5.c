#include <stdio.h>
#include <math.h>
int main(void)
{
    double rst;
    rst = log(2.0);
    printf("rst:%.2f\n", rst);
    return 0;
}
