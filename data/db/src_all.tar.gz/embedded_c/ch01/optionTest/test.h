#pragma once
int max(int, int);
int min(int, int);
