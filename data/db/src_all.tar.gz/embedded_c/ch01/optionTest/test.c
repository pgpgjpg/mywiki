#include <stdio.h>
#include "test.h"

int max(int x, int y)
{
	if(x > y)
		return x;
	else
		return y;
}

int min(int x, int y)
{
	if(x >y)
		return y;
	else
		return x;
}
