#include <stdio.h>
#include "test.h"

int main()
{
	int lv1 = 5, lv2 = 3;

	printf("MAX : %d\n", max(lv1, lv2));
	printf("MIN : %d\n", min(lv1, lv2));

	return 0;
}
