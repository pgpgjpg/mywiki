#include <stdio.h>
int gv1 = 10, gv2;
int main(void)  {
    int lv1, lv2, lv3=30;
    const int lv4=10;
    short *p;
    printf("Main Start..\n");
    lv1 = 10;
    printf("Main End...\n");
    return 0;
}
