#include <stdio.h>
#include <math.h>

int main(void)
{
	double rst;

	rst = sin(45.0);
	printf("rst : %.2f\n", rst);
	
	return 0;
}
