#include "calc.h" 
#include <stdio.h>

int div(int d1, int d2) {
	if(d2 == 0){
		printf("error : d2 is 0\n");
		return 1;
	}
	else
		return d1/d2;
}

