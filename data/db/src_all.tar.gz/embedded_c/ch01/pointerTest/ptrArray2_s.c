#include <stdio.h>

void printData_1(......., int size)
{
	int i;

	for(i=0; i<size; i++) {
		printf("%s,%s\n", ...............);
	}
}

void printData_2(.........., int size)
{	
	int i;

	for(i=0; i<size; i++) {
		printf("%s,%s\n", ..............);
	}
}

int main(void)
{
	char arr1[3][80] = {"kim", "lee", "park"};
	char *p1[3] = {"kim", "lee", "park"};
	
	printData_1(arr1, 3);
	printf("-------------------------\n");
	printData_2(p1, 3);
	printf("-------------------------\n");
	
	return 0;
}
