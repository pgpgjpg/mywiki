#include "calc.h" 

int mul(int d1, int d2) {
    return d1*d2;
}

