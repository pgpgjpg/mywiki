#include "calc.h" 

int sub(int d1, int d2) {
    return d1-d2;
}

