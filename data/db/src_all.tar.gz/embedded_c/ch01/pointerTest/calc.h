#pragma once
typedef int (*FP)(int, int);
int add(int, int);
int sub(int, int);
int mul(int, int);
int div(int, int);
