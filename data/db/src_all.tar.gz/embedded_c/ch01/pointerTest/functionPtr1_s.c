#include <stdio.h>

typedef int (*FP)(int, int);

int add(int d1, int d2) {
	return d1+d2;
}
int sub(int d1, int d2) {
	return d1-d2;
}
int mul(int d1, int d2) {
	return d1*d2;
}
int div(int d1, int d2) {
	if(d2) return d1/d2;
	else { printf("Zero Dived Error!!\n"); return 0; }
}

int main(void)
{
	int no, rst;
	FP f;

	while(1){
		do{
			printf("\nSelect(1. add, 2. sub, 3. mul, 4.div, 0. quit) => ");
			scanf("%d", &no);
		}while(no<0 || no>4);

		switch(no){
			case 1 : 
				f = add;
				printf("%d\n", f(2, 1));
				break;
			case 2 : 
				f = sub;
				printf("%d\n", f(2, 1));
				break;
			case 3 :
				f = mul;
				printf("%d\n", f(2, 1));
				break;
			case 4 : 
				f = div;
				printf("%d\n", f(2, 1));
				break;
			default : 
				return 0;	
		}
	}

	return 0;
}
