#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

int main()
{
	int b = true;
	int8_t ch = 0x10;
	int32_t i = 0xffffffff;
	int64_t ii = 0xaaaaaaaaffffffff;

	printf("%d %x %x %lx\n", b, ch, i,  ii);

	return 0;
}
