#include <stdio.h>
#include <stdlib.h>

int main()
{
/*
	int *pnum[5] = {NULL}, sum = 0;

	for(int i = 0; i < 5; ++i){
		pnum[i] = (int*)malloc(sizeof(int));
		scanf("%d", pnum[i]);
		printf("addr : %p, value : %d\n", pnum[i], *pnum[i]);	
	}

	for(int i = 0; i < 5; ++i) sum += **(pnum+i);
	for(int i = 0; i < 5; ++i) free(pnum[i]);

	printf("Sum = %d\n", sum);

	return 0;
*/

	int *pnum, sum = 0;
	pnum = (int*)malloc(sizeof(int)*5);

	for(int i = 0; i < 5; ++i){
		scanf("%d", &pnum[i]);
		printf("addr : %p, value : %d\n", &pnum[i], pnum[i]);	

	}

	for(int i = 0; i < 5; ++i) sum += pnum[i];
	free(pnum);

	printf("Sum = %d\n", sum);

	return 0;
}
