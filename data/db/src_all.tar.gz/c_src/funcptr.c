#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int max(int*);
int min(int*);

int main()
{
	// Variables declaration
	int n1[5], maxV, minV; 
	int (*fptr[2])(int*);

	// rand
	srand(time(NULL));
	
	// connect function pointer to funtion
	fptr[0] = max;
	fptr[1] = min;

	// Enter values in array for function's input
	for(int i = 0; i < 5; ++i)
		n1[i] = rand()%100;
	
	// Must use pointer of function
	// max(n1);
	maxV = fptr[0](n1);
	// min(n1);
	minV = fptr[1](n1);

	// printing array, max and min value
	for(int i = 0; i < 5; ++i)
		printf("%5d", *(n1 + i));
	printf("\n");
	printf("Max Value : %d\n", maxV);
	printf("Min Value : %d\n", minV);

	return 0;
}

int max(int *a)
{
	int maxV = *a;

	// finding max value in array
	for(int i = 1; i < 5; ++i){
		if(maxV < *(a + i))
			maxV = *(a + i);
	}

	return maxV;
}

int min(int *a)
{
	int minV = *a;

	// finding min value in array
	for(int i = 1; i < 5; ++i){
		if(minV > *(a + i))
			minV = *(a + i);
	}

	return minV;

}
