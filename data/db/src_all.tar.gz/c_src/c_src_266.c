#include <stdio.h>

int main()
{
	double d[5] = {1.2, 2.3, 3.4, 4.5, 5.6};
	double *dp = d;

	for(int i = 0; i < 5; ++i){
		//printf("%.1lf\t", *(d + i));
		//printf("%.1lf\t", *(dp + i));
		printf("%.1lf\t", *dp++);
	}
	printf("\n");

	return 0;
}
