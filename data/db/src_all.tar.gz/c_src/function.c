#include <stdio.h>
#include <math.h>

// Fucntion declare
void isprime(int number);

int main()
{
	int number;

	while(1)
	{
		printf("\nEnter any positive number(exit : negative number) --> ");
		scanf("%d", &number);

		if(number < 0){
			printf("%d is invalid number\n", number);
			break;
		}
		// call function
		isprime(number);
	}

	return 0;
}

// Function definition
void isprime(int number)
{
	int i, cnt = 0;
	double maxNumber;

	maxNumber = sqrt(number);
	
    for(i = 2; i <= maxNumber; ++i){
        if(number%i == 0){
			printf("The number %d isn't prime\n", number);			
			break;
		}
    }
	if(i == maxNumber)
		printf("The number %d is prime\n", number);

	return;
}
