#include <stdio.h>

int main()
{
	struct person{
		char name[20];
		int age;
	};
	typedef struct person PERSON;
	PERSON p1 = {"Kim", 10}, p2;

	p2 = p1;

	printf("%s %d\n", p2.name, p2.age);

	return 0;
}
