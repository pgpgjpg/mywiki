#include <stdio.h>
#include <stdlib.h>

int input(int**);

int main()
{
	int *pnum, sum = 0;
	
	if(!input(&pnum)){
		exit(1);
	}

	for(int i = 0; i < 5; ++i) sum += pnum[i];
	free(pnum);
	printf("Sum = %d\n", sum);

	return 0;
}

int input(int **ptr)
{
	int *pnum;
	//pnum = (int*)malloc(sizeof(int)*5);
	pnum = (int*)calloc(5, sizeof(int));
	if(ptr == NULL){
		printf("Error : can not allocate memory\n");
		return 0;
	}
		
	for(int i = 0; i < 5; ++i){
		scanf("%d", &pnum[i]);
		printf("addr : %p, value : %d\n", &pnum[i], pnum[i]);	
	}

	*ptr = pnum;

	return 1;
}
