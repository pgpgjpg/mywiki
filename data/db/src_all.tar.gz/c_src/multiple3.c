#include <stdio.h>

int main()
{
	int nMul, sum, i;

	for(i = 1, sum = nMul = 0; i <= 100; ++i){
		i%3 ? (1) : (sum += i, nMul++);
	}
	
	printf("The number of multiple 3 : %d\n", nMul);
	printf("Sum : %d\n", sum);

	return 0;
}

