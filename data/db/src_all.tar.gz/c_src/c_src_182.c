#include <stdio.h>
#include "c_src_182.h"
// 함수 선언
/*
void add(int num1, int num2);
void sub(int num1, int num2);
void multiply(int num1, int num2);
void divide(int num1, int num2);
*/
int main()
{
	int num1, num2;
	char op;

	printf("Enter oper you want(+, -, *, /)\n");
	scanf("%c", &op);
	printf("Enter two numbers\n");
	scanf("%d %d", &num1, &num2);

	switch(op){
	case '+' :
		add(num1, num2);
		break;
	case '-' :
		sub(num1, num2);
		break;
	case '*' :
		multiply(num1, num2);
		break;
	case '/' :
		divide(num1, num2);
		break;
	default :	
		break;
	}

	return 0;
}

// 함수 정의
void add(int num1, int num2)
{
	int tmp;

	tmp = num1 + num2;
	printf("%d + %d = %d\n", num1, num2, tmp);

	return; 
}

void sub(int num1, int num2)
{
	int tmp;

	tmp = num1 - num2;
	printf("%d - %d = %d\n", num1, num2, tmp);

	return; 
}

void multiply(int num1, int num2)
{
	int tmp;

	tmp = num1 * num2;
	printf("%d * %d = %d\n", num1, num2, tmp);

	return; 
}

void divide(int num1, int num2)
{
	int tmp;

	tmp = num1 / num2;
	printf("%d / %d = %d\n", num1, num2, tmp);

	return; 
}
