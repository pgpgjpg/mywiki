#include <stdio.h>
#include <string.h>

char* mygets();

int main()
{
	char *str = NULL;
	str = mygets();
	puts(str);
	printf("%ld\n", strlen(str));

	return 0;
}

char* mygets()
{
	char ch;
	static char str[80];
	int count = 0;
	int size = sizeof(str)/sizeof(str[0]);

	while(1){
		char c = getchar();

		if(count >= size)
			break;
		if(c == '\n'){
			str[count] = '\0';
			break;
		}
		str[count++] = c;
	}

	return str;
}
