#include <stdio.h>
#include <string.h>

int main()
{
	char str[50] = "12345";

	strncat(str, "ab", 3);
	printf("%s****\n", str);

	return 0;
}
