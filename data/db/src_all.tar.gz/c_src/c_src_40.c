#include <stdio.h>

int main()
{
	printf("%.1lf\n", 1e6);
	printf("%.7lf\n", 3.14e-05);
	printf("%le\n", 0.0000314);
	printf("%.2le\n", 0.0000314);
}
