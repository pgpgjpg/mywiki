#include <stdio.h>
#include <stdlib.h>

struct ARRAY{
	int pos;	// index of array
	int size;	// size of array
	int *array;	// start address
};

int create_array(struct ARRAY**);
int add_array(struct ARRAY*, int);
int get_array(struct ARRAY*, int, int*);
int destroy_array(struct ARRAY*);

int main(int argc, char *argv[])
{
	struct ARRAY *arr = NULL;
	int val;

	// allocate of array memory
	create_array(&arr);

	// Enter values
	if(argc != 2){
		printf("You must enter number of room\n");
		return 1;
	}

	for(int i = 0; i < atoi(argv[1]); ++i){
		if(!add_array(arr, i)){
			printf("can not write in array\n");
			return 1;
		}
	}
	
	// Get value and print
	for(int i = 0; i < atoi(argv[1]); ++i){
		get_array(arr ,i, &val);
		printf("array[%d] : %d\n", i, val);
	}
	
	// free for allocated memory
	destroy_array(arr);
	

	return 0;
}

int create_array(struct ARRAY **input_array)
{
	struct ARRAY *p;

	p = (struct ARRAY*)malloc(sizeof(struct ARRAY));
	if(p == NULL){
		printf("can not allocate struct ARRAY\n");
		return 0;
	}
	p->pos = 0;
	p->size = 5;
	p->array = (int*)malloc(sizeof(int)*p->size);
	if(p->array == NULL){
		printf("can not allocate p->array\n");
		return 0;
	}

	*input_array = p;

	// success
	return 1;
}

int add_array(struct ARRAY* input_array, int val)
{
	if(input_array->pos >= input_array->size){
		int buffer = 5;
		input_array->array = (int*)realloc(input_array->array, sizeof(int)*(input_array->size += buffer));	


		printf("Size is exceeded, So I added %d rooms more in array\n", buffer);
		printf("Current size is %d\n", input_array->size);
	}
	
	input_array->array[input_array->pos++] = val;

	return 1;
}

int get_array(struct ARRAY* input_array, int idx, int* res)
{
	*res = *(input_array->array + idx);
}

int destroy_array(struct ARRAY* input_array)
{
	free(input_array->array);
	input_array->array = NULL;
	free(input_array);
	input_array = NULL;
	return 1;
}
