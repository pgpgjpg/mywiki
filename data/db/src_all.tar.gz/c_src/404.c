#include <stdio.h>

int main()
{
	char* ptr[3];
	int n1, n2, n3;

	ptr[0] = "dog";
	ptr[1] = "cat";
	ptr[2] = "horse";
	
	/*
	for(int i = 0; i < 3; ++i)
		//*ptr[i] = 10*i;
		scanf("%d", ptr[i]);
	*/
	
	for(int i = 0; i < 3; ++i)
		printf("%c ", *ptr[i]);
	printf("\n");

	return 0;
}
