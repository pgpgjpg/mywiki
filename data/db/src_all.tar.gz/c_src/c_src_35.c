#include <stdio.h>

int main()
{
    printf("%d을 %d로 나누면 %lf입니다\n", 1, 2, 0.5);

    return 0;
}