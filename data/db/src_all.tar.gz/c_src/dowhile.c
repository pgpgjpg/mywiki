#include <stdio.h>
#include <stdlib.h>

int main()
{
	int menu;

	do{
		printf("1. 입력 \n");
		printf("2. 출력 \n");
		printf("9. 종료 \n");
		printf("select : ");
		scanf("%d", &menu);

		switch(menu){
		case 1 : 
			printf("select 1\n\n");
			break;
		case 2 : 
			printf("select 2\n\n");
			break;
		case 9 : 
			printf("select 9\n\n");
			exit(0);
			break;
		default :
			printf("wrong select\n\n");
			break;
		}
	}while(1);

	return 0;
}

