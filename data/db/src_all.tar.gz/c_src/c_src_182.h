// 함수 선언
void add(int num1, int num2);
void sub(int num1, int num2);
void multiply(int num1, int num2);
void divide(int num1, int num2);
