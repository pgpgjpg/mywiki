#include <stdio.h>
#include <string.h>

void reverse(char *str, int size);

int main()
{
	char str[80];
	int size = sizeof(str)/sizeof(str[0]);

	// Enter string
	fgets(str, size, stdin);
	str[strlen(str) - 1] = '\0';
	
	// reverse function
	reverse(str, size);

	// print
	printf("%s\n", str);

	return 0;
}

void reverse(char *str, int size)
{
	char tmp[size];
	int len = strlen(str);

	// copy str to tmp 
	strcpy(tmp, str);
	
	// reverse
	for(int i = 0; i < len; ++i){
		str[i] = tmp[len - 1 - i];
	}
}
