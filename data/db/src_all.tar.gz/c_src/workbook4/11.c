#include <stdio.h>
#include <string.h>

int main()
{
	char colors[20][20];
	char res[20][20];
	int idx = 0;

	// Enter 3 colors
	while(1){
		printf("Enter color --> ");
		fgets(colors[idx], sizeof(colors[idx]), stdin);
		
		if(strcmp(colors[idx], "exit\n") == 0){
			break;
		}
		else{
			colors[idx][strlen(colors[idx]) - 1] = '\0';
		}
		++idx;
	}

	// sorting
	for(int i = 0; i < idx; ++i){
		int rank = 0;		

		for(int j = 0; j < idx; ++j){
			if(strcmp(colors[i], colors[j]) > 0) ++rank;
		}
		
		strcpy(res[rank], colors[i]);
	}


	// print
	for(int i = 0; i < idx; ++i){
		printf("%s ", res[i]);
	}
	printf("\n");




	return 0;
}
