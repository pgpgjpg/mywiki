#include <stdio.h>

void add_array(int *parr1, int *parr2, int size);

int main()
{
	int arr1[100], arr2[100], idx=0, size;
	// Enter value in array

	printf("Enter size of array --> ");
	scanf("%d", &size);

	while(1){
		printf("Enter value for arr1 and arr2 --> ");
		scanf("%d%d", arr1+idx, arr2+idx);
		++idx;

		if(idx == size)
			break;
	}

	// add_array function
	add_array(arr1, arr2, size);

	return 0;
}

void add_array(int *parr1, int *parr2, int size)
{
	int	addArr[size];

	// add , print
	for(int i = 0; i < size; ++i){
		addArr[i] = parr1[i] + parr2[i]; 
		printf("arr1[%d] + arr2[%d] = %d\n", i, i, addArr[i]);
	}

}
