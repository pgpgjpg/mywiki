#include <stdio.h>
#include <stdlib.h>

int input_score(); // return the number of students
int output_score(int nStudent); // return the average

int total = 0; // total score


int main()
{
	int menu, nStudent;

	do{
		printf("1. 점수 입력\n");
		printf("2. 평균점수, 학생 수 출력\n");
		printf("9. 종료 \n");
		printf("select : ");
		scanf("%d", &menu);

		switch(menu){
		case 1 : 
			nStudent = input_score();
			break;
		case 2 : 
			output_score(nStudent);
			break;
		case 9 : 
			exit(0);
			break;
		default :
			printf("wrong select\n\n");
			break;
		}
	}while(1);

	return 0;
}

int input_score()
{
	int score = 0, nStudent = -1;

	do{
		total += score;
		printf("If you want to exit, please enter negative number\n");
		printf("Enter the score of student #%d --> ", ++nStudent+1);
		
		scanf("%d", &score);
	}while(score >= 0);

	return nStudent;
}

int output_score(int nStudent)
{
	double avg;
	if(nStudent != 0) avg = (double) total/nStudent;
	else avg =  0;
	printf("The number of students : %d\nAverage is %.1lf\n", nStudent, avg);
	return avg;
}
