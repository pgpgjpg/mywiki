#include <stdio.h>

int main()
{
	int num = 1;

	while(num <= 10)
	{
		num++;
		if(num == 5)
			continue;
		printf("%d\n", num);
	}

	return 0;
}
