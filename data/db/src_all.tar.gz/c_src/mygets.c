#include <stdio.h>

void mygets(char *str, int size);

int main()
{
	char name[80];
	int size = sizeof(name)/sizeof(name[0]);

	mygets(name, size);
	puts(name);
	//printf("%s\n", name);

	return 0;
}

void mygets(char *str, int size)
{
	int count = 0;
	printf("%ld\n", sizeof(str)/sizeof(str[0]));
	while(1){
		char c = getchar();

		if(count >= size)
			break;
		if(c == '\n'){
			str[count] = '\0';
			break;
		}
		str[count++] = c;
	}
}
