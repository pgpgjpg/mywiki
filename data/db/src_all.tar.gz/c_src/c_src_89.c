#include <stdio.h>

int main()
{
	int a, b;
	a = b = 5;
	int pre, post;

	pre = (++a) * 3;
	post = (b++) * 3;

	printf("Inital value : a = %d, b = %d\n", a, b);
	printf("Prefix : (++a) * 3 = %d, Postfix : (b++) * 3 = %d\n", pre, post);

	return 0;
}
