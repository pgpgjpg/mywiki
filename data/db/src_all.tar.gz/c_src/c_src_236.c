#include <stdio.h>

int main()
{
	char ch, *cp;
	int i, *ip;

	printf("addr of ch : %p\n", &ch);
	printf("addr of i : %p\n", &i);
	
	cp = &ch;
	ip = &i;

	printf("addr of ch : %p\n", cp);
	printf("addr of i : %p\n", ip);

	i = 123;
	ch = 'A';
	printf("i : %d\n", *ip);
	printf("ch : %c\n", *cp);

	*ip = 456;
	*cp = 'B';
	printf("i : %d\n", *ip);
	printf("ch : %c\n", *cp);

	return 0;
}
