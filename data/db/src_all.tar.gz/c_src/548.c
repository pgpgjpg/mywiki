#include <stdio.h>

int main()
{
	typedef struct{
		int num;
		float fnum;
		char str[10];
	}DATA;

	DATA data[2] = {{10, 1.45, "c lang"}, {20, 453.78, "c++ lang"}};
	
	FILE* fp;
	if((fp = fopen("data", "wb")) == NULL){
		printf("error : fopen\n");
		return 1;
	}

	fwrite(data, sizeof(DATA), 2, fp);
	fclose(fp);
	

	DATA data2[2];
	if((fp = fopen("data", "rb")) == NULL){
		printf("error : fopen\n");
		return 1;
	}

	fread(data2, sizeof(DATA), 2, fp);
	printf("%d %.2f %s\n", data2[0].num, data2[0].fnum, data2[0].str);
	printf("%d %.2f %s\n", data2[1].num, data2[1].fnum, data2[1].str);
	fclose(fp);

	return 0;
}

