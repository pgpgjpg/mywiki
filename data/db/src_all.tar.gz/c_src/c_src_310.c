#include <stdio.h>

int main()
{
	int num;

	while(1){
		if(scanf("%d", &num) != 1)
			goto EXIT;
		if(num == 0)
			break;
	}
	printf("normal exit\n");
	return 0;

EXIT:
	printf("Incorrect Input\n");
	return 1;
}
