#include <stdio.h>

int main()
{
	char* p = "hi";

	printf("%x %x %x\n", *(p), *(p + 1), *(p + 2)) ;


	return 0;
}
