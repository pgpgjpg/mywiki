#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char temp[80];
	char *sp[10];
	int i;

	printf("%ld\n", sizeof(sp));

	for(i = 0; i < 9; ++i){
		printf("string : ");
		fgets(temp, 80, stdin);
		temp[strlen(temp) - 1] = '\0';
		if(strcmp(temp, "end") == 0) break;
		sp[i] = (char *)malloc(strlen(temp) + 1);
		if(sp[i] == NULL) return 1;
		strcpy(sp[i], temp);
	}
	
	for(int j = 0; j < i; ++j){
		printf("%s\n", sp[j]);
	}

	return 0;
}
