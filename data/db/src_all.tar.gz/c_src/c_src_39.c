#include <stdio.h>

int main()
{
	printf("%o\n", 12);
	printf("%x\n", 12);
	printf("%X\n", 12);
}
