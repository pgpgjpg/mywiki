#include <stdio.h>

int main()
{
	double celsius, fahrenheit;

	// 화씨 입력
	printf("Enter celsius : ");
	scanf("%lf", &celsius);

	// 섭씨로 변환
	fahrenheit = (celsius * 1.8) + 32;

	printf("Fahrenheit : %.2lf\n", fahrenheit);

	return 0;
}
