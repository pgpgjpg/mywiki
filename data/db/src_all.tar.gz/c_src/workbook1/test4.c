#include <stdio.h>

// After getting three numbers, output max number

int main()
{
	int num1, num2, num3, maxNum;
 	
	printf("Enter three numbers : ");
	scanf("%d%d%d", &num1, &num2, &num3);


	(num1 >= num2) ? ((num1 >= num3) ? (maxNum = num1) : (maxNum = num3)) : ((num2 >= num3) ? (maxNum = num2) : (maxNum = num3));


	printf("Max value is %d\n", maxNum);

	return 0;
}
