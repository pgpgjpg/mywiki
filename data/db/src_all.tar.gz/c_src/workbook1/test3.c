#include <stdio.h>

int main()
{
	double feet, meter;
	char order;

	printf("choose converting type\n");
	printf("1. meter to feet\n2. feet to meter\n");
	scanf("%c", &order);

	if(order == '1'){
		printf("Enter value : ");
		scanf("%lf", &meter);

		feet = meter*3.2808;
		printf("%.2lf meter -> %.2lf feet\n", meter, feet);
	}else if(order == '2'){
		printf("Enter value : ");
		scanf("%lf", &feet);

		meter = feet/3.2808;
		printf("%.2lf feet -> %.2lf meter\n", feet, meter);
	}else printf("You choose wrong command\n");

	return 0;
}
