#include <stdio.h>

int main()
{
	int x, y, z;
	int xx;

	x = -3 * 4 % -6 / 5;
	printf("1. x = %d\n", x);

	x = 2; y = 1; z = 0;
	x = x && y || z;
	printf("2. x = %d\n", x);

	x = y = z = 1;
	z += -x++ + ++y;
	printf("3. x = %d, y = %d, z = %d\n", x, y, z);

	return 0;
}
