#ifndef _MENU_LINKEDLISTH_
#define _MENU_LINKEDLISTH_
struct person{
    char name[20];
    int age;
    float height;
    struct person* nptr;
};

void load(struct person **, struct person **);
void save(struct person *);
void input(struct person **HEAD, struct person **TAIL);
void print(struct person *HEAD);
void search(struct person *HEAD);
void delete(struct person **HEAD, struct person **TAIL);
void destroy(struct person **HEAD);
#endif
