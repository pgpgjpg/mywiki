#include <stdio.h>

int main()
{
	int *a;

	printf("%p\n", a);

	return 0;
}

