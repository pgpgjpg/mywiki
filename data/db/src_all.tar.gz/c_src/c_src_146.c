#include <stdio.h>

int main()
{
	int num1, num2;
	char op;

	scanf("%c", &op);
	scanf("%d %d", &num1, &num2);

	switch(op){
	case '+' :
		printf("+ : %d\n", num1 + num2);
		break;
	case '-' :
		printf("- : %d\n", num1 - num2);
		break;
	case 'x' :
		printf("* : %d\n", num1 * num2);
		break;
	case '/' :
		printf("/ : %d\n", num1 / num2);
		break;
	default :	
		break;
	}

	return 0;
}

