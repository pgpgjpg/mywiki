#include <stdio.h>

int main()
{
	int a = 10;
	double b = 3.4;

	long l = 10;
	long long ll = 100;
	long double ld = 1000.1;


	printf("int형 변수의 크기 : %d\n", sizeof(a));
	printf("double형 변수의 크기 : %d\n", sizeof(b));
	printf("정수형 상수의 크기: %d\n", sizeof(10));
	printf("수식의 결과값의 크기: %d\n", sizeof(1.5+4.3));
	printf("char 자료형의 크기 : %d\n", sizeof(char));



	printf("long 자료형의 크기 : %d\n", sizeof(l));
	printf("long long 자료형의 크기 : %d\n", sizeof(ll));
	printf("long double 자료형의 크기 : %d\n", sizeof(ld));


	return 0;
}
