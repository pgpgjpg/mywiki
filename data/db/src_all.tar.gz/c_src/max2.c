#include <stdio.h>

// After getting two numbers, output max number

int main()
{
	int num1, num2;

	printf("Enter two numbers : ");
	scanf("%d%d", &num1, &num2);

	num1 > num2 ? printf("Max value is %d\n", num1) : printf("Max value is %d\n", num2);

	return 0;
}
