#include <stdio.h>
#include <string.h>

void myStrcpy(char *dest, const char *src);
void myStrncpy(char *dest, const char *src, int n);

int main()
{
	char name[80];

	myStrcpy(name, "Jo Pyeong Geun");
	puts(name);
	printf("length : %ld\n", strlen(name));
	
	myStrncpy(name, "Jo Pyeong Geun", 5);
	puts(name);
	printf("length : %ld\n", strlen(name));

	return 0;
}

void myStrcpy(char *dest, const char *src)
{	
	int cnt = 0;
	char c;

	while(1){
		c = src[cnt];
		dest[cnt] = c;

		if(c == '\0')
			break;

		++cnt;
	}
}

void myStrncpy(char *dest, const char *src, int n)
{	
	int cnt = 0;
	char c;

	while(1){
		c = src[cnt];
		dest[cnt] = c;

		if(cnt == n){
			dest[cnt] = '\0';
			break;
		}

		if(c == '\0')
			break;

		++cnt;
	}
}
