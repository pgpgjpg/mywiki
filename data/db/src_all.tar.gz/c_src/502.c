#include <stdio.h>

int main()
{
	union utype{
		short num;
		int inum;
		char ch[4];
	}u;

	u.ch[0] = 0xFF;
	u.ch[1] = '\0';
	u.ch[2] = '\0';
	u.ch[3] = '\0';
	printf("size : %ld\n", sizeof(union utype));
	printf("u.num = %x, u.inum : %x\n", u.num, u.inum);

	return 0;
}
