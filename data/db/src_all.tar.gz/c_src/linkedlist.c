#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"

int main()
{
	int choice;
	struct person *HEAD, *TAIL;

	HEAD = TAIL = NULL;
	load(&HEAD, &TAIL);

    do{
        printf("1. 입력 \n");
        printf("2. 출력 \n");
        printf("3. 검색 \n");
        printf("4. 삭제 \n");
        printf("9. 종료 \n");
        printf("select : ");
        scanf("%d", &choice);
		getchar();

        switch(choice){
        case 1 :
            printf("select 1\n\n");
			input(&HEAD, &TAIL);
            break;
        case 2 :
            printf("select 2\n\n");
			print(HEAD);
            break;
        case 3 :
            printf("select 3\n\n");
			search(HEAD);
            break;
        case 4 :
            printf("select 4\n\n");
			delete(&HEAD, &TAIL);
            break;
        case 9 :
            printf("select 9\n\n");
			save(HEAD);
			destroy(&HEAD);
            exit(0);
            break;
        default :
            printf("wrong select\n\n");
            break;
        }
    }while(1);

	return 0;
}

void input(struct person **HEAD, struct person **TAIL)
{
	struct person *tmp;

	tmp = (struct person*)malloc(sizeof(struct person));
	if(tmp == NULL){
		printf("can not allocate tmp\n");\
		return;
	}

	tmp->nptr = NULL;
	printf("Enter name : ");
	fgets(tmp->name, 20, stdin);
	tmp->name[strlen(tmp->name) - 1] = '\0';

	printf("Enter age : ");
	scanf("%d", &tmp->age);
	printf("Enter height : ");
	scanf("%f", &tmp->height);

	if(*HEAD == NULL){
		*HEAD = *TAIL = tmp;
	}
	else{
		(*TAIL)->nptr = tmp;
		*TAIL = tmp;
	}
}

void print(struct person *HEAD)
{
	struct person *tmp;

	tmp = HEAD;

	while(tmp){		
		printf("name : %s\nheight : %.2f\nage : %d\n\n", tmp->name, tmp->height, tmp->age);

		tmp = tmp->nptr;
	}
}

void search(struct person *HEAD)
{
	struct person *tmp;
	char name[20];

	tmp = HEAD;

	printf("Enter name that you want to find : ");
	fgets(name, 20, stdin);
	name[strlen(name) - 1] = '\0';
	
	while(tmp){
		if(!strcmp(tmp->name, name)){
			printf("name : %s\nheight : %.2f\nage : %d\n\n", tmp->name, tmp->height, tmp->age);	
			break;
		}
		tmp = tmp->nptr;
	}
	if(tmp == NULL)
		printf("No such name\n");
}

void delete(struct person **HEAD, struct person **TAIL)
{
	struct person *tmp, *before;
	char name[20];

	tmp = *HEAD;

	printf("Enter name that you want to delete : ");
	fgets(name, 20, stdin);
	name[strlen(name) - 1] = '\0';

	while(tmp){
		if(!strcmp(tmp->name, name)){
			if(tmp == *HEAD){
				*HEAD = tmp->nptr;
				break;
			}else if(tmp->nptr == NULL){
				before->nptr = NULL;
				*TAIL = before;
				break;
			}else{
				before->nptr = tmp->nptr;
				break;
			}
		}
		before = tmp;
		tmp = tmp->nptr;
	}
	if(!tmp)
		printf("Failure\n");
	else
		printf("Success\n");
	free(tmp);
	tmp = NULL;
}

void destroy(struct person **HEAD)
{
	struct person *tmp;
	while(*HEAD){
		tmp = *HEAD;
		*HEAD = (*HEAD)->nptr;
		free(tmp);
		tmp = NULL;
	}
}

void load(struct person **HEAD, struct person **TAIL)
{
	FILE *fp;
	struct person *tmp;

	if((fp = fopen("linkedlist_log.txt", "r")) == NULL){
		printf("error : There is not file\n");
		return;
	}

	while(1){
		tmp = (struct person*)malloc(sizeof(struct person));
		if(tmp == NULL){
			printf("error : can not allocate tmp\n");
			return;
		}
		fread(tmp, sizeof(struct person), 1, fp);
		if(feof(fp) != 0) break;
		if(*HEAD == NULL){
			*HEAD = *TAIL = tmp;
		}
		else{
			(*TAIL)->nptr = tmp;
			*TAIL = tmp;
		}
	}
	fclose(fp);
}

void save(struct person *HEAD)
{
	FILE *fp;
	struct person *tmp;
	/*
	if((fp = fopen("linkedlist_log.txt", "w"))==NULL){
		printf("error : save\n");
		return;
	}
	tmp = HEAD;
	fwrite(tmp, sizeof(struct person), 1, fp);
	tmp = tmp->nptr;
	fclose(fp);
	*/

	if((fp = fopen("linkedlist_log.txt", "w"))==NULL){
		printf("error : save\n");
		return;
	}

	tmp = HEAD;

	while(tmp){		
		fwrite(tmp, sizeof(struct person), 1, fp);

		tmp = tmp->nptr;
	}

	fclose(fp);
}
