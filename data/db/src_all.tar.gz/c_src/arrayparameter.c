#include <stdio.h>

void input_array(int *pa, int array_size);
void print_array(int *pa, int array_size);
void find_max(int pa[], int array_size, int *pMaxVal);

int main()
{
	int num[5], maxVal;

	input_array(num, sizeof(num)/sizeof(num[0]));
	print_array(num, sizeof(num)/sizeof(num[0]));
	find_max(num, sizeof(num)/sizeof(num[0]), &maxVal);
	printf("max value is %d\n", maxVal);


	return 0;
}

void input_array(int *pa, int array_size)
{
	for(int i = 0; i < array_size; ++i){
		printf("array[%d/%d] = ? ", i, array_size - 1);
		scanf("%d", pa + i);
	}

	printf("*(pa+5) = %d\n", *(pa + 5));
	printf("*(pa+6) = %d\n", *(pa + 6));

	printf("It is done\n");
}

void print_array(int *pa, int array_size)
{
	for(int i = 0; i < array_size; ++i){
		printf("%d\t", *(pa + i));
	}

	printf("\n");
}

void find_max(int pa[], int array_size, int *pMaxVal)
{
	*pMaxVal = pa[0];

	printf("sizeof(np[]) = %ld\n", sizeof(pa));

	for(int i = 1; i < 5; ++i){
		if(*pMaxVal < *(pa + i))
			*pMaxVal = *(pa + i);
	}
}
