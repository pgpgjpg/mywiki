#include <stdio.h>
#include <string.h>

int main()
{
	char str1[80], str2[80];

	printf("input string : ");
	fgets(str1, 79, stdin);
	printf("%ld\n", strlen(str1));
	str1[strlen(str1) - 1] = '\0';
	printf("%ld\n", strlen(str1));
	
	if(strcmp(str1, "...") == 0)
		strcpy(str2, "good morning");
	else
		strcpy(str2, str1);

	printf("str1 : %s\n", str1);
	printf("str2 : %s\n", str2);

	//for(int i = 0; i < 80; ++i)
	//	printf("%d : %c\n", i+1,  str1[i]);

	return 0;
}

