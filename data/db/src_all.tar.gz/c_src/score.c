// 성적처리프로그램
// 90~100 : A
// 80~89 : B
// 70~79 : C
// 60~69 : D
// ~59 : F
#include <stdio.h>

int main()
{
	int score;

	while(1){
		printf("Enter your score --> ");
		scanf("%d", &score);
		if(score < 0){ 
			printf("The score %d is invalid score\n", score);  
			break;
		}
		
		switch(score/10){
		case 10 :
		case 9 :
			printf("Your grade is 'A'\n");
			break;
		case 8 :
			printf("Your grade is 'B'\n");
			break;
		case 7 :
			printf("Your grade is 'C'\n");
			break;
		case 6 :
			printf("Your grade is 'D'\n");
			break;
		default :
			printf("Your grade is 'F'\n");
			break;
		}	
	}

	return 0;
}

