#include <stdio.h>

int main()
{
	printf("%d, %d\n", 10/3, 10%3);
	printf("%lf, %d\n", (double)10/3, 10%3);
	printf("%lf, %d\n", (double)(10/3), 10%3);

	return 0;
}
