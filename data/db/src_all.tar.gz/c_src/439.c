#include <stdio.h>

void add(int, int);
void sub(int, int);

int main()
{
	int n1, n2, select;
	void (*fptr[2])(int, int);

	fptr[0] = add;
	fptr[1] = sub;
	
	printf("n1 n2 : ");
	scanf("%d %d", &n1, &n2);
	printf("select (1. add 2.sub) --> ");
	scanf("%d", &select);

	if(select != 1 && select != 2)	
		printf("Wrong selection\n");
	else
		fptr[select - 1](n1, n2);

	return 0;
}

void add(int n1, int n2)
{
	printf("%d + %d = %d\n", n1, n2, n1 + n2);
}

void sub(int n1, int n2)
{
	printf("%d - %d = %d\n", n1, n2, n1 - n2);
}
