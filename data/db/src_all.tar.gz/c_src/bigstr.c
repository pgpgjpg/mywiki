// bigstr 배열에 입력하는 문자열을 추가, "..." 입력될 때까지
// 배열 크기가 넘어가는 일이 생겼을 때, bigstr 출력
#include <stdio.h>
#include <string.h>

int main()
{
	char bigstr[10]={'\0'};
	int strSize = sizeof(bigstr)/sizeof(bigstr[0]);
	
	while(1){
		char tmp[80];

		printf("문자열을 입력하세요.\n");
		printf("추가를 멈추고 싶다면, \"...\"을 입력하세요.\n");
		
		fgets(tmp, 80, stdin);

		if(strlen(bigstr) + strlen(tmp) > strSize){
			printf("%s\n", bigstr);
			break;
		}

		if(!strcmp("...\n", tmp)){
			printf("%s\n", bigstr);
			break;
		}
		tmp[strlen(tmp) - 1] = '\0';
		strcat(bigstr, tmp);
		strcat(bigstr, " ");
	}

	return 0;
}
