#include <stdio.h>

int main()
{
	int res;
	char ch;

	while(1){
		res = scanf("%c", &ch);
		if(res == -1){
			printf("Ctrl + z\n");
			break;
		}

		printf("%c ", ch);
	}

	return 0;
}
