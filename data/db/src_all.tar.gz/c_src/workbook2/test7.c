#include <stdio.h>

int main()
{
	int answer, num, cnt;

	cnt = 0;
	srand(time(NULL));

	while(1){
		// 정답 입력
		printf("answer ? ");
		scanf("%d", &num);
		// 난수 생성
		answer = rand()%21;
		++cnt;
		printf("Answer : %d\n\n", answer);

		// 입력한 값과 생성된 난수가 같을 경우
		if(answer == num){
			printf("Success\n");
			break;
		}
		if(cnt == 5){
			printf("Fail\n");
			break;
		}
	}

	return 0;
}

