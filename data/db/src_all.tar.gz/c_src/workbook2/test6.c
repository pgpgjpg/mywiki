#include <stdio.h>

int main()
{
	int num, sum, cnt;
	char command;
	float avg;

	sum = cnt = 0;

	while(1){
		// 정수 입력
		printf("입력 : ");
		scanf("%d", &num);
		getchar();

		// 입력값이 0일 경우 예외처리
		if(num != 0){
			sum += num;
			cnt++;
		}

		// 추가 입력 여부 확인
		printf("입력을 계속 하시겠습니까? (y/n) ");
		scanf("%c", &command);

		if(command ==  'y')
			continue;
		else if(command == 'n'){
			avg = sum/cnt;
			break;
		}
	}

	printf("합 : %d, 평균 : %.2f\n", sum, avg);

	return 0;
}
