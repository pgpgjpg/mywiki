#include <stdio.h>

int main()
{
	short sint;
	int intNum = 33000, i;
	
	printf("intNum = %d\n", intNum);
	sint = intNum;
	printf("sint = %d\n", sint);


	for(i = 0; i < 128; ++i)
		printf("test %d : %c\n", i, i);
}
