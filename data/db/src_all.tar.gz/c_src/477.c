#include <stdio.h>
#include <string.h>
#include <stdlib.h>


struct person{
	char name[20];
	char gender;
	int age;
};

void print_person(struct person *ptr);


int main()
{


	struct person p1, p2, p3[5], *ptr;
/*
	printf("name : ");
	fgets(p1.name, 20, stdin);
	p1.name[strlen(p1.name) - 1] = '\0';
	 
	printf("age : ");
	scanf("%d", &p1.age);

	printf("p1.name : %s\np1.age : %d\n", p1.name, p1.age);

	printf("size : %ld\n", sizeof(struct person));
*/
	ptr = p3;

	for(int i = 0; i < 5; ++i){
		printf("name : ");
		fgets(ptr->name, 20, stdin);
		ptr->name[strlen(ptr->name) - 1] = '\0';

		printf("age : ");
		scanf("%d", &ptr->age);
		getchar();

		++ptr;
	}

	print_person(p3);

	return 0;
}


void print_person(struct person *ptr)
{
	for(int i = 0; i < 5; ++i)
		printf("ptr->name : %s\nptr->age : %d\n", ptr[i].name, ptr[i].age);
}
