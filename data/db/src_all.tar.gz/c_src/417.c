#include <stdio.h>

int main()
{
	char ch, *cp, **mp;

	cp = &ch;
	mp = &cp;
	ch = 'A';
	
	*cp = 'B';
	**mp = 'C';
	printf("%c %c %c\n", ch, *cp, **mp);

	

	return 0;
}
