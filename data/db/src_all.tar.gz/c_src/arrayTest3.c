#include <stdio.h>

int main()
{
	int A[3] = {1, 2, 3};
	int B[10];
	int A_size, B_size;

	A_size = sizeof(A)/sizeof(A[0]);
	B_size = sizeof(B)/sizeof(B[0]);

	for(int i = 0; i < B_size; ++i)
		B[i] = A[i%A_size];

	for(int i = 0; i < B_size; ++i)
		printf("B[%d] = %d\n", i,  B[i]);
	
	return 0;
}
