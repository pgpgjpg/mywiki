#include <stdio.h>
#include <stdlib.h>

int main()
{
	struct node{
		int id;
		struct node* next;
	}*tmp, *HEAD, *TAIL;

	HEAD = TAIL = NULL;

	while(1){
		tmp = (struct node*)malloc(sizeof(struct node));
		if(tmp == NULL){
			printf("error : can not allocate memory for temp\n");
			return 1;
		}

		printf("id : ");
		scanf("%d", &tmp->id);
		if(!tmp->id)
			break;

		tmp->next = NULL;
		
		if(HEAD == NULL){
			HEAD = TAIL = tmp;
		}else{
			TAIL->next = tmp;
			TAIL = tmp;
		}
		
	}
	tmp = HEAD;
	while(tmp != NULL){
		printf("%d\n", tmp->id);
		tmp = tmp->next;
	}

	int id;
	printf("search id : ");
	scanf("%d", &id);

	
	tmp = HEAD;
	while(tmp){
		if(id == tmp->id){
			printf("Found\n");
			break;
		}
		tmp = tmp->next;
	}
	if(tmp == NULL)
		printf("No such ID\n");


	struct node *before;
	
	tmp = before = HEAD;

	printf("delete id : ");
	scanf("%d", &id);

	while(tmp){
		if(id == tmp->id){
			// when tmp is head
			if(tmp == HEAD){
				HEAD = tmp->next;
				free(tmp);
				tmp = NULL;
			}else if(tmp->next == NULL){	// when tmp is tail
				TAIL = before;
				TAIL->next = NULL;
				free(tmp);
				tmp = NULL;
			}else{ // when tmp is between head and tail
				before->next = tmp->next;
				free(tmp);
				tmp = NULL;
			}

			printf("%d is deleted\n\n", id);
			break;
		}
		before = tmp;
		tmp = tmp->next;
	}

	tmp = HEAD;
	while(tmp != NULL){
		printf("%d\n", tmp->id);
		tmp = tmp->next;
	}


	return 0;
}
