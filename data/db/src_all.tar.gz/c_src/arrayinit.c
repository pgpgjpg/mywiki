#include <stdio.h>

int main()
{
	int intarray1[3] = {1, 2, 3};
	int intarray2[] = {1, 2, 3, 4, 5};
	char chararray[6] = {'s', 'e', 'o', 'u', 'l', '\0'};
	double doublearray[3] = {1.1, 2.1, 3.1};
/*
	for(int i = 0; i < 10; ++i){
		printf("%c ", chararray[i]); 
	}
*/
	printf("%s\n", chararray);
	printf("%ld\n", sizeof(intarray2)/sizeof(intarray2[0]));


	return 0;
}
