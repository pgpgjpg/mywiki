#include <stdio.h>
/*
int main()
{
	int a = 10;
	double b = 3.5;
	void *vp;

	vp = &a;
	printf("a : %d\n", *(int*)vp);

	vp = &b;
	printf("b : %.2lf\n", *(double*)vp);

	return 0;
}
*/

int main()
{
	char ch, *cp;
	unsigned int i, *ip;
	void *p;

	cp = &ch;
	ip = &i;

	ch = 'a';
	i = 0x0fffffff;

	p = cp;
	printf("p = %p, cp = %p\n", p, cp);
	printf("*p = %c, *cp = %c\n", *(char*)p, *cp);

	p = ip;
	printf("ip : %d\n", *(int*)p);

	return 0;
}
