#include <stdio.h>
#include <string.h>

void swap(char*, void*, void*);

int main()
{
	int ia, ib;
	double da, db;
	char ca, cb;
	long la, lb;
	void (*pf)(char*, void*, void*) = swap;

	// swap for int
	ia = 1, ib = 2;
	printf("Int ia : %d, ib : %d\n", ia, ib);
	pf("int", &ia, &ib);
	printf("Int ia : %d, ib : %d\n", ia, ib);

	// swap for double
	da = 1, db = 2;
	printf("Double da : %.2lf, ib : %.2lf\n", da, db);
	pf("double", &da, &db);
	printf("Double da : %.2lf, ib : %.2lf\n", da, db);

	// swap for char
	ca = 'a', cb = 'b';
	printf("Char da : %c, ib : %c\n", ca, cb);
	pf("char", &ca, &cb);
	printf("Char da : %c, ib : %c\n", ca, cb);
	
	// Exception
	la = 1, lb = 2;
	swap("long", &la, &lb);

	return 0;
}

void swap(char *str, void *a, void *b)
{
	if(!strcmp(str, "int")){
		int tmp;

		tmp = *(int*)a;
		*(int*)a = *(int*)b;
		*(int*)b = tmp;

	}else if(!strcmp(str, "double")){
		double tmp;

		tmp = *(double*)a;
		*(double*)a = *(double*)b;
		*(double*)b = tmp;

	}else if(!strcmp(str, "char")){
		char tmp;

		tmp = *(char*)a;
		*(char*)a = *(char*)b;
		*(char*)b = tmp;

	}else{
		printf("%s is not supported datatype in swap() function\n", str);
	}
}
