#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct student{
	char name[20];
	float scoreLinux;
	float scoreC;
	float scoreCpp;
	float avg;
	struct student *nptr;
};

void createNode(struct student**,struct student**);
void print(struct student *);

int main()
{
	struct student *HEAD, *TAIL;

	HEAD = TAIL = NULL;

	do{
		int choice;
		printf("1. 입력 \n");
        printf("2. 출력 \n");
        printf("9. 종료 \n");
        printf("select : ");
        scanf("%d", &choice);
		getchar();
        switch(choice){
        case 1 :
            printf("select 1\n\n");
			createNode(&HEAD, &TAIL);
        case 2 :
            printf("select 2\n\n");
			print(HEAD);
            break;
		case 9 : 
			printf("Exit\n");
			exit(0);
        default :
            printf("wrong select\n\n");
            break;
        }
	}while(1);

	return 0;
}

void createNode(struct student **HEAD,struct student **TAIL)
{
	struct student *tmp;

	while(1){
		tmp = (struct student*)malloc(sizeof(struct student));
		tmp->nptr = NULL;
		printf("Name : ");
		fgets(tmp->name, 20, stdin);
		tmp->name[strlen(tmp->name) - 1] = '\0';

		if(!strcmp(tmp->name, "end"))
			break;

		printf("Score Linux : ");
		scanf("%f", &tmp->scoreLinux);
		printf("Score C : ");
		scanf("%f", &tmp->scoreC);
		printf("Score C++ : ");
		scanf("%f", &tmp->scoreCpp);
		getchar();
		tmp->avg = (tmp->scoreLinux + tmp->scoreC + tmp->scoreCpp)/3.;

		

		if(*HEAD == NULL){
			*HEAD = *TAIL = tmp;
		}
		else{
			(*TAIL)->nptr = tmp;
			*TAIL = tmp;
		}
	}
}

void print(struct student *HEAD)
{
	struct student *tmp;
	tmp = HEAD;
	while(tmp){
		printf("name : %s\nLinux : %3.1f\nC : %3.1f\nC++ : %3.1f\nAvg : %3.1f\n\n", tmp->name, tmp->scoreLinux, tmp->scoreC, tmp->scoreCpp, tmp->avg);
		tmp = tmp->nptr;
	}
}
