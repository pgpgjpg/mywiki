#include <stdio.h>

void input_data(int *pa, int *pb);
void swap_data(void);
void print_data(int a, int b);

int a, b;

int main()
{
	input_data(&a, &b);
	swap_data();
	print_data(a, b);

	return 0;
}

void input_data(int *pa, int *pb)
{
	printf("Enter value of a --> ? ");
	scanf("%d", pa);

	printf("Enter value of b --> ? ");
	scanf("%d", pb);
}

void swap_data(void)
{
	int tmp;

	tmp = a;
	a = b;
	b = tmp;
}

void print_data(int a, int b)
{
	printf("a : %d / b : %d\n", a, b);
}
