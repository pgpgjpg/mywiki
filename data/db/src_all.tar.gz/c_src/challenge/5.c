#include <stdio.h>
#include <stdlib.h>

int getDigit(int num);

int main()
{
	char input[1024], oper;
	int res, num1, num2, digit;
	

	printf("사칙연산 입력(정수) : ");
	scanf("%s", input);

	num1 = atoi(input);
	digit = getDigit(num1);
	num2 = atoi(input+(digit+1));
	oper = input[digit];

	printf("num1 : %d, num2 : %d, operate : %c\n", num1, num2, oper);

	if(oper == '+') res = num1 + num2;
	else if(oper == '-') res = num1 - num2;
	else if(oper == '*') res = num1*num2;
	else if(oper == '/') res = num1/num2;
	else{ 
		printf("wrong operate\n");
		return 2;
	}

	printf("%s=%d\n", input, res);	

	return 0;
}


int getDigit(int num)
{
	int i = 0;
	while(num != 0){
		++i;
		num /= 10;
	}

	return i;
}
