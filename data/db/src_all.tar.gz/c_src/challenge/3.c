#include <stdio.h>

int main()
{
	char ch;

	printf("문자입력 : ");
	scanf("%c", &ch);
	printf("%c문자의 아스키 토코드 값은 %d입니다.\n", ch, ch);

	return 0;
}
