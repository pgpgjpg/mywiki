#include <stdio.h>

#define CM2M 0.01

int main()
{
	double weight, height, BMI;

	printf("몸무게(kg)와 키(cm) 입력 : ");
	scanf("%lf%lf", &weight, &height);

	BMI = weight / (height*height*CM2M*CM2M);

	printf("height : %lf\nweight : %lf\nBMI : %lf\n", weight, height, BMI);

	if(BMI >= 20.0 && BMI < 25.0) printf("표준입니다.\n");
	else printf("체추중관리가 필요합니다.\n");

	return 0;
}

