#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void sort(int *arr, int size);
void swap(int *a, int *b);

int main(int argc, char *argv[])
{
	srand(time(NULL));
	
	int size;
	int *input;

	if(argc == 2)
		size = atoi(argv[1]);
	else{
		size = 10;
	}

	input = (int*)malloc(sizeof(int)*size);

	for(int i = 0; i < size; ++i)
		input[i] = rand()%100;
	

	printf("\noriginal array\n");
	for(int i = 0; i < size; ++i)
		printf("%2d ", input[i]);
	printf("\n\n");	
	sort(input, size);
	printf("sorted array\n");
	for(int i = 0; i < size; ++i)
		printf("%2d ", input[i]);
	printf("\n\n");
	return 0;
}

void sort(int *arr, int size)
{
	for(int i = size - 1; i >= 0; --i){
		for(int j = 0; j < i; ++j){
			if(arr[j] > arr[j + 1])
				swap(arr+j, arr+j+1);
		}
	}
}

void swap(int *a, int *b)
{
	int tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}
