#include "15.h"
#include "15.h"


int main()
{
    struct student *HEAD, *TAIL;

    HEAD = TAIL = NULL;

    do{
        int choice;
        printf("1. 입력 \n");
        printf("2. 출력 \n");
        printf("9. 종료 \n");
        printf("select : ");
        scanf("%d", &choice);
        getchar();
        switch(choice){
        case 1 :
            printf("select 1\n\n");
            createNode(&HEAD, &TAIL);
        case 2 :
            printf("select 2\n\n");
            print(HEAD);
            break;
        case 9 :
            printf("Exit\n");
            exit(0);
        default :
            printf("wrong select\n\n");
            break;
        }
    }while(1);

    return 0;
}
