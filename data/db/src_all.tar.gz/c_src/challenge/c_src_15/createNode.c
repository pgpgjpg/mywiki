#include "15.h"

void createNode(struct student **HEAD,struct student **TAIL)
{
    struct student *tmp;

    while(1){
        tmp = (struct student*)malloc(sizeof(struct student));
        tmp->nptr = NULL;
        printf("Name : ");
        fgets(tmp->name, 20, stdin);
        tmp->name[strlen(tmp->name) - 1] = '\0';

        if(!strcmp(tmp->name, "end"))
            break;

        printf("Score Linux : ");
        scanf("%f", &tmp->scoreLinux);
        printf("Score C : ");
        scanf("%f", &tmp->scoreC);
        printf("Score C++ : ");
        scanf("%f", &tmp->scoreCpp);
        getchar();
        tmp->avg = (tmp->scoreLinux + tmp->scoreC + tmp->scoreCpp)/3.;



        if(*HEAD == NULL){
            *HEAD = *TAIL = tmp;
        }
        else{
            (*TAIL)->nptr = tmp;
            *TAIL = tmp;
        }
    }
}

