#ifndef _15_
#define _15_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct student{
    char name[20];
    float scoreLinux;
    float scoreC;
    float scoreCpp;
    float avg;
    struct student *nptr;
};

void createNode(struct student**,struct student**);
void print(struct student *);
#endif
