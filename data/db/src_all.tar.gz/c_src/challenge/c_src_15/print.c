#include "15.h"

void print(struct student *HEAD)
{
    struct student *tmp;
    tmp = HEAD;
    while(tmp){
        printf("name : %s\nLinux : %3.1f\nC : %3.1f\nC++ : %3.1f\nAvg : %3.1f\n\n", tmp->name, tmp->scoreLinux, tmp->scoreC, tmp->scoreCpp, tmp->avg);
        tmp = tmp->nptr;
    }
}
