#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void print(int *arr, int length);

int main()
{
	// Enter length N
	int N;
	printf("Enter length of array : ");
	scanf("%d", &N);

	// Create array N, N
	int size = N*N;
	int array[N][N];
	int *trace;

	trace = (int*)calloc(N*N, sizeof(int));


	// Input random value in array (different each other)
	srand(time(NULL));
	for(int r = 0; r < N; ++r){
		for(int c = 0; c < N; ++c){
			while(1){
				int randVal = rand()%(N*N) + 1;
				if(!trace[randVal - 1]){
					trace[randVal - 1] = 1;
					array[r][c] = randVal;
					break;
				}
			}
		}
	}

	print(&array[0][0], N);

	// Erase number that user enters and replace by 'X'
	int input, xCnt = 0;	

	while(1){
		printf("Enter number that you want to delete(1~%d) : ", N*N);
		scanf("%d", &input);

		while(input < 0 || input > N*N){
			printf("You must enter number(1~%d) : ", N*N);
			scanf("%d", &input);
		}

		if(input == 0){
			printf("Exit\n");
			break;
		}

		if(!trace[input - 1]){
			printf("You already removed %d\n", input);
			continue;
		}
	
		for(int r = 0; r < N; ++r){
			if(!trace[input - 1]) break;
			for(int c = 0; c < N; ++c){
				if(array[r][c] == input){
					array[r][c] = -1;
					trace[input - 1] = 0;
					++xCnt;
					break;
				}
			}
		}

		// After all value are to be 'X', exit(0)
		if(xCnt == N*N){
			printf("All values are changed to 'X'\n");
			break;
		}

		print(&array[0][0], N);
	}
	
	free(trace);

	return 0;
}


void print(int *arr, int length)
{
	for(int r = 0; r < length; ++r){
		for(int c = 0; c < length; ++c){
			if(*(arr + r*length + c) != -1){
				printf("%d\t", *(arr + r*length + c));
			}else{
				printf("X\t");
			}
			
		}
		printf("\n");
	}
}

