#include <stdio.h>

struct student{
	char name[20];
	float math;
	float English;
	float Korean; 
	float avg;
};

void createStudentData(struct student **input, int num);
void enterScores(struct student *input);
void calcAvg(struct student *input);
void getAvg(struct student *input, float *avg);
void sorting(struct student *input, int num);
void swap(struct student *a, struct student *b);
void print(struct student *intput);

int main(int argc, char *argv[])
{
	struct student *arr;
	int nStudent;

	if(argc == 2)
		nStudent = argv[1];
	else
		nStudent = 10;

	createStudentData(&arr, nStudent);

	for(int i = 0; i < nStudent; ++i)	enterScores(arr+i);
	for(int i = 0; i < nStudent; ++i)	calcAvg(arr+i);
	for(int i = 0; i < nStudent; ++i)	print(arr+i);
	sorting(arr, nStudent);

	return 0;
}

void createStudentData(struct student **input, int num)
{
	*input = (struct student*)malloc(sizeof(struct student)*num);
	if(*input == NULL){
		printf("can not allocate data\n");
		exit(1);
	}
}

void enterScores(struct student *input)
{
	strcpy(input->name, "Unknown");
	input->math = rand()%10001*0.01;
	input->English = rand()%10001*0.01;
	input->Korean = rand()%10001*0.01;
}

void calcAvg(struct student *input)
{
	input->avg = (input->math + input->English + input->Korean)/3.;
}
void getAvg(struct student *input, float *avg)
{
	*avg = input->avg;
}

void sorting(struct student *input, int num)
{
	for(int i = num - 1; i >= 0; --i){
		for(int j = 0; j < i; ++j){
			if(input[j].avg < input[j+1].avg)
		}
	}
}

void swap(struct student *a, struct student *b)
{
	struct student tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

void print(struct student *intput)
{
	float avg;
	getAvg(input, &avg);
	printf("%s\t avg:%.2f(math:%.2f English:%.2f Korean:%.2f)\n", input->name, input->avg, input->math, input->English, input->Korean);
}
