#include <stdio.h>
#include <string.h>

int main()
{
	char word[80];
	int maxLength = -1;
	int count = 0;
	while(1){
		char c = getchar();

		if(c == '^Z'){
			printf("EOL\n");
			goto EXIT;
		}

		if(c == '\n'){
			if(maxLength < count){
				maxLength = count;		
			}
			word[count] = '\0';
			printf("%s : %d\n", word, count);
			word[0] = '\0';
			count = 0;
		}else{
			word[count] = c;
			++count;
		}
	}
	return 0;


EXIT:
	printf("Error\n");
	return 1;
	
}
