#include <stdio.h>

int main()
{
	FILE *fp;

	fp = fopen("test.txt", "r");
	if(fp == NULL){
		printf("error : fopen\n");
		return 1;
	}
	fputs("Hello world\n", fp);
	fputs("Hello world\n", fp);
	fclose(fp);

	return 0;
}
