#!/bin/bash
if [ $# -ne 1 ]; then
	echo "Usage : $0 filename"
	exit 1
fi

if [ -f $1 ]; then
	scp -P 2223 $1 pi@10.0.2.2:/home/pi
else
	echo "$1 is not found"
fi
