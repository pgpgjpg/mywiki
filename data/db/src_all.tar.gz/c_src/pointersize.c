#include <stdio.h>

int main()
{
	char ch='a', *p=&ch;
	int num=1, *np=&num;
	float fnum=1, *fp=&fnum;
	double dnum=1, *dp=&dnum;

	printf("char pointer size : %ld\n", sizeof(p));
	printf("int pointer size : %ld\n", sizeof(np));
	printf("float pointer size : %ld\n", sizeof(fp));
	printf("double pointer size : %ld\n", sizeof(dp));

	printf("char pointer addr : %p\n", p);
	printf("int pointer addr : %p\n", np);
	printf("float pointer addr : %p\n", fp);
	printf("double pointer addr : %p\n", dp);

	printf("char pointer val : %c\n", *p);
	printf("int pointer val : %d\n", *np);
	printf("float pointer val : %f\n", *fp);
	printf("double pointer val : %lf\n", *dp);

	return 0;
}
