#include <stdio.h>
#include <string.h>

int main()
{
	char str1[80], str2[80];

	//strcpy(str1, "peer");
	//strcpy(str2, "peach");

	fgets(str1, 80, stdin);
	str1[strlen(str1) - 1] = '\0';
	fgets(str2, 80, stdin);
	str2[strlen(str2) - 1] = '\0';

	printf("%s\n%s\n", str1, str2);

	int resCmp = strcmp(str1, str2);
	if(resCmp == 0)
		printf("same\n");
	else if(resCmp > 0)
		printf("str1 > str2\n");
	else
		printf("str1 < str2\n");

	return 0;
}
