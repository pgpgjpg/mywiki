// 2g, 3g, 5g 각 10개 씩
// 81g 경우 각 추의 갯수 구하기(모든 경우의 수)
#include <stdio.h>

#define GRAM2 2
#define GRAM3 3
#define GRAM5 5

int main()
{
	int totalGram = 81;
	int n2, n3, n5;
	int nWeight = 10;
	int sum = 0;

	for(n2 = 0; n2 <= nWeight; ++n2){
		for(n3 = 0; n3 <= nWeight; ++n3){
			for(n5 = 0; n5 <= nWeight; ++n5){
				sum = n2*GRAM2 + n3*GRAM3 + n5*GRAM5;

				if(sum == totalGram)
					printf("2g*%d=%dg 3g*%d=%dg 5g*%d=%dg\nSum = %d\n", n2, n2*GRAM2, n3, n3*GRAM3, n5, n5*GRAM5, sum);
			}
		}
	}

	return 0;
}
