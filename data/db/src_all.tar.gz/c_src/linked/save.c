#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"
void save(struct person *HEAD)
{
    FILE *fp;
    struct person *tmp;
    /*
    if((fp = fopen("linkedlist_log.txt", "w"))==NULL){
        printf("error : save\n");
        return;
    }
    tmp = HEAD;
    fwrite(tmp, sizeof(struct person), 1, fp);
    tmp = tmp->nptr;
    fclose(fp);
    */

    if((fp = fopen("linkedlist_log.txt", "wb"))==NULL){
        printf("error : save\n");
        return;
    }

    tmp = HEAD;

    while(tmp){
        fwrite(tmp, sizeof(struct person), 1, fp);

        tmp = tmp->nptr;
    }

    fclose(fp);
}

