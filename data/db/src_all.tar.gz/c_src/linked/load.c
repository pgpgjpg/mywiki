#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"
void load(struct person **HEAD, struct person **TAIL)
{
    FILE *fp;
    struct person *tmp;

    if((fp = fopen("linkedlist_log.txt", "rb")) == NULL){
        printf("error : There is not file\n");
        return;
    }

    while(1){
        tmp = (struct person*)malloc(sizeof(struct person));
        if(tmp == NULL){
            printf("error : can not allocate tmp\n");
            return;
        }
        fread(tmp, sizeof(struct person), 1, fp);
        if(feof(fp) != 0) break;
        if(*HEAD == NULL){
            *HEAD = *TAIL = tmp;
        }
        else{
            (*TAIL)->nptr = tmp;
            *TAIL = tmp;
        }
    }
    fclose(fp);
}

