#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"
void delete(struct person **HEAD, struct person **TAIL)
{
    struct person *tmp, *before;
    char name[20];

    tmp = *HEAD;

    printf("Enter name that you want to delete : ");
    fgets(name, 20, stdin);
    name[strlen(name) - 1] = '\0';

    while(tmp){
        if(!strcmp(tmp->name, name)){
            if(tmp == *HEAD){
                *HEAD = tmp->nptr;
                break;
            }else if(tmp->nptr == NULL){
                before->nptr = NULL;
                *TAIL = before;
                break;
            }else{
                before->nptr = tmp->nptr;
                break;
            }
        }
        before = tmp;
        tmp = tmp->nptr;
    }
    if(!tmp)
        printf("Failure\n");
    else
        printf("Success\n");
    free(tmp);
    tmp = NULL;
}


