#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"
void search(struct person *HEAD)
{
    struct person *tmp;
    char name[20];

    tmp = HEAD;

    printf("Enter name that you want to find : ");
    fgets(name, 20, stdin);
    name[strlen(name) - 1] = '\0';

    while(tmp){
        if(!strcmp(tmp->name, name)){
            printf("name : %s\nheight : %.2f\nage : %d\n\n", tmp->name, tmp->height, tmp->age);
            break;
        }
        tmp = tmp->nptr;
    }
    if(tmp == NULL)
        printf("No such name\n");
}

