#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"
void print(struct person *HEAD)
{
    struct person *tmp;

    tmp = HEAD;

    while(tmp){
        printf("name : %s\nheight : %.2f\nage : %d\n\n", tmp->name, tmp->height, tmp->age);

        tmp = tmp->nptr;
    }
}

