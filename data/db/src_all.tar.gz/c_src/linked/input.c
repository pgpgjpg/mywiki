#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"
void input(struct person **HEAD, struct person **TAIL)
{
    struct person *tmp;

    tmp = (struct person*)malloc(sizeof(struct person));
    if(tmp == NULL){
        printf("can not allocate tmp\n");\
        return;
    }

    tmp->nptr = NULL;
    printf("Enter name : ");
    fgets(tmp->name, 20, stdin);
    tmp->name[strlen(tmp->name) - 1] = '\0';

    printf("Enter age : ");
    scanf("%d", &tmp->age);
    printf("Enter height : ");
    scanf("%f", &tmp->height);

    if(*HEAD == NULL){
        *HEAD = *TAIL = tmp;
    }
    else{
        (*TAIL)->nptr = tmp;
        *TAIL = tmp;
    }
}


