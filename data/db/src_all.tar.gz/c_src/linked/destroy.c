#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"

void destroy(struct person **HEAD)
{
    struct person *tmp;
    while(*HEAD){
        tmp = *HEAD;
        *HEAD = (*HEAD)->nptr;
        free(tmp);
        tmp = NULL;
    }
}


