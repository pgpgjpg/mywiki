#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"

int main()
{
    int choice;
    struct person *HEAD, *TAIL;

    HEAD = TAIL = NULL;
    load(&HEAD, &TAIL);

    do{
        printf("1. 입력 \n");
        printf("2. 출력 \n");
        printf("3. 검색 \n");
        printf("4. 삭제 \n");
        printf("9. 종료 \n");
        printf("select : ");
        scanf("%d", &choice);
        getchar();

        switch(choice){
        case 1 :
            printf("select 1\n\n");
            input(&HEAD, &TAIL);
            break;
        case 2 :
            printf("select 2\n\n");
            print(HEAD);
            break;
        case 3 :
            printf("select 3\n\n");
            search(HEAD);
            break;
        case 4 :
            printf("select 4\n\n");
            delete(&HEAD, &TAIL);
            break;
        case 9 :
            printf("select 9\n\n");
            save(HEAD);
            destroy(&HEAD);
            exit(0);
            break;
        default :
            printf("wrong select\n\n");
            break;
        }
    }while(1);

    return 0;
}
