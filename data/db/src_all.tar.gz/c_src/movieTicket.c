#include <stdio.h>

int main()
{
	unsigned char age;
	int price;

	printf("####KIOSK FOR TICKET####\n");
	printf("How old are you? ");
	scanf("%hhu", &age);
	printf("Your age is %d\n", age);

	if(age >= 0 && age <= 7) price = 0;
	else if(age <= 18) price = 10000;
	else if(age <= 55) price = 15000;
	else if(age <= 65) price = 8000;
	else price = 0;

	printf("The price is \%dwon\n", price);

	return 0;
}
