#include <stdio.h>

int main()
{
	int a = 10, b = 20;
	int* const pa = &a;

	printf("변수a값 : %d\n", *pa);
	pa = &b;
	printf("변수b값 : %d\n", *pa);
	pa = &a;
	//a = 20;
	*pa = 20;
	printf("변수a값 : %d\n", *pa);

	return 0;
}
