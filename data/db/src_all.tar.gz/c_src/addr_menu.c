#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int input_addr();
void output_addr();
void search_addr();
int delete_addr();

char addrs[20][80];
char names[20][80];
int registeredNum;

int main()
{
	int menu, n;

	do{
		printf("1. 이름/주소 입력 \n");
		printf("2. 이름/주소 출력 \n");
		printf("3. 이름/주소 검색 \n");
		printf("4. 이름/주소 삭제 \n");
		printf("9. 종료 \n");
		printf("select : ");
		scanf("%d", &menu);
		getchar();

		switch(menu){
		case 1 : 
			n = input_addr();
			break;
		case 2 : 
			output_addr(n);
			break;
		case 3 : 
			search_addr(); // input : name, output : addr
			break;
		case 4 : 
			n = delete_addr(); // input : name -> 이름/주소 삭제
			break;
		case 9 : 
			printf("select 9\n\n");
			exit(0);
			break;
		default :
			printf("wrong select\n\n");
			break;
		}
	}while(1);

	return 0;
}

int input_addr()
{
	int i;

	for(i = registeredNum; i < 20; ++i){
		printf("name(%2d/%2d) : ", i+1, 20);
		fgets(names[i], 80, stdin);
		names[i][strlen(names[i]) - 1] = '\0';
		
		if(strcmp(names[i], "end") == 0){
			names[i][0] = 0;
			break;
		}
		registeredNum++;
		printf("addr(%2d/%2d) : ", i+1, 20);
		fgets(addrs[i], 80, stdin);
		addrs[i][strlen(addrs[i]) - 1] = '\0';

	}

	return i;
}

void output_addr(int num)
{
	int i;
	for(i = 0; i < registeredNum; ++i){
		if(names[i][0] == 0){
			break;
		}
		printf("%2d : %s\n", i+1, names[i]);
		printf("%2d : %s\n", i+1, addrs[i]);
	}
	printf("The number of registered is %d\n", i);
}

void search_addr()
{
	char name[80];
	char state = 0;

	printf("Enter the name that you want to search addr --> ");
	fgets(name, 80, stdin);
	name[strlen(name) - 1] = '\0';

	for(int i = 0; i < 20; ++i){
		if(!strcmp(names[i], name)){
			printf("%s's addr is %s\n", name, addrs[i]);
			state = 1;
		}
	}
	if(state == 0)
		printf("%s is not found in DB\n", name);
}

int delete_addr()
{
	char name[80];
	int num = 20;

	printf("Enter the name that you want to remove --> ");
	fgets(name, 80, stdin);
	name[strlen(name) - 1] = '\0';

	for(int i = 0; i < 20; ++i){
		if(names[i][0] == 0){
			num = i;
			break;
		}
		if(!strcmp(names[i], name)){
			registeredNum--;
			for(int j = i + 1; j < 20; ++j){
				strcpy(names[j - 1], names[j]);
				strcpy(addrs[j - 1], addrs[j]);
			}
		}
	}

	return num; 
}
