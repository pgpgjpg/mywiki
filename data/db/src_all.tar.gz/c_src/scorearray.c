// 음악, 미술, 체육 시험성적 입력 
// 평균 계산 배열
// 젲일 성적이 좋은 학생 번호 찾기

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int music[5];
	int art[5];
	int sport[5];
	double avg[5];
	double maxAvg = -1;
	int maxIdx;

	srand(time(NULL));

	for(int i = 0; i < 5; ++i){
		music[i] = rand()%101;
		art[i] = rand()%101;
		sport[i] = rand()%101;
	}

	for(int i = 0; i < 5; ++i){
		printf("%d student's music: %3d / art: %3d / sport: %3d\n", i+1, music[i], art[i], sport[i]);
	}


	for(int i = 0; i < 5; ++i){
		avg[i] = (music[i] + art[i] + sport[i])/3.;
		printf("%d student's average : %.2lf\n", i+1, avg[i]);
	}

	for(int i = 0; i < 5; ++i){
		if(maxAvg < avg[i]){
			maxAvg = avg[i];
			maxIdx = i;
		}
	}

	printf("\nmost highest score student : %d\n", maxIdx+1);
	printf("most highest score average : %.2lf\n\n", maxAvg);

	return 0;
}
