#include <stdio.h>

int main()
{
	int age;
	double height;
	char name[80];
	unsigned double udHeight;

	printf("나이와 키를 입력하세요 : ");
	scanf("%d%lf", &age, &height);
	printf("나이는 %d살, 키는 %.1lfcm입니다.\n", age, height);
	printf("name ? : ");
	scanf("%s", name);

	printf("name = %s, age = %d, height = %.1f\n", name, age, height);

	return 0;
}
