#include <stdio.h>

int main()
{
	int array[5];

	for(int i = 0; i < 5; ++i){
		//array[i] = i+1;
		printf("Enter value to array[%d] --> ", i);
		//scanf("%d", &array[i]);
		scanf("%d", array + i);
	}

	for(int i = 0; i < 5; ++i){
		printf("%d ", array[i]);
	}
	printf("\n");
	

	return 0;
}
