#include <stdio.h>

int main()
{
	int array[3][4] = {1, };

	printf("%p %p %p\n", array, array[0], &array[0][0]);
	printf("%p %p %p\n", array+1, array[1], &array[1][0]);
	
	printf("%ld\n", sizeof(array));
	printf("%ld\n", sizeof(array[0]));
	printf("%ld\n", sizeof(array[0][0]));
	/*
	for(int i = 0; i < 3; ++i){
		for(int j = 0; j < 4; ++j){
			printf("raw %d col %d  --> ", i, j);
			scanf("%d", &array[i][j]);
		}
	}
	*/
	for(int i = 0; i < 3; ++i){
		for(int j = 0; j < 4; ++j){
			printf("%d ", array[i][j]);
		}
		printf("\n");
	}

	return 0;
}
