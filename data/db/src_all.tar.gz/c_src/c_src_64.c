#include <stdio.h>

int main()
{
	char name[20] = "Jo Pyeong Geun";
	int i;

	printf("My Name is %s\n", name);


	for(i = 0; i < 20; ++i)
		printf("test %d : %c(%d)\n", i, name[i], name[i]);

	return 0;
}
