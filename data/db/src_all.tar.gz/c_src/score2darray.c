// 음악, 미술, 체육 시험성적 입력 
// 평균 계산 배열
// 젲일 성적이 좋은 학생 번호 찾기

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	// raw : student, col : subject
	// c0 : music, c1 : art, c2 : sport
	float score[5][4];
	char rank[5] = {1, 1, 1, 1, 1};
	double maxAvg = -1;
	int maxIdx;

	srand(time(NULL));

	for(int i = 0; i < 5; ++i){
		score[i][0] = rand()%1001*0.1;
		score[i][1] = rand()%1001*0.1;
		score[i][2] = rand()%1001*0.1;
	}

	for(int i = 0; i < 5; ++i){
		printf("%d student's music: %3.1f / art: %3.1f / sport: %3.1f\n", i+1, score[i][0], score[i][1], score[i][2]);
	}


	for(int i = 0; i < 5; ++i){
		score[i][3] = (score[i][0] + score[i][1] + score[i][2])/3.;
		printf("%d student's average : %.2f\n", i+1, score[i][3]);
	}

	for(int i = 0; i < 5; ++i){
		if(maxAvg < score[i][3]){
			maxAvg = score[i][3];
			maxIdx = i;
		}
	}

	for(int i = 0; i < 5; ++i){
		for(int j = 0; j < 5; ++j){
			if(score[i][3] < score[j][3])
				++rank[i];
		}
	}

	
	for(int i = 0; i < 5; ++i){
		printf("%d student's rank : %d\n", i+1, rank[i]);
	}


	printf("\nmost highest score student : %d\n", maxIdx+1);
	printf("most highest score average : %.2f\n\n", maxAvg);

	return 0;
}
