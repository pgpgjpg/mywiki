#include <stdio.h>

int main()
{
	char small, cap = 'G';

	if(cap >= 'A' && cap <= 'Z'){
		small = cap + ('a' - 'A');
	}

	printf("Capital : %c\n", cap);
	printf("Small : %c\n", small);

	return 0;
}
