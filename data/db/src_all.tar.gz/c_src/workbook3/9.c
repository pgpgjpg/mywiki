#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

void mygets(char *input);

int main()
{
    int music[5], art[5], sport[5];
	char names[5][80];
    double avg[5], tmp[5];
    double maxAvg = -1;
    int maxIdx;
	int rank;

    srand(time(NULL));

    for(int i = 0; i < 5; ++i){
		printf("%d번 학생의 이름을 입력하세요 --> ", i+1);
		mygets(names[i]);
        music[i] = rand()%101;
        art[i] = rand()%101;
        sport[i] = rand()%101;
    }

    for(int i = 0; i < 5; ++i)
        avg[i] = (music[i] + art[i] + sport[i])/3.;

	for(int i = 0; i < 5; ++i){
		rank = 0;
        for(int j = 0; j < 5; ++j){
			if(avg[i] < avg[j]) ++rank;
		}

		printf("%d:%s Avg: %.2lf[%d/5] (music: %3d / art: %3d / sport: %3d)\n", i+1, names[i], avg[i], rank+1,  music[i], art[i], sport[i]);
	}

    return 0;

}

void mygets(char *input)
{
	int size, i = 0;
	size = sizeof(input)/sizeof(input[0]);
	
	while(1){
		char c = getchar();
		
		if(i >= size)
			break;
		if(c == '\n'){
			input[i] = '\0';
			break;
	    }	
		input[i++] = c;
	}
}
