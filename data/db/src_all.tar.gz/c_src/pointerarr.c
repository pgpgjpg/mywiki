#include <stdio.h>

int main()
{
	char arr[10] = {'a', 'b', 'c', 'd', 'e'}, *cp;
	int *ip;

	cp = arr;
	ip = arr;

	printf("%d\n", *(cp+0));
	printf("%d\n", *(ip+0));
	printf("%d\n", *(cp+1));
	printf("%d\n", *(ip+1));

	for(int i = 0; i < 5; ++i)
		printf("%c\n", ++(*cp));

	return 0;
}
