#include <stdio.h>
#include <signal.h>
#include <unistd.h>

//void handler(int signo)
void handler()
{
	write(1, "Control_C\n", 10);
}

int main()
{
	sigset_t set;

	sigfillset(&set);
	sigdelset(&set, SIGINT);
	//sigdelset(&set, SIGQUIT);
	sigprocmask(SIG_SETMASK, &set, NULL);



	signal(SIGINT, handler);
	signal(SIGQUIT, handler);
	while(1);

	return 0;
}

