#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void handler(int signo)
{
	printf("Control_c\n");
}

int main()
{
	struct sigaction act, oldact;
	act.sa_handler = handler;
	sigfillset(&act.sa_mask);
	act.sa_flags = SA_RESETHAND|SA_RESTART;
	sigaction(SIGINT, &act, &oldact);

	for(int i = 0; i < 10; ++i){
		printf("%d\n", i);
		sleep(1);
	}

	sigaction(SIGINT, &oldact, NULL);

	while(1);

	return 0;
}
