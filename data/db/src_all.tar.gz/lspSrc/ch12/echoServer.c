#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <pthread.h>

#define BACKLOG 10

void* thread_function(void *arg);

int main(void)
{
   int sockfd, new_fd;
   struct sockaddr_in server_addr;
   struct sockaddr_in client_addr;
   int sin_size;
   int yes = 1;

   if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
       perror("socket");
       exit(1);
   }
   int value = 1;
   if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (void*) &value, sizeof(int)) == -1){
	  	perror("setsockopt");
		exit(1);
   }

   server_addr.sin_family = AF_INET;
   server_addr.sin_port = htons(60000);
   server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
   memset(&(server_addr.sin_zero), '\0', 8);

   if(bind(sockfd, (struct sockaddr *)&server_addr,
		   sizeof(struct sockaddr))==-1) {
       perror("bind");
       exit(1);
   }
   if(listen(sockfd, BACKLOG) == -1) {
       perror("listen");
       exit(1);
   }
   while(1) {
       sin_size = sizeof(struct sockaddr_in);
       if((new_fd = accept(sockfd, (struct sockaddr *) &client_addr,
    		       &sin_size))== -1)  {
           perror("accept");
           continue;
       }
       printf("server : got connection from %s \n",
    		    inet_ntoa(client_addr.sin_addr));


	   int ret;
	   pthread_t tid;

	   if((ret = pthread_create(&tid, NULL, thread_function, &new_fd)) != 0){
		   perror("pthread_create");
	   }

	  
	   pthread_detach(tid);
   }
   return 0;
}

void* thread_function(void *arg)
{
	  char recvbuf[100];
	  int numBytes;
	  int new_fd = *((int*)arg);
	  if(numBytes = read(new_fd, recvbuf, sizeof(recvbuf)) == -1){
	   	   perror("read");
	  }
	  if(send(new_fd, recvbuf, sizeof(recvbuf), 0) == -1)
	  	   perror("send");

			
	  if(send(new_fd, "Hello, client!\n", 14, 0) == -1)
           perror("send");
			

   	   return NULL;
}
