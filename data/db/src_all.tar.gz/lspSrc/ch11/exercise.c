#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

int main(void)
{
   struct hostent *host;
   struct sockaddr_in server_addr;

  //  get the network address by hostname

   server_addr.sin_family = AF_INET;
   server_addr.sin_port = /*    */(0x0050);
   server_addr.sin_addr = *((struct in_addr *) host->h_addr);
   memset(&(server_addr.sin_zero), '\0',8);

   printf("[ %s ]\n",  /*    */ );
   return 0;
}
