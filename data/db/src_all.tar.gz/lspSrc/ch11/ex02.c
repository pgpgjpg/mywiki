#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    struct in_addr addr;

    if (argc != 2) {
        fprintf(stderr, "%s <IP Address>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    printf("inet_addr(\"%s\") : %08x\n", argv[1], inet_addr(argv[1]));
    if (inet_aton(argv[1], &addr) == 0) {
        fprintf(stderr, "Invalid address\n");
        exit(EXIT_FAILURE);
    }
    printf("inet_atona(\"%s\") : %08x\n",argv[1],  addr);
    printf("\ninet_ntoa(%08x) : %s\n",  addr, inet_ntoa(addr));
    return 0;
}
