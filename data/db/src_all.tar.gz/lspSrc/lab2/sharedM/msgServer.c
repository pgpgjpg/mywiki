#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <sys/epoll.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

#define MAXDATASIZE 1024

int main(void)
{
	int sockfd[2], new_fd, nSockets, efd;
	struct sockaddr_in server_addr[2];
	struct sockaddr_in client_addr;
	int sin_size;
	int yes = 1, n, nEvents;
	char buf[MAXDATASIZE];
	struct epoll_event ev, *client_list;
	int shmid, semid;
    char *shmaddr;
	int shmIdx = 0, strLen = 100;

    if((shmid = shmget(0x123400, strLen*10, 0660|IPC_CREAT|IPC_EXCL)) == -1){
        if((shmid = shmget(0x123400, strLen*10, 0660)) == -1){
            perror("shmget");
            exit(1);
        }
    }
    if((semid = semget(0x123400, 1, 0660|IPC_CREAT|IPC_EXCL)) == -1){
        if((semid = semget(0x123400, 1, 0660)) == -1){
            perror("semget");
            exit(1);
        }
    }
    if((shmaddr = shmat(shmid, (char*)0, 0)) == NULL){
        perror("shmar");
        exit(1);
    }

	union semun{
        int                 val;
        struct  semid_ds    *buf;
        unsigned short int  *array;
    }arg;
    arg.val = 0;
    semctl(semid, 0, SETVAL, arg);
    struct sembuf sv = {0, 1, SEM_UNDO};	
	

	server_addr[0].sin_family = AF_INET;
	server_addr[0].sin_port = htons(60000);
	server_addr[0].sin_addr.s_addr = htonl(INADDR_ANY); 
	memset(&(server_addr[0].sin_zero), '\0', 8);

	server_addr[1].sin_family = AF_INET;
	server_addr[1].sin_port = htons(60001);
	server_addr[1].sin_addr.s_addr = htonl(INADDR_ANY); 
	memset(&(server_addr[1].sin_zero), '\0', 8);
	nSockets = sizeof(sockfd)/sizeof(sockfd[0]);
	

	if((efd = epoll_create(100)) < 0){
		perror("epoll_create");
		exit(1);
	}

	for(int i = 0; i < nSockets; ++i){
		if((sockfd[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
   			perror("socket");
   			exit(1);
   		} 
		if(bind(sockfd[i], (struct sockaddr *)&server_addr[i], sizeof(struct sockaddr))==-1) { 
			perror("bind");
		    exit(1);
   		}
		ev.events = EPOLLIN;
		ev.data.fd = sockfd[i];
		epoll_ctl(efd, EPOLL_CTL_ADD, sockfd[i], &ev);
	}

	
	while(1) {
		if((nEvents = epoll_wait(efd, client_list, 20, -1)) == -1){
			perror("epoll_wait");
			exit(1);
		}
		
		for(int i = 0; i < nEvents; ++i){
			int idx = client_list[i].data.fd;
			sin_size = sizeof(struct sockaddr_in);
			n = recvfrom(idx, buf, MAXDATASIZE, 0, (struct sockaddr*)&client_addr, &sin_size);
			if(n == -1){
				perror("recvfrom");
				exit(1);
			}
			printf("server : got connection from %s \n", inet_ntoa(client_addr.sin_addr));
	
			buf[n] = '\0';
			printf("from Client> %s\n", buf);
	
			time_t rawtime;
			struct tm* timeinfo;
			char buftime[80], buftmp[20];
			time(&rawtime);
			timeinfo = localtime(&rawtime);
			strftime(buftime, 80, "%G년 %m월 %d일 %H:%M:%S ", timeinfo);
			sprintf(buftmp, " %s ", inet_ntoa(client_addr.sin_addr));
			strcat(buftime, buftmp);
			strcat(buftime, buf);
			strcat(buftime, "\0");


			while(1){
				if(semctl(semid, 0, GETVAL) <= 10){
					printf("shm storage [ %d / 10 ]\n", semctl(semid, 0, GETVAL));
					printf("sending... > %s\n", buftime);
					memset(shmaddr+shmIdx*strLen, 0, strLen);
					memcpy(shmaddr+shmIdx*strLen, buftime, strlen(buftime));
					shmIdx = ++shmIdx % 10;
					semop(semid, &sv, 1);
					break;
				}else{
					fprintf(stderr, "error : exceed the range\n");
					break;
				}
			}
		}
		//printf("loop?");
   }

   return 0;
}
