#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main(void)
{
	int shmid, semid, shmIdx=0, strLen = 100;
	char *shmaddr;

	if((shmid = shmget(0x123400, strLen*10, 0660|IPC_CREAT|IPC_EXCL)) == -1){
		if((shmid = shmget(0x123400, strLen*10, 0660)) == -1){
			perror("shmget");
			exit(1);
		}
	}
	if((semid = semget(0x123400, 1, 0660|IPC_CREAT|IPC_EXCL)) == -1){
		if((semid = semget(0x123400, 1, 0660)) == -1){
			perror("semget");
			exit(1);
		}
	}
	if((shmaddr = shmat(shmid, (char*)0, 0)) == NULL){
		perror("shmar");
		exit(1);
	}

	struct sembuf sp = {0, -1, SEM_UNDO};
	int fd;
	if((fd = open("msg.log", O_WRONLY|O_CREAT|O_APPEND, 0666)) == -1){
		perror("open");
		exit(1);
	}
	//memset(shmaddr, 0, strlen(shmaddr));
	while(1){
		if(!strcmp(shmaddr, "")) continue;
			if(semctl(semid, 0, GETVAL) != 0){
				printf("Got from server : %s\n", shmaddr+shmIdx*strLen);
				write(fd, shmaddr+shmIdx*strLen, strlen(shmaddr+shmIdx*strLen));
				write(fd, "\n", 1);
				shmIdx = ++shmIdx % 10;
				//memset(shmaddr+shmIdx*strLen, 0, strLen);
				semop(semid, &sp, 1);
				sleep(1);
		}
	}

	close(fd);
    return 0;
}
