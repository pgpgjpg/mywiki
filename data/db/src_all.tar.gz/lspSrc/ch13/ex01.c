#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>

#define BACKLOG 10

int main(void)
{
   int sockfd, new_fd;
   struct sockaddr_in server_addr;
   struct sockaddr_in client_addr;
   int sin_size;
   int yes = 1;

   if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
       perror("socket");
       exit(1);
   }
   server_addr.sin_family = AF_INET;
   server_addr.sin_port = htons(60000);
   server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
   memset(&(server_addr.sin_zero), '\0', 8);

   if(bind(sockfd, (struct sockaddr *)&server_addr,
		   sizeof(struct sockaddr))==-1) {
       perror("bind");
       exit(1);
   }
   char buf[1024];
   int n;

   while(1) {
       sin_size = sizeof(struct sockaddr_in);
	   n = recvfrom(sockfd, buf, 1024, 0, (struct sockaddr*)&client_addr, &sin_size);
       printf("server : got connection received from %s \n", inet_ntoa(client_addr.sin_addr));
	   buf[n] = '\0';
	   printf("from Client> %s\n", buf);

	   fgets(buf, 1024, stdin);
	   buf[strlen(buf) - 1] = '\0';
	   if(sendto(sockfd, buf, 1024, 0, (struct sockaddr*)&client_addr, sizeof(struct sockaddr)) == -1){
		perror("sendto");
	   }
   }
   return 0;
}
