/***************************************
 * Filename: sk_app.c
 * Title: Skeleton Device Application
 * Desc: Implementation of system call
 ***************************************/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include "sk_ioctl.h"
#include <sys/ioctl.h>

int main(void)
{
    int fd;
    
    fd = open("/dev/SK", O_RDWR);
    printf("fd = %d\n", fd);
    
    if (fd<0) {
        perror("/dev/SK error");
        exit(-1);
    }
    else
        printf("SK has been detected...\n");
    
	char buf[1024], len;
	printf("Write\n");
	write(fd, "hello", 6);
	printf("Read\n");
	len = read(fd, buf, 1024);
	buf[len] = '\0';
	
	int choice;
	printf("1. UP  2. DOWN : chioce --> ");
	scanf("%d", &choice);
	if(choice == 1)
		ioctl(fd, SPEED_UP, 0);
	else
		ioctl(fd, SPEED_DOWN, 0);

    close(fd);
    
    return 0;
}

