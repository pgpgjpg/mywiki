/***************************************
 * Filename: sk.c
 * Title: Skeleton Device
 * Desc: module_init, module_exit
 ***************************************/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>

MODULE_LICENSE("GPL");
int result;
struct file_operations sk_fops;

static int sk_init(void)
{
    printk("SK Module is up... \n");
	result = register_chrdev(0, "SK", &sk_fops);
	printk("major number = %d\n", result);
    return 0;

}

static void sk_exit(void)
{
    printk("The module is down...\n");
	unregister_chrdev(result, "SK");
}


module_init(sk_init);  
module_exit(sk_exit);  

