/***************************************
 * Filename: sk.c
 * Title: Skeleton Device
 * Desc: Implementation of system call
 ***************************************/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <asm/uaccess.h>

MODULE_LICENSE("GPL");

int result;
char data[11];
/* Define Prototype of functions */
int sk_open(struct inode *inode, struct file *filp);
int sk_release(struct inode *inode, struct file *filp);
ssize_t sk_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
ssize_t sk_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);

struct file_operations sk_fops = { 
    .open       = sk_open,
    .release    = sk_release,
	.write		= sk_write,
	.read		= sk_read,
};

/* Implementation of functions */
int sk_open(struct inode *inode, struct file *filp)
{
    printk("Device has been opened...\n");
    
    /* H/W Initialization */
    
    
    return 0;
}

int sk_release(struct inode *inode, struct file *filp)
{
    printk("Device has been closed...\n");
    
    return 0;
}



ssize_t sk_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
	int ret;

	ret = copy_from_user(data, buf, count);
	printk("data >>> %s\n", data);

	return count;
}

ssize_t sk_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{
	int ret;
	ret = copy_to_user(data, buf, count);
	printk("%d data >>> %s\n",ret, data);
	return 0;
}

static int __init sk_init(void)
{
    printk("SK Module is up... \n");

    result = register_chrdev(0, "SK", &sk_fops);
    if (result < 0 ) {
        printk("Couldn't get a major number...\n");
    }
    printk("major number=%d\n", result);
    return 0;
}
static void __exit sk_exit(void)
{
    printk("The module is down...\n");
    unregister_chrdev(result, "SK");
}

module_init(sk_init); 
module_exit(sk_exit); 
