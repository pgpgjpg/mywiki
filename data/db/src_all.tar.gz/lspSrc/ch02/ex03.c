#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	printf("uid = %d\n", getuid());
	printf("euid = %d\n", geteuid());

	printf("login name : %s\n", getlogin());

	return 0;
}

