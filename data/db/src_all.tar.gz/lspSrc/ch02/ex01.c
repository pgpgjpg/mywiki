#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

int main(void)
{
	int fd=3;
	extern int errno;

	if(close(fd)==-1) {
		perror("close");
		printf("%d\n", errno);
		exit(1);
	}
	
	return 0;
}
