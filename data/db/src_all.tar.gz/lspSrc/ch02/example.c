#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct tm TM;

int main(void)
{
	char *homedir, filename[80], name[20];
	FILE *fp;
	time_t ti;
	TM *t;

	time(&ti);

	t = localtime(&ti);
	
	homedir=getenv("HOME");
	strcpy(filename, homedir);

	sprintf(name, "%d%02d%d", t->tm_year+1900, t->tm_mon+1, t->tm_mday);

	strcat(filename, "/");
	strcat(filename, name);
	
	

	if((fp=fopen(filename, "w"))==NULL) {
		perror("fopen");
		exit(1);
	}
	
	fwrite("getenv test\n", 12, 1, fp);
	fclose(fp);
	
	return 0;
}

