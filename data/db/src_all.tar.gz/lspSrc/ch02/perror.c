#include <stdio.h>
#include <unistd.h>

int main()
{
	int fd = 3;

	if(close(fd) == -1){
		perror("close111\n");
		return -1;
	}

	return 0;
}
