#include <stdio.h>
#include <stdlib.h>
#include <sys/sysinfo.h>

int main()
{
	struct sysinfo *si = (struct sysinfo*)malloc(sizeof(struct sysinfo));

	if(sysinfo(si) != 0){
		printf("error : sysinfo\n");
		return 1;
	}

	printf("Seconds since boot : %lu\n", si->uptime);

	printf("Average load(~1m) : %lu\n", si->loads[0]);
	printf("Average load(~5m) : %lu\n", si->loads[1]);
	printf("Average load(~15m) : %lu\n", si->loads[2]);

	printf("Total usable main memory size : %lu\n", si->totalram);
	printf("Available memory size : %lu\n", si->freeram);

	printf("Total swap : %lu\n", si->totalswap);
	printf("Swap space still available : %lu\n", si->freeswap);

	printf("Number of current processes : %u\n", si->procs);

	return 0;
}

