#ifndef _MINISHELL_H_
#define _MINISHELL_H_

char** command_parse(char *line);
void command_freelist(char **arglist);

typedef struct bt_type{
	char* cmd;
	void (*bt_func)(char**);
} BT_TYPE;

int redirectin(char** arglist);
int redirectout(char** arglist);
int redirecterr(char** arglist);
int checkBackground(char**);
int run_command(char**);
void hostname_func(char**);
int check_builtin(char**); 	// 빌트인 명령인지 판단
     						// (1: 빌드인명령, 0: 외부 명령)

#endif
