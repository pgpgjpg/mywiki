#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "minishell.h"
#include "builtin.h"

#define MAXLINE 255

void child_handler(int signo);

int main(void) {
    char line[MAXLINE];
	char **command;

	struct sigaction cact;

	cact.sa_handler = child_handler;
	sigfillset(&cact.sa_mask);
	cact.sa_flags = SA_RESTART;
	sigaction(SIGCHLD, &cact, NULL);

	signal(SIGINT, SIG_IGN); 
	signal(SIGQUIT, SIG_IGN); 

    fputs("minishell> ",stdout);

    while (fgets(line,MAXLINE,stdin)) {
		char **tmp;
        if(!strncmp(line,"exit",4))
            exit(0);
		
		if (command=command_parse(line)) {
			if(!check_builtin(command)){
				run_command(command);
			}
			command_freelist(command);
		}

        //fputs(line, stdout);
        fputs("minishell> ",stdout);
    }
    return 0;
}


void child_handler(int signo)
{
    pid_t  pid;

    for (;;) {
        pid = waitpid(-1, NULL, WNOHANG);
        if (pid == 0) {
                break;
        } else if (pid == -1 && errno == ECHILD) {
                break;

        } else if (pid == -1) {
                perror("waitpid");
                abort();
            }
        printf("PID of the dead child = %d\n", pid);

    }
    return;
}

