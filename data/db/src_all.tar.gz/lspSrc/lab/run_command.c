#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include "minishell.h"
#include <fcntl.h>

int checkPipe(char** arglist);

int run_command(char** arglist)
{
	pid_t pid;
	int flag = checkBackground(arglist);
	int pipeFlag = 0;
	pid = fork();

	switch(pid){
		case -1 :
			perror("fork()");
			exit(-1);
			break;
		case 0 : 
			signal(SIGINT, SIG_DFL);
			signal(SIGQUIT, SIG_DFL);
			

			pipeFlag = checkPipe(arglist);

			if(!pipeFlag){
				redirectin(arglist);
				redirectout(arglist);
				redirecterr(arglist);
				execvp(arglist[0], arglist);
				perror("execv");
				exit(1);
			}
			break;
			
		default :
			if(flag)	waitpid(pid, NULL, WNOHANG);
			else		waitpid(pid, NULL, 0);
			break;
	}

	return 0;
}

int checkBackground(char** arglist)
{
	int i = 0;

	while(arglist[i] != NULL) i++;
	
	if(!strcmp(arglist[i-1], "&")){
		arglist[i-1] = NULL;
		return 1;
	}
	else
		return 0;
}


int redirectin(char** arglist)
{
	int i;
	for(i = 0; arglist[i]; i++){
		if(!strcmp(arglist[i], "<") || !strcmp(arglist[i], "0<")){
			int fd = open(arglist[i+1], O_RDONLY);
			if(fd == -1){
				perror("open");
				exit(1);
			}
			dup2(fd, 0);
			close(fd);
			arglist[i] = NULL;
		}
	}
}

int redirectout(char** arglist)
{
	int i;
	for(i = 0; arglist[i]; i++){
		if(!strcmp(arglist[i], ">")){
			int fd = open(arglist[i+1], O_WRONLY|O_CREAT|O_TRUNC, 0666);
			if(fd == -1){
				perror("open");
				exit(1);
			}
			dup2(fd, 1);
			close(fd);
			arglist[i] = NULL;
		}
	}
}

int redirecterr(char** arglist)
{
	int i;
	for(i = 0; arglist[i]; i++){
		if(!strcmp(arglist[i], "2>")){
			int fd = open(arglist[i+1], O_WRONLY|O_CREAT|O_TRUNC, 0666);
			if(fd == -1){
				perror("open");
				exit(1);
			}
			dup2(fd, 2);
			close(fd);
			arglist[i] = NULL;
		}
	}
}

int checkPipe(char** arglist)
{
	int i;
	int pd[2];
	for(i = 0; arglist[i]; i++){
		if(!strcmp(arglist[i], "|")){
			arglist[i] = NULL;
			pipe(pd);

			switch(fork()){
		        case -1 :
		            perror("fork()");
		            exit(-1);
		            break;

				case 0 :
	                close(pd[0]);
	                dup2(pd[1], 1);
	                close(pd[1]);
	                execvp(arglist[0], arglist);
	                perror("execv");
	                exit(1);
		            break;
		
		        default :
		            close(pd[1]);
		            dup2(pd[0], 0);
		            close(pd[0]);
		            execvp(arglist[i+1], &arglist[i+1]);
		            perror("execv");
		            exit(1);
		            break;
	    	}
			return i;
		}
	}
	return 0;
}
