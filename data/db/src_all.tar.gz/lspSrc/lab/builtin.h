void hostname_func(char**);
int check_builtin(char**);
void id_func(char**);
void cd_func(char**);
