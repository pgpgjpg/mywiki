#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "minishell.h"
#include "builtin.h"
#include <sys/utsname.h>

BT_TYPE bt_array[] = {
	{"hostname", hostname_func},
	{"id", id_func},
	{"cd", cd_func},
	{"NULL", NULL}
};

void cd_func(char** arglist)
{
	char *home;
	if(!arglist[1] || !strcmp(arglist[1], "~")){
		home = getenv("HOME");
		if(chdir(home) == -1){
			perror("chdir");
			return;
		}
	}else{
		if(chdir(arglist[1]) == -1){
			perror("chdir");
			return;
		}
	}

}

void id_func(char** arglist)
{
	printf("UID = %d\n", getuid());
	printf("Name = %s\n", getlogin());
}

void hostname_func(char** arglist)
{
	struct utsname mysystem;
	
	if(uname(&mysystem)==-1) {
		perror("uname");
		exit(1);
	}
	
	printf("OS 종류 = %s\n", mysystem.sysname);
	printf("hostname = %s\n", mysystem.nodename);
	printf("release = %s\n", mysystem.release);
	printf("version = %s\n", mysystem.version);
	printf("hardware = %s\n", mysystem.machine);
}

int check_builtin(char** arglist)
{
	for(int i = 0; bt_array[i].cmd; ++i)
		if(strcmp(arglist[0], bt_array[i].cmd) == 0){
			bt_array[i].bt_func(arglist);
			return 1;
		}

	return 0;	
}
