#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	int fd, od;

	if((fd=open("/etc/hosts", O_RDONLY))==-1) {
		perror("open1");
		fprintf(stderr, "File Read Fail.....\n");
	} else {
		printf("File Read Success!! fd= %d\n", fd);
		//close(fd);
	}
	
	if((od=open("myhosts", O_RDWR|O_CREAT|O_TRUNC, 0666))==-1) {
		perror("open2");
		fprintf(stderr, "File Create Fail.....\n");
	} else {
		printf("File Creat Success!!  fd= %d\n", od);
		//close(fd);
	}
	
	struct stat fb, ob;
	if(fstat(fd, &fb) == -1){
		perror("fstat");
		exit(1);
	}
	char* p;
	p = mmap(NULL, fb.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
	if(p == NULL){
		perror("mmap");
		return 1;
	}
	close(fd);
	printf("%s\n", p);

	ftruncate(od, fb.st_size);

	char* op;

	op = (char*)mmap(NULL, fb.st_size, PROT_READ|PROT_WRITE, MAP_SHARED, od, 0);
	if(op == NULL){
		perror("mmap");
		exit(1);
	}
	close(od);
	memcpy(op, p, fb.st_size);
	printf("%s\n", op);
	munmap(p, fb.st_size);
	munmap(op, fb.st_size);

	return 0;
}
