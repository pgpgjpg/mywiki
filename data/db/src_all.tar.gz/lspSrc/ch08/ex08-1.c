#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>


int main()
{
	int shmid, semid, i, j;
	char *shmaddr;

	if((shmid=shmget(0x123400, 30, 0660|IPC_CREAT|IPC_EXCL))==-1) {
		if((shmid=shmget(0x123400, 30, 0660))==-1){
			perror("shmget");
			exit(1);
		}
	}
	if((semid=semget(0x123400, 1, 0660|IPC_CREAT|IPC_EXCL))==-1) {
		if((semid=semget(0x123400, 1, 0660))==-1){
			perror("shmget");
			exit(1);
		}
	}
 	if((shmaddr=shmat(shmid, (char *)0, 0))== NULL) {
		perror("shmat");
		exit(1);
	}


	
	union semun{
    	int                  val;
        struct   semid_ds   *buf;
        unsigned short int  *arrary;
	}  arg;
	arg.val = 0;
	semctl(semid, 0, SETVAL, arg);
	
	struct sembuf sv = {0, 1, SEM_UNDO};
 	for(i=0; i<20; i++) {
		while(1){
			if(!semctl(semid, 0, GETVAL)){
		 		sprintf(shmaddr, "shared memory test %d", i+1);
				semop(semid, &sv, 1);
		 		printf("send : %s\n", shmaddr);
				break;
			}
		}
 		for(j=0; j<10000; j++);
 	}
	printf("for send : sem val -> %d\n", semctl(semid, 0, GETVAL));
	while(1){
		if(!semctl(semid, 0, GETVAL)){
			printf("for send : sem val -> %d\n", semctl(semid, 0, GETVAL));
		 	sprintf(shmaddr, "end");
			semop(semid, &sv, 1);	
		 	printf("send : %s\n", shmaddr);
			printf("for send : sem val -> %d\n", semctl(semid, 0, GETVAL));
			break;
		}
	}

	if(shmdt(shmaddr)==-1 ) {
		perror("shmdt");
		exit(1);
	}

	return 0;
}
