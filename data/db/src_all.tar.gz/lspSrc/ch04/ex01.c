#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	if(argc != 2){
		printf("Usage : %s filename\n", argv[0]);
		exit(1);
	}

	struct stat fbuf;

	if(stat(argv[1], &fbuf) == -1){
		perror("stat");
		return 1;
	}

	printf("inode : %ld\n", fbuf.st_ino);
	printf("size : %ld\n", fbuf.st_size);
	printf("uid : %d\n", fbuf.st_uid);

	if(S_ISDIR(fbuf.st_mode))
		printf("%s is directory\n", argv[1]);
	else if(S_ISREG(fbuf.st_mode))
		printf("%s is regular file\n", argv[1]);


	return 0;
}
