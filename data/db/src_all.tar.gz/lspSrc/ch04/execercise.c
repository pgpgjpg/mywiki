#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
	if(argc != 2){
		printf("error : %s\n", argv[0]);
		return 1;
	}

   int fd;
   struct stat fbuf;
   char *buf;

   if((fd=open(argv[1], O_RDONLY))==-1)
   {
       perror("open");
       exit(1);
   }

   fstat(fd, &fbuf);
   buf = (char*)malloc(sizeof(char)*fbuf.st_size);

   if(read(fd, buf, fbuf.st_size)==-1){
	perror("read");
	return 1;
   }

   close(fd);

   printf("%s", buf);

   return 0;
}
