#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(void)
{
	int fd1, fd2;
	char buf[1024];

	if((fd1 = open("/etc/hosts", O_RDONLY))==-1) {
		perror("open1");
		fprintf(stderr, "File Read Fail.....\n");
		return 1;
	}

	if((fd2 = open("myhosts", O_WRONLY|O_CREAT|O_TRUNC, 0666))==-1) {
		perror("open2");
		fprintf(stderr, "File Create Fail.....\n");
		return 1;
	}



	struct stat fbuf;
	fstat(fd1, &fbuf);
	char* p = (char*)malloc(sizeof(char)*fbuf.st_size+1);
	int n;
	if((n = read(fd1, p, (fbuf.st_size+1))) == -1){
		perror("read");
	}
	write(fd2, p, fbuf.st_size+1);
	printf("read size : %d\nfile size : %ld\n", n, fbuf.st_size+1);

	/*
	while(1){
		int n;
		n = read(fd1, buf, 1024);

		if(n == -1){
			perror("read");
			break;
		}
		if(n < 1024){
			write(fd2, buf, n);
			break;
		}
		write(fd2, buf, n);
	}
	*/

	close(fd1);
	close(fd2);

	return 0;
}
