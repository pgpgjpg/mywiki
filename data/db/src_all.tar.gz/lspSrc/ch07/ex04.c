#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int main()
{
	sigset_t sigset, oldset, susset;

	//sigemptyset(&sigset);
	//sigfillset(&sigset);
	//sigprocmask(SIG_SETMASK, &sigset, &oldset);

	printf("waiting...\n");

	//sigemptyset(&susset);
	//sigaddset(&susset, SIGINT);
	sigfillset(&susset);
	sigdelset(&susset, SIGINT);

	sigsuspend(&susset);

	printf("You sent signal SIGINT\n");

	return 0;
}
