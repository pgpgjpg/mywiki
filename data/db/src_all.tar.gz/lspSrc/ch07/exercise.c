#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int usr1_count=0;
int usr2_count=0;
int end_flag=0;

void int_handler( int signo)
{
   end_flag=1;
}

void usr1_handler( int signo)
{
   usr1_count++;
}

void usr2_handler( int signo)
{
   usr2_count++;
}


int main( void)
{
   sigset_t sigset, set;
   struct sigaction act;


	sigfillset(&set);
	sigdelset(&sigset, SIGINT);
	sigdelset(&sigset, SIGUSR1);
	sigdelset(&sigset, SIGUSR2);
	sigprocmask(SIG_SETMASK, &set, NULL);


   act.sa_handler=int_handler;
   sigfillset(&act.sa_mask);
   act.sa_flags=SA_RESTART;
   sigaction(SIGINT, &act, NULL);

   act.sa_handler=usr1_handler;
   sigfillset(&act.sa_mask);
   act.sa_flags=SA_RESTART;
   sigaction(SIGUSR1, &act, NULL);

   act.sa_handler=usr2_handler;
   sigfillset(&act.sa_mask);
   act.sa_flags=SA_RESTART;
   sigaction(SIGUSR2, &act, NULL); 


	sigfillset(&sigset);
	sigdelset(&sigset, SIGINT);
	sigdelset(&sigset, SIGUSR1);
	sigdelset(&sigset, SIGUSR2);

   while(!end_flag)
  	   sigsuspend( &sigset);

   printf("usr1_count = %d, usr2_count = %d\n", usr1_count, usr2_count);
   return 0;
}
