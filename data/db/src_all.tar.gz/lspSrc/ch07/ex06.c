#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <time.h>


void interval_handler(int sig)
{
	struct timeval tv;
	struct tm *pt;
	time_t t;

	t = time(NULL);
	gettimeofday(&tv, NULL);
	pt = localtime(&t);

	printf("<interval handler> called(s) : %ld\n", tv.tv_sec);
	printf("<interval handler> called(us) : %ld\n", tv.tv_usec);
	printf("%d%02d%d\n", pt->tm_year+1900, pt->tm_mon+1, pt->tm_mday);
}

int main(void)
{
	struct sigaction act;
	struct itimerval itimer;

	act.sa_handler=interval_handler;
	sigfillset(&act.sa_mask);
	act.sa_flags=SA_RESTART;
	sigaction(SIGALRM, &act, NULL);

	printf("<main> Current Time : %ld\n", time(NULL));
	memset(&itimer, 0, sizeof(itimer));
	itimer.it_value.tv_sec=5;
	itimer.it_interval.tv_sec=2;
	setitimer(ITIMER_REAL, &itimer, NULL);

	while(1)
		pause();   	// wating for any signal
	return 0;
}


