#include <stdio.h>
#include <signal.h>

void handler(int signo)
{
	printf("Control_C\n");
}

int main()
{
	struct sigaction act;

	act.sa_handler = handler;
	sigfillset(&act.sa_mask);
	sigdelset(&act.sa_mask, SIGINT);
	act.sa_flags = SA_RESTART;
	sigaction(SIGINT, &act, NULL);

	sigdelset(&act.sa_mask, SIGQUIT);
	sigprocmask(SIG_SETMASK, &act.sa_mask, NULL);

	printf("waiting...\n");

	while(1) sigsuspend(&act.sa_mask);

	return 0;
}
