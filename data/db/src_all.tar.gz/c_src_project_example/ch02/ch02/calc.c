#include <stdio.h>
#include "calc.h"

int main()
{
	int num1, num2;
	
	printf("num1 ? num2? ");
	scanf("%d %d", &num1, &num2);
	add(num1, num2);
	sub(num1, num2);
	
	return 0;
}