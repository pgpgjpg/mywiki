#include <stdio.h>

void add(int n1, int n2)
{
	printf("shared  : %d + %d = %d\n", n1, n2, n1+n2);
	printf("%d * %d = %d\n", n1, n2, n1*n2);
}
