#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>
#include "calc.h"

typedef void (* OP_FUNC) (int, int);
OP_FUNC fadd;
OP_FUNC fsub;

int main()
{
	int num1, num2;
	void *handle;
	
	handle=dlopen("./libcalc.so", RTLD_LAZY);
	if(handle==NULL) {
		printf("%s\n", dlerror());
		exit(1);
	}
	fadd = (OP_FUNC) dlsym(handle, "add");
	fsub = (OP_FUNC) dlsym(handle, "sub");
	printf("num1 ? num2? ");
	scanf("%d %d", &num1, &num2);
	fadd(num1, num2);
	fsub(num1, num2);
	dlclose(handle);
	
	return 0;
}
