#include <stdlib.h>
#include <stdio.h>

int main()
{
	char *tempName;
	char szTempName[256];
    int i;
    FILE* fp;
    
    /*임시 파일명 생성 */    
	tempName = tmpnam(NULL);
	printf("임시 파일명 = %s\n\n", tempName);
	
	tempName = tmpnam(szTempName);
	printf("임시 파일명 = %s\n", tempName);
	printf("임시 파일명 = %s\n\n", szTempName);
    
    return 0;    
    
}
