#include <stdio.h>

char * inputLine(void)
{
	char ch;
	static char line[1024];
	int i=0;
	
	while(ch=getc(stdin)) {
		if(ch==EOF)
			return NULL;
		if(ch=='\n')
			break;
		line[i++]=ch;
	}	
	line[i]='\0';
	
	return line;
}

void outputLine(char *string)
{
	puts(string);
}