#include <stdlib.h>
#include <stdio.h>

int main()
{
	char *tempName;
    int i;
    FILE* fp;
    
    /*임시 파일명 생성 */    
    for (i=0;i<10;i++) {
    	tempName = tmpnam(NULL);
    	
    	printf("임시 파일명 = %s\n", tempName);
    }

    printf("==========================\n\n");
    /*임시 파일명 생성 및 파일 생성 후 삭제 */    
    for (i=0;i<10;i++) {
    	tempName = tmpnam(NULL);
    	if (NULL != tempName) {
        	fp = fopen(tempName, "w");
        	fclose(fp);
        	printf("임시 파일명 = %s\n", tempName);
        } else {
        	printf("임시 파일명 생성 오류 \n");
        }
    }
    
    return 0;    
    
}
