#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	char *ptr;
	
	ptr = (char *) malloc(10);
	printf(" ptr : %p\n", ptr);
	ptr[0] = 'a';
	ptr[1] = 'b';
	
	ptr = (char *) realloc(ptr, 100);
	printf(" ptr : %p\n", ptr);
	printf("ptr[0] : %c, ptr[1] : %c\n", ptr[0], ptr[1]);
	ptr[10]='c';
	ptr[11]='d';
	printf("ptr[10] : %c, ptr[11] : %c\n", ptr[10], ptr[11]);
	
	free(ptr);
	return 0;
	
}