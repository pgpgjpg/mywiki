#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
라인 단위로 문자열을 읽는 함수
만약 문자중 #을 만나면 \n이 나올때까지 모든 문자를 버린다.
*/
#define COMMENT_CODE        '#'

char *inputLine(FILE *fp)
{
    int c, n;
    static char line[BUFSIZ+1];
    int flag = 0;
    
    n = 0;
	while ((c = fgetc(fp)) != '\n') {
        if (EOF == c) {
            return(NULL);
        }
            
        //입력 버퍼 보다 크면 while 루프를 종료한다 
        if (n >= BUFSIZ) {
            break;
        }
        
        //읽어들인 문자가 comment 이면 flag 설정한다.
        if (COMMENT_CODE == c) {
            flag = 1;
        }
        
        //flag가 설정되지 않았다면 읽어들인 문자를 버퍼에 기록한다.
        if (1 != flag) {
            line[n++] = c;
        }
    }

    line[n] = '\0';
    return(line);
}

int main(int argc, char* argv[]) 
{
	char* str;
	int line = 1;
	FILE* fp;

    //프로그램을 실행 할 수 있는 인자가 존재하는 확인한다.	
	if (2 != argc) {
	    printf("Usage : ex02 filename\n");
	    exit(1);
	}
	
	//파일을 open 한다.
	fp = fopen(argv[1], "r");
	if (NULL == fp) {
	    printf("%s 파일을 열수 없습니다\n", argv[1]);
	    exit(1);
	}
	
	while (1) {
	    //파일에 한 라인을 읽어들입니다.
		str = inputLine(fp);

		if (NULL == str) {
			 break;
		}
		if (0 != str[0]) {
    		printf("%3d : %s\n", line, str);
    		line++;
        }
	}
	
	//파일을 닫습니다.
	fclose(fp);
	
	return 0;
}
