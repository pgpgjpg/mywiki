#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
라인 단위로 문자열을 읽는 함수 
*/
char *inputLine(FILE *fp)
{
    int c, n;
    static char line[BUFSIZ+1];

    n = 0;
	while ((c = fgetc(fp)) != '\n') {
        if (c == EOF)
            return(NULL);

        if (n < BUFSIZ)
            line[n++] = c;
    }

    line[n] = '\0';
    return(line);
}

int main(int argc, char* argv[]) 
{
	char* str;
	int line = 1;

//	printf("%d\n", BUFSIZ);
	while (1) {
		str = inputLine(stdin);

		if (NULL == str) {
			 break;
		}
		printf("%3d : %s\n", line, str);
		line++;
	}
	return 0;
}
