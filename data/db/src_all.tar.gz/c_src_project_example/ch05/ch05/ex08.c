#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile.h"

#define MAIN_MENU_TITLE "MAIN_MENU_TITLE"
#define MENU_COUNT      "MENU_COUNT"
#define MENU_TITLE      "MENU_TITLE"
#define CHOICE_MSG      "CHOICE_MSG"


int main_menu(LPC_PROFILE lpProfile);
int add(LPC_PROFILE lpProfile);
int sub(LPC_PROFILE lpProfile);

int main_menu(LPC_PROFILE lpProfile)
{
    int menu, i;
    char* mainTitle = NULL;
    char* menuTitle = NULL;
    char* choiceMsg = NULL;
    int   menuCount = 0;
    char  szBuf[256];
            
    //menu title을 읽어들인다.
    profileGetStringValue(lpProfile, MAIN_MENU_TITLE, &mainTitle);

    //choice msg을 읽어들인다.
    profileGetStringValue(lpProfile, CHOICE_MSG, &choiceMsg);

    //menu의 수를 읽어들인다.
    profileGetIntValue(lpProfile, MENU_COUNT, &menuCount);

    //무한 반복을 하면서 처리를 메뉴를 입력 반는다.    
    while (1) {
        //메뉴를 출력한다.
        puts(mainTitle);
        puts("");
        for (i=0;i<menuCount;i++) {
            sprintf(szBuf, "MENU_TITLE_%d", i+1);
            //choice msg을 읽어들인다.
            profileGetStringValue(lpProfile, szBuf, &menuTitle);
            puts(menuTitle);
        }
        printf("[%d] 종료\n\n", i+1);
        
        //메뉴를 입력받는다.
        printf("%s\n",choiceMsg);
        scanf("%d%*c", &menu);
        
        //메뉴입력에 따라 분기 하여 해당 기능을 수행한다.
        switch (menu)  {
        case 1:
            add(lpProfile);
            break;
        case 2:
            sub(lpProfile);
            break;
        case 3:
            return 0;
        default:
            printf("잘못입력되었습니다\n");
            break;
        }
    }
    
    return 0;
}

int add(LPC_PROFILE lpProfile)
{
    int a, b;
    
    puts("더하기 메뉴입니다");
    puts("");
    printf("a = ");
    scanf("%d", &a);
    printf("b = ");
    scanf("%d%*c", &b);
    
    printf("%d + %d = %d\n", a, b, a + b);
    
    return 0;
}

int sub(LPC_PROFILE lpProfile)
{
    int a, b;
    
    puts("빼기 메뉴입니다");
    puts("");
    printf("a = ");
    scanf("%d", &a);
    printf("b = ");
    scanf("%d%*c", &b);
    
    printf("%d - %d = %d\n", a, b, a - b);
    
    return 0;
}

int main(int argc, char* argv[]) 
{
    LPPROFILE lpProfile;
    int nErr;

    //프로파일 메모리를 할당한다.    
    nErr = profileCreate(&lpProfile, "input3.txt");
    profileAllDisplay(lpProfile);
    getchar();
    main_menu(lpProfile);    

    //포로파일 메모리를 해제한다.
    profileDestroy(lpProfile);

}
