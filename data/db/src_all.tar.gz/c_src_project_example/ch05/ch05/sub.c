#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int sub(void* lpData)
{
    int a, b;
    
    puts("빼기 메뉴입니다");
    puts("");
    printf("a = ");
    scanf("%d", &a);
    printf("b = ");
    scanf("%d%*c", &b);
    
    printf("%d - %d = %d\n", a, b, a - b);
    
    return 0;
}

