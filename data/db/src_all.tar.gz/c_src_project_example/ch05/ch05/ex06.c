#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile.h"

/*
    profile을 이용하여 읽어 들인 모든 내용을 출력한다.
*/
int main(int argc, char* argv[]) 
{
    LPPROFILE lpProfile = NULL;
    int nErr;
	LPHASH lpHash = NULL;
	long value = 10;
	char *key;
	POSITION pos;
    char szKey[256];
	char *msg;
    
    //프로파일 메모리를 할당한다.    
    nErr = profileCreate(&lpProfile, "input2.txt");
    if (ERR_PROFILE_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		exit(1);
    }

	//hash 테이블에 값을 등록한다
	nErr = hashSetValue(lpHash, "Key1", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
	    //오류 코드를 문자열로 변환 한다.
	    sprintf(szKey, "%d", nErr);
	    
	    //오류 코드에 대한 메시지를 profile 에서 얻는다.
	    profileGetStringValue(lpProfile, szKey, &msg);
		printf("%s:%d error message = %s\n",__FILE__, __LINE__, msg);
	}

    //포로파일 메모리를 해제한다.
    profileDestroy(lpProfile);
	
	return 0;
}
