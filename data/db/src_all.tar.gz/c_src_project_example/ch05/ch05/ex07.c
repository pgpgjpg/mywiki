#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main_menu();
int menu_add();
int menu_sub();

int main_menu()
{
    int menu;

    //무한 반복을 하면서 처리를 메뉴를 입력 반는다.    
    while (1) {
        //메뉴를 출력한다.
        puts("산술 연산 프로그램");
        puts("");
        puts("[1] 더하기");
        puts("[2] 빼기");
        puts("[3] 종료");
        puts("");
        
        //메뉴를 입력받는다.
        printf("원하는 메뉴는 ?");
        scanf("%d%*c", &menu);
        
        //메뉴입력에 따라 분기 하여 해당 기능을 수행한다.
        switch (menu)  {
        case 1:
            menu_add();
            break;
        case 2:
            menu_sub();
            break;
        case 3:
        	
            return 0;
        default:
            printf("잘못입력되었습니다\n");
            break;
        }
    }
    
    return 0;
}

int menu_add()
{
    int a, b;
    
    puts("더하기 메뉴입니다");
    puts("");
    printf("a = ");
    scanf("%d", &a);
    printf("b = ");
    scanf("%d%*c", &b);
    
    printf("%d + %d = %d\n", a, b, a + b);
    
    return 0;
}

int menu_sub()
{
    int a, b;
    
    puts("빼기 메뉴입니다");
    puts("");
    printf("a = ");
    scanf("%d", &a);
    printf("b = ");
    scanf("%d%*c", &b);
    
    printf("%d - %d = %d\n", a, b, a - b);
    
    return 0;
}

int main(int argc, char* argv[]) 
{
    //main menu함수를 실행합니다
    main_menu();    
}
