#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "input.h"

/*
    아래 예제는 문자열을 라인 단위로 읽고 해당 문자열을 = 기점으로 왼쪽은 key로 
    오른쪽은 value  로 분류 하여 화면에 출력한다.
*/
int main(int argc, char* argv[]) 
{
    int line=0;
	char *str;
    char *key, *value;
	FILE *fp;

    //프로그램을 실행 할 수 있는 인자가 존재하는 확인한다.	
	if (2 != argc) {
	    printf("Usage : ex02 filename\n");
	    exit(1);
	}
	
	//파일을 open 한다.
	fp = fopen(argv[1], "r");
	if (NULL == fp) {
	    printf("%s 파일을 열수 없습니다\n", argv[1]);
	    exit(1);
	}
	
	while (1) {
	    //파일에 한 라인을 읽어들입니다.
		str = inputLine(fp);

		if (NULL == str) {
			 break;
		}
		if (0 != str[0]) {
    		printf("%3d : %s\n", line, str);
    		key = strtok(str, "=");
    		value = key + strlen(key) + 1;
            printf("\tkey = %s\n", key);
            printf("\tvalue = %s\n", value);
    		line++;
        }
	}
	
	//파일을 닫습니다.
	fclose(fp);
	
	return 0;
}
