#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
라인 단위로 문자열을 읽는 함수 
*/
char *inputLine(FILE *fp)
{
    int c, n;
    static char line[BUFSIZ+1];

    n = 0;
	while ((c = fgetc(fp)) != '\n') {
        if (c == EOF)
            return(NULL);

        if (n < BUFSIZ)
            line[n++] = c;
    }

    line[n] = '\0';
    return(line);
}

int main(int argc, char* argv[]) 
{
	char* str;
	int line = 1;
	FILE* fp;

    //프로그램을 실행 할 수 있는 인자가 존재하는 확인한다.	
	if (2 != argc) {
	    printf("Usage : ex02 filename\n");
	    exit(1);
	}
	
	//파일을 open 한다.
	fp = fopen(argv[1], "r");
	if (NULL == fp) {
	    printf("%s 파일을 열수 없습니다\n", argv[1]);
	    exit(1);
	}
	
	while (1) {
	    //파일에 한 라인을 읽어들입니다.
		str = inputLine(fp);

		if (NULL == str) {
			 break;
		}
		printf("%3d : %s\n", line, str);
		line++;
	}
	
	//파일을 닫습니다.
	fclose(fp);
	
	return 0;
}
