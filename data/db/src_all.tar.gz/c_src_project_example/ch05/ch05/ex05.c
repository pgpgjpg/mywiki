#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "profile.h"

/*
    profile을 이용하여 읽어 들인 모든 내용을 출력한다.
*/
int main(int argc, char* argv[]) 
{
    LPPROFILE lpProfile;
    int nErr;

    //프로파일 메모리를 할당한다.    
    nErr = profileCreate(&lpProfile, "input2.txt");
    if (ERR_PROFILE_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		exit(1);
    }

    profileAllDisplay(lpProfile);
    
    //포로파일 메모리를 해제한다.
    profileDestroy(lpProfile);
	
	return 0;
}
