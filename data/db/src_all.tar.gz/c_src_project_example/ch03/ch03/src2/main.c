#include <stdio.h>


int main(void)
{
	printf("test2 program\n");
}
