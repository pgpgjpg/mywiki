#include <stdio.h>

void read(int num) {
	printf("read function called : %d\n", num);
	printf("read function end\n");
}
