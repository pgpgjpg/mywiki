#include <stdio.h>
#include "rw.h"

int main(void)
{
	printf("main function called\n");
	read(20);
	write();
	return 0;
}
