#include <stdio.h>

void write(void)
{
	printf("write function called\n");
	printf("write function called\n");
}
