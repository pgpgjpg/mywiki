void read(int);
void write(void);
void new(void);
