#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "array.h"


int srh(void* lpData){    
    LPMENU lpMenu = (LPMENU)lpData;
    LPPERSON pPerson;
    char name[20];
    int size = arraySize(lpMenu->lpArray);
    printf("이름을 입력하세요 -> ");
    fgets(name, 20, stdin);
    name[strlen(name) - 1] = '\0';

    for(int i = 0; i < size; ++i){
        int nErr = arrayGetAt(lpMenu->lpArray, i, (LPDATA*) &pPerson);
        printf("case 3 -> [%d]name : %s\n", i, pPerson->name);
        if (ERR_ARRAY_OK != nErr) {                        
            return -1;
        }
        if(!strcmp(name, pPerson->name)){
            printf("[%d] Name:\t%s\n", i, pPerson->name);
            printf("[%d] Age:\t%d\n", i, pPerson->age);
            printf("[%d] Height:\t %f\n", i, pPerson->height);
        }              
    }

    return 0;
}