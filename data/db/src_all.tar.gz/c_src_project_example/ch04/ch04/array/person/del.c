#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "array.h"


int del(void* lpData){    
    LPMENU lpMenu = (LPMENU)lpData;
    LPPERSON pPerson;
    char name[20];
    int size = arraySize(lpMenu->lpArray);
    printf("이름을 입력하세요 -> ");
    fgets(name, 20, stdin);
    name[strlen(name) - 1] = '\0';
    
    for(int i = 0; i < arraySize(lpMenu->lpArray); ++i){                    
        int nErr = arrayGetAt(lpMenu->lpArray, i, (LPDATA*) &pPerson);                    
        if (ERR_ARRAY_OK != nErr) {            
            return -1;
        }
        if(!strcmp(name, pPerson->name)){
            nErr = arrayRemoveAt(lpMenu->lpArray, i);
            if (ERR_ARRAY_OK != nErr) {
                printf("error = %d\n", nErr);
                return -1;
            }                        
        }                        
    }
    return 0;
}