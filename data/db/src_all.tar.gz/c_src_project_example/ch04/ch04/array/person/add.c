#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "array.h"
//#include "array.c"

int add(void* lpData){
    PERSON *person = (PERSON*)malloc(sizeof(PERSON));
    LPMENU lpMenu = (LPMENU)lpData;
    printf("이름을 입력하세요 -> ");
    fgets(person->name, 20, stdin);                
    person->name[strlen(person->name) - 1] = '\0';   
    printf("나이를 입력하세요 -> ");
    scanf("%d", &person->age);
    getchar();
    printf("키를 입력하세요 -> ");
    scanf("%f", &person->height);
    getchar();               

    int nErr = arrayAdd(lpMenu->lpArray, (const LPDATA)person);  
    if (ERR_ARRAY_OK != nErr) {
        return -1;
    }

    return 0;
}