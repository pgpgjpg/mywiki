#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"

int main(int argc, char* argv[]) 
{
    LPMENU lpMenu;
    int nErr;

    //MENU 메모리를 할당한다.    
    nErr = menuCreate(&lpMenu);
    if (ERR_MENU_OK != nErr) {
      printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
      return nErr;
    }
    
    nErr = menuRun(lpMenu);    
    if (ERR_MENU_OK != nErr) {
      printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
      return nErr;
    }

    //MENU메모리를 해제한다.
    menuDestroy(lpMenu);
    
    return 0;
}
