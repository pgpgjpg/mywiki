#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "array.h"


int des(void* lpData){    
    LPMENU lpMenu = (LPMENU)lpData;
    if (NULL != lpMenu->lpArray) {
        arrayDestroy(lpMenu->lpArray);
    }
    return 0;       
}