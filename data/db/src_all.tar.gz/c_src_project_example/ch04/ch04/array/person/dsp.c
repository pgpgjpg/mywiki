#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "array.h"


int dsp(void* lpData){    
    LPMENU lpMenu = (LPMENU)lpData;
    LPPERSON pPerson;
    int size = arraySize(lpMenu->lpArray);
    for(int i = 0; i < size; ++i){
        int nErr = arrayGetAt(lpMenu->lpArray, i, (LPDATA*) &pPerson);
        if (ERR_ARRAY_OK != nErr) {
            return -1;
        }
        //배열에서 얻은 값을 출력합니다
        printf("[%d] Name:\t%s\n", i, pPerson->name);
        printf("[%d] Age:\t%d\n", i, pPerson->age);
        printf("[%d] Height:\t %f\n", i, pPerson->height);
    }

    return 0;
}