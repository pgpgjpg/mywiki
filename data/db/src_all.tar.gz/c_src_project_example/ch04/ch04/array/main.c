#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"

typedef struct Person{
    char name[20];
    int age;
    float height;
}PERSON, *LPPERSON;

int main()
{
    LPMENU lpMenu;
    int nErr;

    //MENU 메모리를 할당한다.    
    nErr = menuCreate(&lpMenu);
    if (ERR_MENU_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		return nErr;
    }
    
    nErr = menuRun(lpMenu);    
    if (ERR_MENU_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		return nErr;
    }

    //MENU메모리를 해제한다.
    menuDestroy(lpMenu);
    
    return 0;


    /*
    LPARRAY lpArray = NULL;
    LPPERSON pPerson;
    int nErr = arrayCreate(&lpArray);
    if(ERR_ARRAY_OK != nErr)
        return  nErr;

    do{
        int menu;
        printf("1. 입력\n");
        printf("2. 출력\n");
        printf("3. 검색\n");
        printf("4. 삭제\n");
        printf("5. 종료\n");
        scanf("%d", &menu);
        getchar();
        switch(menu){
            case 1 :{
                PERSON *person = (PERSON*)malloc(sizeof(PERSON));
                printf("이름을 입력하세요 -> ");
                fgets(person->name, 20, stdin);                
                person->name[strlen(person->name) - 1] = '\0';   
                printf("나이를 입력하세요 -> ");
                scanf("%d", &person->age);
                getchar();
                printf("키를 입력하세요 -> ");
                scanf("%f", &person->height);
                getchar();               

                nErr = arrayAdd(lpArray, (const LPDATA)person);  
                if (ERR_ARRAY_OK != nErr) {
                    goto exit;
                }
                break;
            }
            case 2 : {
                int size = arraySize(lpArray);
                for(int i = 0; i < size; ++i){
                    nErr = arrayGetAt(lpArray, i, (LPDATA*) &pPerson);
                    if (ERR_ARRAY_OK != nErr) {
                        goto exit;
                    }
                    //배열에서 얻은 값을 출력합니다
                    printf("[%d] Name:\t%s\n", i, pPerson->name);
                    printf("[%d] Age:\t%d\n", i, pPerson->age);
                    printf("[%d] Height:\t %f\n", i, pPerson->height);
                }
                break;
            }
            case 3 : {
                char name[20];
                int size = arraySize(lpArray);
                printf("이름을 입력하세요 -> ");
                fgets(name, 20, stdin);
                name[strlen(name) - 1] = '\0';
                
                for(int i = 0; i < size; ++i){
                    nErr = arrayGetAt(lpArray, i, (LPDATA*) &pPerson);
                    printf("case 3 -> [%d]name : %s\n", i, pPerson->name);
                    if (ERR_ARRAY_OK != nErr) {                        
                        goto exit;
                    }
                    if(!strcmp(name, pPerson->name)){
                        printf("[%d] Name:\t%s\n", i, pPerson->name);
                        printf("[%d] Age:\t%d\n", i, pPerson->age);
                        printf("[%d] Height:\t %f\n", i, pPerson->height);
                    }              
                }
                break;
            }

            case 4 : {
                char name[20];
                int size = arraySize(lpArray);
                printf("이름을 입력하세요 -> ");
                fgets(name, 20, stdin);
                name[strlen(name) - 1] = '\0';
                
                for(int i = 0; i < arraySize(lpArray); ++i){                    
                    nErr = arrayGetAt(lpArray, i, (LPDATA*) &pPerson);                    
                    if (ERR_ARRAY_OK != nErr) {
                        printf("get error\n");
                        goto exit;
                    }
                    if(!strcmp(name, pPerson->name)){
                        nErr = arrayRemoveAt(lpArray, i);
                        if (ERR_ARRAY_OK != nErr) {
                            printf("error = %d\n", nErr);
                            goto exit;
                        }                        
                    }                        
                }
                break;
            }    
            case 5 :            
                goto exit;
                
            default :
                printf("잘못 입력하였습니다.\n");
                break;
        }
    }while(1);

    exit:
    //메모리를 해제합니다
    if (NULL != lpArray) {
        arrayDestroy(lpArray);
    }
    return nErr;    
    */
}