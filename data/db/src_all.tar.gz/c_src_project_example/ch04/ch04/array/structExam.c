#include <stdio.h>
#include <stdlib.h>
#include "array.h"

/****************************************************************************
//구조체 사용예 
****************************************************************************/

typedef struct {
    char name[32];
    int  kor;
    int  eng;
    int  mat;
    int  total;
    float avg;
} STUDENT, *LPSTUDENT;

int studentOutput(LPSTUDENT lpStudent)
{
    int nErr;
    
    printf("이름 = %s  ", lpStudent->name);
    printf("국어 = %.3d  ", lpStudent->kor);
    printf("영어 = %.3d  ", lpStudent->eng);
    printf("수학 = %.3d  ", lpStudent->mat);
    printf("총점 = %.3d  ", lpStudent->total);
    printf("평균 = %6.2f\n", lpStudent->avg);
    
    return 0;
}


int main()
{
    //배열을 관리하는 구조체 변수를 선언합니다.
    LPARRAY lpArray = NULL;
    int i;
    LPSTUDENT value;
    int nErr = ERR_ARRAY_OK;
    int size;
    STUDENT student [] = {
        {"홍길동", 100, 100, 100, 300, 100},
        {"이순신",  70,  80,  90, 240,  80},
        {"장길산",  90,  80,  70, 240,  80},
        {"연정토",  90,  70,  80, 240,  80},
    };
    int strSize = sizeof(student) / sizeof(student[0]);
   
    //배열 구조체 매모리를 할당합니다
    nErr = arrayCreate(&lpArray);
    if (ERR_ARRAY_OK != nErr) {
        return nErr;
    }
    
    for (i=0;i<strSize;i++) {
        //배열에 값을 추가합니다
        nErr = arrayAdd(lpArray, (const LPDATA) &student[i]);
        if (ERR_ARRAY_OK != nErr) {
            goto exit;
        }
        //증가합니다
        value++;
    }

    //배열의 크기를 얻는다
    size = arraySize(lpArray);
    printf("array size = %d\n", size);
    //배열에서 위치를 이용하여 값을 얻는다
    for (i=0;i<size;i++) {
        nErr = arrayGetAt(lpArray, i, (LPDATA*) &value);
        if (ERR_ARRAY_OK != nErr) {
            goto exit;
        }
        //배열에서 얻은 값을 출력합니다
        studentOutput(value);
    }
    printf("======================================\n");

    //배열에서 2 번째 위치를 삭제합니다.
    nErr = arrayRemoveAt(lpArray, 2);
    if (ERR_ARRAY_OK != nErr) {
        printf("error = %d\n", nErr);
        goto exit;
    }
    
    //배열의 크기를 얻는다
    size = arraySize(lpArray);
    printf("array size = %d\n", size);
    //배열에서 위치를 이용하여 값을 얻는다
    for (i=0;i<size;i++) {
        nErr = arrayGetAt(lpArray, i, (LPDATA*) &value);
        if (ERR_ARRAY_OK != nErr) {
            goto exit;
        }
        //배열에서 얻은 값을 출력합니다
        studentOutput(value);
    }
    printf("======================================\n");
    
exit:
    //메모리를 해제합니다
    if (NULL != lpArray) {
        arrayDestroy(lpArray);
    }
    return nErr;
}

