#include <stdio.h>
#include <stdlib.h>
#include "array.h"

/****************************************************************************
 정수형 자료형 사용예
****************************************************************************/

int main()
{
    //배열을 관리하는 구조체 변수를 선언합니다.
    LPARRAY lpArray = NULL;
    int i;
    long value = 10;
    int nErr = ERR_ARRAY_OK;
    int size;
    
    //배열 구조체 매모리를 할당합니다
    nErr = arrayCreate(&lpArray);
    if (ERR_ARRAY_OK != nErr) {
        return nErr;
    }
    
    for (i=0;i<20;i++) {
        //배열에 값을 추가합니다
        nErr = arrayAdd(lpArray, (const LPDATA) value);
        if (ERR_ARRAY_OK != nErr) {
            goto exit;
        }
        //증가합니다
        value++;
    }

    //배열의 크기를 얻는다
    size = arraySize(lpArray);
    printf("array size = %d\n", size);
    //배열에서 위치를 이용하여 값을 얻는다
    for (i=0;i<size;i++) {
        nErr = arrayGetAt(lpArray, i, (LPDATA*) &value);
        if (ERR_ARRAY_OK != nErr) {
            goto exit;
        }
        //배열에서 얻은 값을 출력합니다
        printf("array[%d] = %ld\n", i, value);
    }
    printf("======================================\n");

    //배열에서 5 번째 위치를 삭제합니다.
    nErr = arrayRemoveAt(lpArray, 5);
    if (ERR_ARRAY_OK != nErr) {
        printf("error = %d\n", nErr);
        goto exit;
    }
    
    //배열의 크기를 얻는다
    size = arraySize(lpArray);
    printf("array size = %d\n", size);
    //배열에서 위치를 이용하여 값을 얻는다
    for (i=0;i<size;i++) {
        nErr = arrayGetAt(lpArray, i, (LPDATA*) &value);
        if (ERR_ARRAY_OK != nErr) {
            goto exit;
        }
        //배열에서 얻은 값을 출력합니다
        printf("array[%d] = %ld\n", i, value);
    }
    printf("======================================\n");
    
exit:
    //메모리를 해제합니다
    if (NULL != lpArray) {
        arrayDestroy(lpArray);
    }
    return nErr;
}
