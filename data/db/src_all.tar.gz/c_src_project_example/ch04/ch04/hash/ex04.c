#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"
/*
value로 구조체를 사용하는 방법을 알아본다
*/
/****************************************************************************
//구조체 사용예 
****************************************************************************/
typedef struct {
    char name[32];
    int  kor;
    int  eng;
    int  mat;
    int  total;
    float avg;
} STUDENT, *LPSTUDENT;
int studentOutput(LPSTUDENT lpStudent)
{
    int nErr;
    
    printf("이름 = %s  ", lpStudent->name);
    printf("국어 = %.3d  ", lpStudent->kor);
    printf("영어 = %.3d  ", lpStudent->eng);
    printf("수학 = %.3d  ", lpStudent->mat);
    printf("총점 = %.3d  ", lpStudent->total);
    printf("평균 = %6.2f\n", lpStudent->avg);
    
    return 0;
}
void studentDestroy(LPSTUDENT lpStudent)
{
    printf("학생 메모리를 해제 합니다.\n");
    free(lpStudent);
}
int main()
{
	LPHASH lpHash;
	int i, nErr;
	POSITION pos;
	char *key;
    STUDENT* value;
    int isExist;
	//hash 메모리를 할당하는 함수를 호출한다.
	nErr = hashCreate(&lpHash);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		return 0;
	}
    //hash 테이블에 메모리를 해제 할 수 있는 함수를 등록한다.
    nErr = hashSetFree(lpHash, (void(*)(void*))studentDestroy);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		return 0;
	}
    //hash 테이블에 구조체의 이름을 key로 하여 구조체 주소를 등록한다.
    for(i=0;i<3;i++) {
        //동적으로 메모리를 할당받는다.
        value = (LPSTUDENT) malloc (sizeof(STUDENT));
        
        //자료를 입력합니다.        
        printf("이름 국어 영어 수학 자료를 입력하고 엔터를 치시오");
        nErr = scanf("%s %d %d %d", value->name, &value->kor, &value->eng, &value->mat);
value->total = value->kor + value->eng +value->mat;
        value->avg = value->total / 3.0f;
        //hash 테이블에 자료를 등록합니다.        
    	nErr = hashSetValue(lpHash, value->name, (LPDATA) value);
    	if (ERR_HASH_OK != nErr) {
    		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
    	}
    }
    
    printf("\n");
    
	getchar();
	char name[20];
	printf("삭제할 이름을 입력하세요 -> ");
	fgets(name, 20, stdin);
	name[strlen(name) - 1] = '\0';
	nErr = hashRemoveKey(lpHash, name);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}


	//hash 테이블의 처음 위치를 얻는다.
	nErr = hashGetFirstPostion(lpHash, &pos);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	//다음 위치로 이동하여 
	while (1) {
		nErr = hashGetNextPostion(lpHash, &pos, &key, (LPDATA*) &value);
		if (ERR_HASH_OK != nErr) {
			printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
			break;
		}
		//학생 구조체의 내용을 출력한다.
		studentOutput(value);
		
		//다음 위치가 없음 while 루프를 종료한다.
		if (NULL == pos) {
			break;
		}
	}
    
	


	//hash 메모리를 할당하는 함수를 호출한다.
	nErr = hashDestroy(lpHash);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}

	


	return 0;
}

