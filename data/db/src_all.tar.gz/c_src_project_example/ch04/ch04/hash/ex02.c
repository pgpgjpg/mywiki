#include <stdio.h>
#include "hash.h"
/*
magiccode을 사용하는 예를 확인한다.
잘못된 포인터를 사용하는 예를 확인한다.
*/
int main()
{
	LPHASH lpHash;
	int nErr;
	long value = 10;
	char *key;
	POSITION pos;
	//hash 테이블에 값을 등록한다
	nErr = hashSetValue(lpHash, "Key1", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	//hashGetValue()함수를 이용하여 자료를 얻는다.
	key = "Key2";
	nErr = hashGetValue(lpHash, key, (LPDATA*) &value);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	} else {
    	//key 값과 value를 ?력한다.
    	printf("key = %s   value = %ld\n\n", key, value);
    }
	//hash 메모리를 할당하는 함수를 호출한다.
	nErr = hashDestroy(lpHash);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	
	return 0;
}

