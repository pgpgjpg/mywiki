#include <stdio.h>
#include "hash.h"
/*
value로 구조체를 사용하는 방법을 알아본다
*/
/****************************************************************************
//구조체 사용예 
****************************************************************************/
typedef struct {
    char name[32];
    int  kor;
    int  eng;
    int  mat;
    int  total;
    float avg;
} STUDENT, *LPSTUDENT;
int studentOutput(LPSTUDENT lpStudent)
{
    int nErr;
    
    printf("이름 = %s  ", lpStudent->name);
    printf("국어 = %.3d  ", lpStudent->kor);
    printf("영어 = %.3d  ", lpStudent->eng);
    printf("수학 = %.3d  ", lpStudent->mat);
    printf("총점 = %.3d  ", lpStudent->total);
    printf("평균 = %6.2f\n", lpStudent->avg);
    
    return 0;
}
int main()
{
	LPHASH lpHash;
	int i, nErr;
	POSITION pos;
	char *key;
    STUDENT* value;
    int isExist;
    STUDENT student [] = {
        {"홍길동", 100, 100, 100, 300, 100},
        {"이순신",  70,  80,  90, 240,  80},
        {"장길산",  90,  80,  70, 240,  80},
        {"연정토",  90,  70,  80, 240,  80},
    };
    int size = sizeof(student) / sizeof(student[0]);
	//hash 메모리를 할당하는 함수를 호출한다.
	nErr = hashCreate(&lpHash);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		return 0;
	}
    //hash 테이블에 구조체의 이름을 key로 하여 구조체 주소를 등록한다.
    for(i=0;i<size;i++) {
    	nErr = hashSetValue(lpHash, student[i].name, (LPDATA) &student[i]);
    	if (ERR_HASH_OK != nErr) {
    		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
    	}
    }
    
	//hash 테이블의 처음 위치를 얻는다.
	nErr = hashGetFirstPostion(lpHash, &pos);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	//다음 위치로 이동하여 
	while (NULL != pos) {
		nErr = hashGetNextPostion(lpHash, &pos, &key, (LPDATA*) &value);
		if (ERR_HASH_OK != nErr) {
			printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
			break;
		}
		//학생 구조체의 내용을 출력한다.
		studentOutput(value);
	}
    
	key = "홍길동";
	nErr = hashIsKey(lpHash, key, &isExist);
	if (TRUE == isExist) {
	    printf("%s에 대한 학생 자료가 존재합니다\n", key);
	} else {
	    printf("%s에 대한 학생 자료가 없습니다\n", key);
	}
	key = "박찬호";
	nErr = hashIsKey(lpHash, key, &isExist);
	if (TRUE == isExist) {
	    printf("%s에 대한 학생 자료가 존재합니다\n", key);
	} else {
	    printf("%s에 대한 학생 자료가 없습니다\n", key);
	}
	//hash 메모리를 할당하는 함수를 호출한다.
	nErr = hashDestroy(lpHash);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	return 0;
}

