#include <stdio.h>
#include "hash.h"

int main()
{
	LPHASH lpHash;
	int nErr;
	long value = 10;
	char *key;
	POSITION pos;

	//hash 메모리를 할당하는 함수를 호출한다.
	nErr = hashCreate(&lpHash);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
		return 0;
	}
	
	//hash 테이블에 값을 등록한다
	nErr = hashSetValue(lpHash, "Key1", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	nErr = hashSetValue(lpHash, "Key2", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	nErr = hashSetValue(lpHash, "Key3", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	nErr = hashSetValue(lpHash, "Key4", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	nErr = hashSetValue(lpHash, "Key5", (LPDATA) value++);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	// nErr = hashSetValue(lpHash, "Key2", (LPDATA) value++);
	// if (ERR_HASH_OK != nErr) {
	// 	printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	// }

	//hashGetValue()함수를 이용하여 자료를 얻는다.
	key = "Key2";
	nErr = hashGetValue(lpHash, key, (LPDATA*) &value);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}
	//key 값과 value를 ?력한다.
	printf("key = %s   value = %ld\n\n", key, value);


	//hash 테이블의 처음 위치를 얻는다.
	nErr = hashGetFirstPostion(lpHash, &pos);
	if (ERR_HASH_OK != nErr) {
		printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
	}

	//다음 위치로 이동하여 
	while (NULL != pos) {
		nErr = hashGetNextPostion(lpHash, &pos, &key, (LPDATA*) &value);
		if (ERR_HASH_OK != nErr) {
			printf("%s:%d error code = %d\n",__FILE__, __LINE__, nErr);
			break;
		}

		
		//key 값과 value를 ?력한다.
		printf("key = %s   value = %ld\n", key, value);
	}

	//hash 메모리를 할당하는 함수를 호출한다.
	hashDestroy(lpHash);
	
	return 0;
}

