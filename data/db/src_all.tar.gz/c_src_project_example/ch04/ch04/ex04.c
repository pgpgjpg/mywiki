#include <stdio.h>
#include <stdlib.h>

//가변 길이 배열을 필드로 사용하는 구조체 
typedef struct  {
  unsigned long len;
  char arr[0];
} FILENAME, *LP_FILENAME;

//포인터를 필드로 사용하는 구조체 
typedef struct  {
  unsigned long len;
  char* ptr;
} POINTER, *LP_POINTER;

int main(void)
{
    /*가변 배열은 아래와 같은 형식으로는 초기화 할 수 없음*/
    /*FILENAME fileName = {10, "1234567890"};*/
    LP_FILENAME lpFileName;
    //구조체 필드로 포인터를 사용하기 위한 변수 
    LP_POINTER lpPointer;
    unsigned long size;
    FILE* fp;

    //파일에 기록하기 위해 파일을 생성한다.
    fp = fopen("sample.dat", "rb");
    if (NULL == fp) {
        fprintf(stderr, "sample.dat 파일을 생성할 수 없습니다\n");
    }

    //파일에 가변길이를 먼저 읽는다. 
    //즉 이 부분이 자료의 header 가 됨 
    fread(&size, sizeof(size), 1, fp);
    
    //기변 길이 구조체 메모리를 할당한다.
    lpFileName = (LP_FILENAME) malloc (sizeof(FILENAME) + size + 1);
    if (NULL != lpFileName) {
        lpFileName->len = size;
        //파일에서 문자열을 읽어 들인다.
        fread(lpFileName->arr, size, 1, fp);
        lpFileName->arr[size] = '\0';
        
        printf("len -> %ld \n", lpFileName->len);
        printf("content  -> %s \n", lpFileName->arr);
        printf("sizeof -> %ld \n", sizeof(lpFileName));
    }
    //메모리를 해제한다.
    free(lpFileName);

    //일반 구조체에 포인터 필드를 가진 메모리를 할당합니다.
    lpPointer = (LP_POINTER) malloc (sizeof(POINTER));
    if (NULL != lpPointer) {

        //파일에 구조체를 먼저 읽는다. 
        //즉 이 부분이 자료의 header 가 됨, 단 header에 불필요한 값이 존재함 (ptr)
        fread(lpPointer, sizeof(POINTER), 1, fp);
    
        //구조체 안에서 사용할 배열 메모리를 할당합니다.
        lpPointer->ptr = (char*) malloc (lpPointer->len + 1);
        if (NULL != lpPointer->ptr) {

            fread(lpPointer->ptr, lpPointer->len, 1, fp);
            lpPointer->ptr[lpPointer->len] = '\0';
            
            printf("len -> %ld \n", lpPointer->len);
            printf("content  -> %s \n", lpPointer->ptr);
            printf("sizeof -> %ld \n", sizeof(POINTER));
            
            //메모리를 해제 하다.
            free(lpPointer->ptr);
        }
            //메모리를 해제 하다.
        free(lpPointer);
    }    
    //파일을 닫는다
    fclose(fp);
    
    return 0;
}
