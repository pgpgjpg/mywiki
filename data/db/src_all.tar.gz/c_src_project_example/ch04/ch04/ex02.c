#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	unsigned long len;
	char arr[0];
} FILENAME, *LP_FILENAME;


int main(void)
{
	LP_FILENAME  lpFileName;
	char *lpPath = "/home/user/ch05/array/ex04.c";
	int size = strlen(lpPath);

	lpFileName = (LP_FILENAME) malloc(sizeof(FILENAME) + strlen(lpPath) +1);
	if(lpFileName != NULL) {
		lpFileName->len = size;
		strcpy(lpFileName->arr, lpPath);
		printf("len -> %ld\n", lpFileName->len);
		printf("content -> %s\n", lpFileName->arr);
	}
	free(lpFileName);

	return 0;
}
